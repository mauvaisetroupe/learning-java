"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_core_home_home_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/core/home/home.component.ts?vue&type=script&lang=ts&":
/*!********************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/core/home/home.component.ts?vue&type=script&lang=ts& ***!
  \********************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_class_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-class-component */ "./node_modules/vue-class-component/dist/vue-class-component.esm.js");
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var Home = /** @class */ (function (_super) {
    __extends(Home, _super);
    function Home() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Home.prototype.openLogin = function () {
        this.loginService().openLogin(this.$root);
    };
    Object.defineProperty(Home.prototype, "authenticated", {
        get: function () {
            return this.$store.getters.authenticated;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Home.prototype, "username", {
        get: function () {
            var _a, _b;
            return (_b = (_a = this.$store.getters.account) === null || _a === void 0 ? void 0 : _a.login) !== null && _b !== void 0 ? _b : '';
        },
        enumerable: false,
        configurable: true
    });
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('loginService'),
        __metadata("design:type", Function)
    ], Home.prototype, "loginService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('accountService'),
        __metadata("design:type", Function)
    ], Home.prototype, "accountService", void 0);
    Home = __decorate([
        vue_class_component__WEBPACK_IMPORTED_MODULE_1__["default"]
    ], Home);
    return Home;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (Home);


/***/ }),

/***/ "./src/main/webapp/app/core/home/home.vue":
/*!************************************************!*\
  !*** ./src/main/webapp/app/core/home/home.vue ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_vue_vue_type_template_id_16362f12___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.vue?vue&type=template&id=16362f12& */ "./src/main/webapp/app/core/home/home.vue?vue&type=template&id=16362f12&");
/* harmony import */ var _home_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/core/home/home.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _home_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _home_vue_vue_type_template_id_16362f12___WEBPACK_IMPORTED_MODULE_0__.render,
  _home_vue_vue_type_template_id_16362f12___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/core/home/home.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/core/home/home.component.ts?vue&type=script&lang=ts&":
/*!**********************************************************************************!*\
  !*** ./src/main/webapp/app/core/home/home.component.ts?vue&type=script&lang=ts& ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_home_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./home.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/core/home/home.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_home_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/core/home/home.vue?vue&type=template&id=16362f12&":
/*!*******************************************************************************!*\
  !*** ./src/main/webapp/app/core/home/home.vue?vue&type=template&id=16362f12& ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_home_vue_vue_type_template_id_16362f12___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_home_vue_vue_type_template_id_16362f12___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_home_vue_vue_type_template_id_16362f12___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./home.vue?vue&type=template&id=16362f12& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/core/home/home.vue?vue&type=template&id=16362f12&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/core/home/home.vue?vue&type=template&id=16362f12&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/core/home/home.vue?vue&type=template&id=16362f12& ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "home row" }, [
    _vm._m(0),
    _vm._v(" "),
    _c("div", { staticClass: "col-md-9" }, [
      _c("h1", { staticClass: "display-4" }, [
        _vm._v("Welcome to EA Design IT"),
      ]),
      _vm._v(" "),
      _c("div", [
        _c("h2", [_vm._v("Introduction")]),
        _vm._v(" "),
        _c("p", [
          _vm._v(
            "\n        This application is tool to model application architecture building diagrams to document applications and interactions between\n        applications (data flows).\n      "
          ),
        ]),
        _vm._v(" "),
        _c("h2", [_vm._v("Main concepts")]),
        _vm._v(" "),
        _c("ul", [
          _c(
            "li",
            [
              _vm._v("\n          A "),
              _c("router-link", { attrs: { to: "landscape-view" } }, [
                _vm._v("Landscape"),
              ]),
              _vm._v(
                " is an architecture diagram that represents a subset of\n          "
              ),
              _c("router-link", { attrs: { to: "application" } }, [
                _vm._v("Applications"),
              ]),
              _vm._v(", and their Functional Flows\n        "),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "li",
            [
              _vm._v("\n          In the context of a Landscape, a "),
              _c("router-link", { attrs: { to: "functional-flow" } }, [
                _vm._v("Functional Flow"),
              ]),
              _vm._v(
                " represents a functional\n          information exchange between two ore more applications\n        "
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "li",
            [
              _vm._v(
                "\n          A Functional Flow is implemented through one or more "
              ),
              _c("router-link", { attrs: { to: "flow-interface" } }, [
                _vm._v("Interfaces"),
              ]),
              _vm._v(
                " to transfer\n          information between a source and a target Application.\n        "
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "li",
            [
              _vm._v(
                '\n          Interface is a "pipeline" between two applications and it\'s fully defined by a source and a target Application and a\n          '
              ),
              _c("router-link", { attrs: { to: "protocol" } }, [
                _vm._v("Protocol"),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "li",
            [
              _vm._v(
                "\n          In the context of a Function Flow, exchange data through a specific Interface is implemented by a\n          "
              ),
              _c("router-link", { attrs: { to: "data-flow" } }, [
                _vm._v("Data Flow"),
              ]),
              _vm._v(
                " (concretly, DataFlow is a File, an Event in a topic or API call of a\n          swagger)\n        "
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "li",
            [
              _c("router-link", { attrs: { to: "data-flow-item" } }, [
                _vm._v("Data Flow Item"),
              ]),
              _vm._v(
                " is used for model a more fined-grained data exchange (operation of\n          swagger, substructure in the File, event of a topic)\n        "
              ),
            ],
            1
          ),
        ]),
        _vm._v(" "),
        _vm._m(1),
      ]),
      _vm._v(" "),
      _vm.$store.getters.writeAuthority
        ? _c("div", [
            _c("h2", [_vm._v("Import")]),
            _vm._v(" "),
            _c("ul", [
              _c(
                "li",
                [
                  _vm._v("\n          Import Excel\n          "),
                  _c(
                    "router-link",
                    {
                      attrs: {
                        to: "/application-import-upload-file",
                        "data-cy": "import-excel-applications",
                      },
                    },
                    [_vm._v("Applications")]
                  ),
                  _vm._v(" file\n        "),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "li",
                [
                  _vm._v("\n          Import Excel\n          "),
                  _c(
                    "router-link",
                    {
                      attrs: {
                        to: "flow-import-upload-file",
                        "data-cy": "import-excel-flows",
                      },
                    },
                    [_vm._v("Functional Flows & Interfaces ")]
                  ),
                  _vm._v(" file\n        "),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "li",
                [
                  _vm._v("\n          Import Excel\n          "),
                  _c(
                    "router-link",
                    {
                      attrs: {
                        to: "event-import-upload-file",
                        "data-cy": "import-excel-data",
                      },
                    },
                    [_vm._v("Data Flows & Dat Flow Items")]
                  ),
                  _vm._v(" file\n        "),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "li",
                [
                  _vm._v("\n          Import Excel "),
                  _c(
                    "router-link",
                    {
                      attrs: {
                        to: "/capability-import-upload-file",
                        "data-cy": "import-excel-capabilities",
                      },
                    },
                    [_vm._v("Capabilities")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "li",
                [
                  _vm._v("\n          Import Excel mapping\n          "),
                  _c(
                    "router-link",
                    {
                      attrs: {
                        to: "/application-capability-import-upload-file",
                        "data-cy": "import-excel-capabilities-mapping",
                      },
                    },
                    [_vm._v("Applications/Capabilities")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "li",
                [
                  _vm._v("\n          Import Plantuml\n          "),
                  _c(
                    "router-link",
                    {
                      attrs: {
                        to: "/sequence-diagram/import",
                        "data-cy": "import-sequence-diagram-mapping",
                      },
                    },
                    [_vm._v("Sequence diagram")]
                  ),
                ],
                1
              ),
            ]),
            _vm._v(" "),
            _vm._m(2),
          ])
        : _vm._e(),
      _vm._v(" "),
      _vm.authenticated
        ? _c("div", { staticClass: "alert alert-success" }, [
            _vm.username
              ? _c("span", [
                  _vm._v(
                    'You are logged in as user "' + _vm._s(_vm.username) + '"'
                  ),
                ])
              : _vm._e(),
          ])
        : _vm._e(),
      _vm._v(" "),
      !_vm.authenticated
        ? _c("div", { staticClass: "alert alert-warning" }, [
            _c("span", [_vm._v("Please ")]),
            _c(
              "a",
              {
                staticClass: "alert-link",
                on: {
                  click: function ($event) {
                    return _vm.openLogin()
                  },
                },
              },
              [_vm._v("sign in")]
            ),
            _vm._v(".\n    "),
          ])
        : _vm._e(),
      _vm._v(" "),
      !_vm.authenticated
        ? _c(
            "div",
            { staticClass: "alert alert-warning" },
            [
              _c("span", [_vm._v("You don't have an account yet?")]),
              _vm._v(" \n      "),
              _c(
                "router-link",
                { staticClass: "alert-link", attrs: { to: "/register" } },
                [_vm._v("Register a new account")]
              ),
            ],
            1
          )
        : _vm._e(),
    ]),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "col-md-3" }, [
      _c("span", { staticClass: "hipster img-fluid rounded" }),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("Please, refer to "),
      _c(
        "a",
        { attrs: { href: "https://mauvaisetroupe.github.io/ea-design-it/" } },
        [_vm._v("documentation")]
      ),
      _vm._v(" for more explanation"),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("Please, refer to "),
      _c(
        "a",
        {
          attrs: {
            href: "https://mauvaisetroupe.github.io/ea-design-it/import/",
          },
        },
        [_vm._v("documentation")]
      ),
      _vm._v(" for more explanation"),
    ])
  },
]
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_core_home_home_vue.js.map