"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_owner_owner-update_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/owner/owner-update.component.ts?vue&type=script&lang=ts&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/owner/owner-update.component.ts?vue&type=script&lang=ts& ***!
  \*********************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var _shared_model_owner_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/shared/model/owner.model */ "./src/main/webapp/app/shared/model/owner.model.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var validations = {
    owner: {
        name: {},
    },
};
var OwnerUpdate = /** @class */ (function (_super) {
    __extends(OwnerUpdate, _super);
    function OwnerUpdate() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.owner = new _shared_model_owner_model__WEBPACK_IMPORTED_MODULE_1__.Owner();
        _this.users = [];
        _this.isSaving = false;
        _this.currentLanguage = '';
        return _this;
    }
    OwnerUpdate.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.ownerId) {
                vm.retrieveOwner(to.params.ownerId);
            }
            vm.initRelationships();
        });
    };
    OwnerUpdate.prototype.created = function () {
        var _this = this;
        this.currentLanguage = this.$store.getters.currentLanguage;
        this.$store.watch(function () { return _this.$store.getters.currentLanguage; }, function () {
            _this.currentLanguage = _this.$store.getters.currentLanguage;
        });
        this.owner.users = [];
    };
    OwnerUpdate.prototype.save = function () {
        var _this = this;
        this.isSaving = true;
        if (this.owner.id) {
            this.ownerService()
                .update(this.owner)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A Owner is updated with identifier ' + param.id;
                return _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Info',
                    variant: 'info',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
        else {
            this.ownerService()
                .create(this.owner)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A Owner is created with identifier ' + param.id;
                _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Success',
                    variant: 'success',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
    };
    OwnerUpdate.prototype.retrieveOwner = function (ownerId) {
        var _this = this;
        this.ownerService()
            .find(ownerId)
            .then(function (res) {
            _this.owner = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    OwnerUpdate.prototype.previousState = function () {
        this.$router.go(-1);
    };
    OwnerUpdate.prototype.initRelationships = function () {
        var _this = this;
        this.userService()
            .retrieve()
            .then(function (res) {
            _this.users = res.data;
        });
    };
    OwnerUpdate.prototype.getSelected = function (selectedVals, option) {
        var _a;
        if (selectedVals) {
            return (_a = selectedVals.find(function (value) { return option.id === value.id; })) !== null && _a !== void 0 ? _a : option;
        }
        return option;
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('ownerService'),
        __metadata("design:type", Function)
    ], OwnerUpdate.prototype, "ownerService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], OwnerUpdate.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('userService'),
        __metadata("design:type", Function)
    ], OwnerUpdate.prototype, "userService", void 0);
    OwnerUpdate = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            validations: validations,
        })
    ], OwnerUpdate);
    return OwnerUpdate;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (OwnerUpdate);


/***/ }),

/***/ "./src/main/webapp/app/shared/model/owner.model.ts":
/*!*********************************************************!*\
  !*** ./src/main/webapp/app/shared/model/owner.model.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Owner": function() { return /* binding */ Owner; }
/* harmony export */ });
var Owner = /** @class */ (function () {
    function Owner(id, name, users) {
        this.id = id;
        this.name = name;
        this.users = users;
    }
    return Owner;
}());



/***/ }),

/***/ "./src/main/webapp/app/entities/owner/owner-update.vue":
/*!*************************************************************!*\
  !*** ./src/main/webapp/app/entities/owner/owner-update.vue ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _owner_update_vue_vue_type_template_id_06e65daa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./owner-update.vue?vue&type=template&id=06e65daa& */ "./src/main/webapp/app/entities/owner/owner-update.vue?vue&type=template&id=06e65daa&");
/* harmony import */ var _owner_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./owner-update.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/owner/owner-update.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _owner_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _owner_update_vue_vue_type_template_id_06e65daa___WEBPACK_IMPORTED_MODULE_0__.render,
  _owner_update_vue_vue_type_template_id_06e65daa___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/owner/owner-update.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/owner/owner-update.component.ts?vue&type=script&lang=ts&":
/*!***********************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/owner/owner-update.component.ts?vue&type=script&lang=ts& ***!
  \***********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_owner_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./owner-update.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/owner/owner-update.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_owner_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/owner/owner-update.vue?vue&type=template&id=06e65daa&":
/*!********************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/owner/owner-update.vue?vue&type=template&id=06e65daa& ***!
  \********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_owner_update_vue_vue_type_template_id_06e65daa___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_owner_update_vue_vue_type_template_id_06e65daa___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_owner_update_vue_vue_type_template_id_06e65daa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./owner-update.vue?vue&type=template&id=06e65daa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/owner/owner-update.vue?vue&type=template&id=06e65daa&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/owner/owner-update.vue?vue&type=template&id=06e65daa&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/owner/owner-update.vue?vue&type=template&id=06e65daa& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row justify-content-center" }, [
    _c("div", { staticClass: "col-8" }, [
      _c(
        "form",
        {
          attrs: { name: "editForm", role: "form", novalidate: "" },
          on: {
            submit: function ($event) {
              $event.preventDefault()
              return _vm.save()
            },
          },
        },
        [
          _c(
            "h2",
            {
              attrs: {
                id: "eaDesignItApp.owner.home.createOrEditLabel",
                "data-cy": "OwnerCreateUpdateHeading",
              },
            },
            [_vm._v("Create or edit a Owner")]
          ),
          _vm._v(" "),
          _c("div", [
            _vm.owner.id
              ? _c("div", { staticClass: "form-group" }, [
                  _c("label", { attrs: { for: "id" } }, [_vm._v("ID")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.owner.id,
                        expression: "owner.id",
                      },
                    ],
                    staticClass: "form-control",
                    attrs: { type: "text", id: "id", name: "id", readonly: "" },
                    domProps: { value: _vm.owner.id },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.owner, "id", $event.target.value)
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "owner-name" },
                },
                [_vm._v("Name")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.owner.name.$model,
                    expression: "$v.owner.name.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.owner.name.$invalid,
                  invalid: _vm.$v.owner.name.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "name",
                  id: "owner-name",
                  "data-cy": "name",
                },
                domProps: { value: _vm.$v.owner.name.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(_vm.$v.owner.name, "$model", $event.target.value)
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c("label", { attrs: { for: "owner-users" } }, [_vm._v("Users")]),
              _vm._v(" "),
              _vm.owner.users !== undefined
                ? _c(
                    "select",
                    {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.owner.users,
                          expression: "owner.users",
                        },
                      ],
                      staticClass: "form-control",
                      attrs: {
                        id: "owner-users",
                        "data-cy": "users",
                        multiple: "",
                        name: "users",
                      },
                      on: {
                        change: function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.owner,
                            "users",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                      },
                    },
                    _vm._l(_vm.users, function (userOption) {
                      return _c(
                        "option",
                        {
                          key: userOption.id,
                          domProps: {
                            value: _vm.getSelected(_vm.owner.users, userOption),
                          },
                        },
                        [
                          _vm._v(
                            "\n              " +
                              _vm._s(userOption.login) +
                              "\n            "
                          ),
                        ]
                      )
                    }),
                    0
                  )
                : _vm._e(),
            ]),
          ]),
          _vm._v(" "),
          _c("div", [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: {
                  type: "button",
                  id: "cancel-save",
                  "data-cy": "entityCreateCancelButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.previousState()
                  },
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "ban" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Cancel")]),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "submit",
                  id: "save-entity",
                  "data-cy": "entityCreateSaveButton",
                  disabled: _vm.$v.owner.$invalid || _vm.isSaving,
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "save" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Save")]),
              ],
              1
            ),
          ]),
        ]
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_owner_owner-update_vue.js.map