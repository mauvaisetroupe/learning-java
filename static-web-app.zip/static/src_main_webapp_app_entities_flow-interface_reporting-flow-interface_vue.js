(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_flow-interface_reporting-flow-interface_vue"],{

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.mycolor {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n.mymodalclass {\n  max-width: 1000px;\n}\n.modal-dialog {\n  max-width: 80%;\n}\n", "",{"version":3,"sources":["webpack://./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue"],"names":[],"mappings":";AA2PA;EACA,oCAAA;AACA;AACA;EACA,iBAAA;AACA;AACA;EACA,cAAA;AACA","sourcesContent":["<template>\n  <div>\n    <h2 id=\"page-heading\" data-cy=\"FlowInterfaceHeading\">\n      <span id=\"flow-interface-heading\">Flow Interfaces - Possible duplicates</span>\n      <div class=\"d-flex justify-content-end\">\n        <button class=\"btn btn-info mr-2\" v-on:click=\"handleSyncList\" :disabled=\"isFetching\">\n          <font-awesome-icon icon=\"sync\" :spin=\"isFetching\"></font-awesome-icon> <span>Refresh List</span>\n        </button>\n        <router-link :to=\"{ name: 'FlowInterfaceCreate' }\" custom v-slot=\"{ navigate }\">\n          <button\n            @click=\"navigate\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-primary jh-create-entity create-flow-interface\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span> Create a new Flow Interface </span>\n          </button>\n        </router-link>\n      </div>\n    </h2>\n    <br />\n    <div class=\"alert alert-warning\" v-if=\"!isFetching && flowInterfaces && flowInterfaces.length === 0\">\n      <span>No flowInterfaces found</span>\n    </div>\n    <div class=\"table-responsive\" v-if=\"flowInterfaces && flowInterfaces.length > 0\">\n      <table class=\"table\" aria-describedby=\"flowInterfaces\">\n        <thead>\n          <tr>\n            <th scope=\"row\"><span>Alias</span></th>\n            <th scope=\"row\"><span>Flows</span></th>\n            <th scope=\"row\"><span>Status</span></th>\n            <th scope=\"row\"><span>Documentation URL</span></th>\n            <th scope=\"row\"><span>Documentation URL 2</span></th>\n            <th scope=\"row\"><span>Start Date</span></th>\n            <th scope=\"row\"><span>End Date</span></th>\n            <th scope=\"row\"><span>Source</span></th>\n            <th scope=\"row\"><span>Target</span></th>\n            <th scope=\"row\"><span>Source Component</span></th>\n            <th scope=\"row\"><span>Target Component</span></th>\n            <th scope=\"row\"><span>Protocol</span></th>\n            <th scope=\"row\"><span>Owner</span></th>\n            <th scope=\"row\"><span>Data Flow</span></th>\n            <th scope=\"row\"></th>\n          </tr>\n        </thead>\n        <tbody>\n          <tr v-for=\"flowInterface in flowInterfaces\" :key=\"flowInterface.id\" data-cy=\"entityTable\" :class=\"flowInterface.colored\">\n            <td>\n              <router-link :to=\"{ name: 'FlowInterfaceView', params: { flowInterfaceId: flowInterface.id } }\">{{\n                flowInterface.alias\n              }}</router-link>\n            </td>\n            <td>\n              <span v-for=\"(functionalFlow, i) in flowInterface.functionalFlows\" :key=\"functionalFlow.id\">\n                {{ i > 0 ? ', ' : '' }}\n                <router-link :to=\"{ name: 'FunctionalFlowView', params: { functionalFlowId: functionalFlow.id } }\">{{\n                  functionalFlow.alias\n                }}</router-link>\n              </span>\n            </td>\n            <td>{{ flowInterface.status }}</td>\n            <td>\n              <a v-bind:href=\"flowInterface.documentationURL\">{{ flowInterface.documentationURL }}</a>\n            </td>\n            <td>\n              <a v-bind:href=\"flowInterface.documentationURL2\">{{ flowInterface.documentationURL2 }}</a>\n            </td>\n            <td>{{ flowInterface.startDate }}</td>\n            <td>{{ flowInterface.endDate }}</td>\n            <td>\n              <div v-if=\"flowInterface.source\">\n                <router-link :to=\"{ name: 'ApplicationView', params: { applicationId: flowInterface.source.id } }\">{{\n                  flowInterface.source.name\n                }}</router-link>\n              </div>\n            </td>\n            <td>\n              <div v-if=\"flowInterface.target\">\n                <router-link :to=\"{ name: 'ApplicationView', params: { applicationId: flowInterface.target.id } }\">{{\n                  flowInterface.target.name\n                }}</router-link>\n              </div>\n            </td>\n            <td>\n              <div v-if=\"flowInterface.sourceComponent\">\n                <router-link\n                  :to=\"{ name: 'ApplicationComponentView', params: { applicationComponentId: flowInterface.sourceComponent.id } }\"\n                  >{{ flowInterface.sourceComponent.name }}</router-link\n                >\n              </div>\n            </td>\n            <td>\n              <div v-if=\"flowInterface.targetComponent\">\n                <router-link\n                  :to=\"{ name: 'ApplicationComponentView', params: { applicationComponentId: flowInterface.targetComponent.id } }\"\n                  >{{ flowInterface.targetComponent.name }}</router-link\n                >\n              </div>\n            </td>\n            <td>\n              <div v-if=\"flowInterface.protocol\">\n                <router-link :to=\"{ name: 'ProtocolView', params: { protocolId: flowInterface.protocol.id } }\">{{\n                  flowInterface.protocol.name\n                }}</router-link>\n              </div>\n            </td>\n            <td>\n              <div v-if=\"flowInterface.owner\">\n                <router-link :to=\"{ name: 'OwnerView', params: { ownerId: flowInterface.owner.id } }\">{{\n                  flowInterface.owner.name\n                }}</router-link>\n              </div>\n            </td>\n            <td>\n              <span v-for=\"(dataFlow, i) in flowInterface.dataFlows\" :key=\"dataFlow.id\"\n                >{{ i > 0 ? ', ' : '' }}\n                <router-link class=\"form-control-static\" :to=\"{ name: 'DataFlowView', params: { dataFlowId: dataFlow.id } }\"\n                  >{{ dataFlow.id }}<sup v-if=\"dataFlow.items && dataFlow.items.length > 0\">({{ dataFlow.items.length }})</sup></router-link\n                >\n              </span>\n            </td>\n            <td class=\"text-right\">\n              <div class=\"btn-group\">\n                <b-button\n                  v-on:click=\"prepareMerge(flowInterface)\"\n                  variant=\"warning\"\n                  class=\"btn btn-sm\"\n                  data-cy=\"entityDeleteButton\"\n                  v-b-modal.mergeEntity\n                >\n                  <font-awesome-icon icon=\"asterisk\"></font-awesome-icon>\n                  <span class=\"d-none d-md-inline\">Merge</span>\n                </b-button>\n              </div>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <b-modal ref=\"mergeEntity\" id=\"mergeEntity\" class=\"mymodalclass\">\n      <span slot=\"modal-title\"\n        ><span id=\"eaDesignItApp.flowInterface.delete.question\" data-cy=\"flowInterfaceDeleteDialogHeading\"\n          >Confirm merge operation</span\n        ></span\n      >\n      <div class=\"modal-body\">\n        <p id=\"jhi-delete-flowInterface-heading\" v-if=\"interfaceToKeep\">\n          Are you sure you want to merge flows Interface between <strong>{{ interfaceToKeep.source.name }}</strong> and\n          <strong>{{ interfaceToKeep.target.name }}</strong> ?\n        </p>\n        <p id=\"jhi-delete-flowInterface-heading\" v-if=\"interfaceToKeep\">\n          Interface <strong>{{ interfaceToKeep.alias }}</strong> will replace <strong>{{ checkToMerge }}</strong> ?\n        </p>\n        <strong>Data Flow Comparison</strong>\n        <div class=\"table-responsive\">\n          <table class=\"table\">\n            <thead>\n              <tr>\n                <th scope=\"row\">keep</th>\n                <th scope=\"row\">merge</th>\n                <th scope=\"row\" colspan=\"3\"><span>Interface</span></th>\n                <th scope=\"row\"><span>Flow</span></th>\n                <th scope=\"row\"><span>Data Id</span></th>\n                <th scope=\"row\"><span>Data Resource Name</span></th>\n                <th scope=\"row\"><span>Data Frequency</span></th>\n                <th scope=\"row\"><span>Data Format</span></th>\n              </tr>\n            </thead>\n            <template v-for=\"(inter, i) in interfacesToMerge\">\n              <template v-for=\"(dataFlowToMerge, j) in inter.dataFlows\">\n                <tr :key=\"dataFlowToMerge.id\" :class=\"i % 2 == 0 ? 'mycolor' : ''\">\n                  <td><input v-if=\"j == 0\" type=\"radio\" :value=\"inter\" v-model=\"interfaceToKeep\" @change=\"prepareMerge(inter)\" /></td>\n                  <td>\n                    <input\n                      v-if=\"j == 0\"\n                      :disabled=\"inter.alias == interfaceToKeep.alias\"\n                      type=\"checkbox\"\n                      :id=\"inter.alias\"\n                      :value=\"inter.alias\"\n                      v-model=\"checkToMerge\"\n                    />\n                  </td>\n                  <td>{{ inter.alias }}</td>\n                  <td>\n                    <span v-if=\"inter.documentationURL\">\n                      <a :href=\"inter.documentationURL\" :title=\"inter.alias\" target=\"_blank\">{{ inter.documentationURL }}</a>\n                    </span>\n                  </td>\n                  <td>\n                    <span v-if=\"inter.documentationURL2\">\n                      <a :href=\"inter.documentationURL2\" :title=\"inter.alias\" target=\"_blank\">{{ inter.documentationURL2 }}</a>\n                    </span>\n                  </td>\n                  <td>\n                    <span v-for=\"(flow, k) in inter.functionalFlows\" :key=\"flow.id\" :title=\"flow.description\">\n                      {{ k > 0 ? ', ' : '' }}\n                      {{ flow.alias }}\n                    </span>\n                  </td>\n                  <td>{{ dataFlowToMerge.id }}</td>\n                  <td>{{ dataFlowToMerge.resourceName }}</td>\n                  <td>{{ dataFlowToMerge.frequency }}</td>\n                  <td>{{ dataFlowToMerge.format ? dataFlowToMerge.format.name : '' }}</td>\n                  <td>{{ dataFlowToMerge.resourceType }}</td>\n                  <td>\n                    <span v-if=\"dataFlowToMerge.contractURL\">\n                      <a\n                        :href=\"dataFlowToMerge.contractURL\"\n                        :title=\"'dataFlow ' + dataFlowToMerge.id + ' : ' + dataFlowToMerge.resourceName\"\n                        target=\"_blank\"\n                        >{{ dataFlowToMerge.contractURL }}</a\n                      >\n                    </span>\n                  </td>\n                  <td>\n                    <span v-if=\"dataFlowToMerge.documentationURL\">\n                      <a :href=\"dataFlowToMerge.documentationURL\" :title=\"dataFlowToMerge.resourceName\" target=\"_blank\">{{\n                        dataFlowToMerge.documentationURL\n                      }}</a>\n                    </span>\n                  </td>\n                  <td>{{ dataFlowToMerge.startDate }}</td>\n                  <td>{{ dataFlowToMerge.endDate }}</td>\n                  <td title=\"dataFlow description\">{{ dataFlowToMerge.description }}</td>\n                </tr>\n              </template>\n            </template>\n          </table>\n        </div>\n      </div>\n      <div slot=\"modal-footer\">\n        <button type=\"button\" class=\"btn btn-secondary\" v-on:click=\"closeMergeDialog()\">Cancel</button>\n        <button\n          type=\"button\"\n          class=\"btn btn-primary\"\n          id=\"mergeflowInterfaceButtonID\"\n          ref=\"mergeflowInterfaceButtonRef\"\n          data-cy=\"entityConfirmDeleteButton\"\n          v-on:click=\"mergeFlowInterface()\"\n        >\n          Merge\n        </button>\n      </div>\n    </b-modal>\n  </div>\n</template>\n\n<script lang=\"ts\" src=\"./reporting-flow-interface.components.ts\"></script>\n\n<style>\n.mycolor {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n.mymodalclass {\n  max-width: 1000px;\n}\n.modal-dialog {\n  max-width: 80%;\n}\n</style>\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.components.ts?vue&type=script&lang=ts&":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.components.ts?vue&type=script&lang=ts& ***!
  \*******************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vue2_filters__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue2-filters */ "./node_modules/vue2-filters/dist/vue2-filters.js");
/* harmony import */ var vue2_filters__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue2_filters__WEBPACK_IMPORTED_MODULE_1__);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FlowInterface = /** @class */ (function (_super) {
    __extends(FlowInterface, _super);
    function FlowInterface() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.interfaceToKeep = null;
        _this.interfacesToMerge = null;
        _this.checkToMerge = [];
        _this.flowInterfaces = [];
        _this.isFetching = false;
        return _this;
    }
    FlowInterface.prototype.mounted = function () {
        this.retrieveAllFlowInterfaces();
    };
    FlowInterface.prototype.clear = function () {
        this.retrieveAllFlowInterfaces();
    };
    FlowInterface.prototype.retrieveAllFlowInterfaces = function () {
        var _this = this;
        this.isFetching = true;
        this.reportingService()
            .retrieveInterfaces()
            .then(function (res) {
            _this.flowInterfaces = res.data;
            _this.isFetching = false;
            var mycolor = 'mycolor';
            var previousTuple = '';
            var mergeList = [];
            _this.flowInterfaces.forEach(function (element) {
                if (previousTuple !== element.source.name + element.target.name + element.protocol.id) {
                    mergeList = [];
                    if (mycolor === 'mycolor') {
                        mycolor = '';
                    }
                    else {
                        mycolor = 'mycolor';
                    }
                }
                mergeList.push(element.alias);
                previousTuple = element.source.name + element.target.name + element.protocol.id;
                element.colored = mycolor;
                element.mergeList = mergeList;
            });
        }, function (err) {
            _this.isFetching = false;
            _this.alertService().showHttpError(_this, err.response);
        });
    };
    FlowInterface.prototype.handleSyncList = function () {
        this.clear();
    };
    FlowInterface.prototype.prepareMerge = function (instance) {
        var _this = this;
        this.interfaceToKeep = instance;
        var aliasToMerge = this.interfaceToKeep.mergeList;
        console.log(aliasToMerge);
        this.interfacesToMerge = [];
        this.checkToMerge = [];
        this.flowInterfaces.forEach(function (inter) {
            if (aliasToMerge.indexOf(inter.alias) > -1) {
                _this.interfacesToMerge.push(inter);
                if (inter.id != _this.interfaceToKeep.id) {
                    _this.checkToMerge.push(inter.alias);
                }
            }
        });
        if (this.$refs.mergeEntity) {
            this.$refs.mergeEntity.show();
        }
    };
    FlowInterface.prototype.mergeFlowInterface = function () {
        var _this = this;
        this.reportingService()
            .mergeInterfaces(this.interfaceToKeep, this.checkToMerge)
            .then(function () {
            var message = 'FlowInterfaces ' + _this.checkToMerge + ' have been merged and replaced by ' + _this.interfaceToKeep.alias;
            _this.$bvToast.toast(message.toString(), {
                toaster: 'b-toaster-top-center',
                title: 'Info',
                variant: 'danger',
                solid: true,
                autoHideDelay: 5000,
            });
            _this.interfaceToKeep = null;
            _this.interfacesToMerge = null;
            _this.checkToMerge = [];
            _this.retrieveAllFlowInterfaces();
            _this.closeMergeDialog();
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    FlowInterface.prototype.closeDialog = function () {
        this.$refs.removeEntity.hide();
    };
    FlowInterface.prototype.closeMergeDialog = function () {
        this.$refs.mergeEntity.hide();
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('flowInterfaceService'),
        __metadata("design:type", Function)
    ], FlowInterface.prototype, "flowInterfaceService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], FlowInterface.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('accountService'),
        __metadata("design:type", Function)
    ], FlowInterface.prototype, "accountService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('reportingService'),
        __metadata("design:type", Function)
    ], FlowInterface.prototype, "reportingService", void 0);
    FlowInterface = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            mixins: [(vue2_filters__WEBPACK_IMPORTED_MODULE_1___default().mixin)],
        })
    ], FlowInterface);
    return FlowInterface;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (FlowInterface);


/***/ }),

/***/ "./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue":
/*!**********************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _reporting_flow_interface_vue_vue_type_template_id_33e8405a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reporting-flow-interface.vue?vue&type=template&id=33e8405a& */ "./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=template&id=33e8405a&");
/* harmony import */ var _reporting_flow_interface_components_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reporting-flow-interface.components.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.components.ts?vue&type=script&lang=ts&");
/* harmony import */ var _reporting_flow_interface_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reporting-flow-interface.vue?vue&type=style&index=0&lang=css& */ "./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _reporting_flow_interface_components_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _reporting_flow_interface_vue_vue_type_template_id_33e8405a___WEBPACK_IMPORTED_MODULE_0__.render,
  _reporting_flow_interface_vue_vue_type_template_id_33e8405a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.components.ts?vue&type=script&lang=ts&":
/*!*********************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.components.ts?vue&type=script&lang=ts& ***!
  \*********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_reporting_flow_interface_components_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./reporting-flow-interface.components.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.components.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_reporting_flow_interface_components_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=template&id=33e8405a&":
/*!*****************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=template&id=33e8405a& ***!
  \*****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_template_id_33e8405a___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_template_id_33e8405a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_template_id_33e8405a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./reporting-flow-interface.vue?vue&type=template&id=33e8405a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=template&id=33e8405a&");


/***/ }),

/***/ "./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-style-loader/index.js!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./reporting-flow-interface.vue?vue&type=style&index=0&lang=css& */ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = function(key) { return _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_reporting_flow_interface_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }.bind(0, __WEBPACK_IMPORT_KEY__)
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=template&id=33e8405a&":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=template&id=33e8405a& ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "h2",
        { attrs: { id: "page-heading", "data-cy": "FlowInterfaceHeading" } },
        [
          _c("span", { attrs: { id: "flow-interface-heading" } }, [
            _vm._v("Flow Interfaces - Possible duplicates"),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "d-flex justify-content-end" },
            [
              _c(
                "button",
                {
                  staticClass: "btn btn-info mr-2",
                  attrs: { disabled: _vm.isFetching },
                  on: { click: _vm.handleSyncList },
                },
                [
                  _c("font-awesome-icon", {
                    attrs: { icon: "sync", spin: _vm.isFetching },
                  }),
                  _vm._v(" "),
                  _c("span", [_vm._v("Refresh List")]),
                ],
                1
              ),
              _vm._v(" "),
              _c("router-link", {
                attrs: { to: { name: "FlowInterfaceCreate" }, custom: "" },
                scopedSlots: _vm._u([
                  {
                    key: "default",
                    fn: function (ref) {
                      var navigate = ref.navigate
                      return [
                        _c(
                          "button",
                          {
                            staticClass:
                              "btn btn-primary jh-create-entity create-flow-interface",
                            attrs: {
                              id: "jh-create-entity",
                              "data-cy": "entityCreateButton",
                            },
                            on: { click: navigate },
                          },
                          [
                            _c("font-awesome-icon", {
                              attrs: { icon: "plus" },
                            }),
                            _vm._v(" "),
                            _c("span", [
                              _vm._v(" Create a new Flow Interface "),
                            ]),
                          ],
                          1
                        ),
                      ]
                    },
                  },
                ]),
              }),
            ],
            1
          ),
        ]
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      !_vm.isFetching && _vm.flowInterfaces && _vm.flowInterfaces.length === 0
        ? _c("div", { staticClass: "alert alert-warning" }, [
            _c("span", [_vm._v("No flowInterfaces found")]),
          ])
        : _vm._e(),
      _vm._v(" "),
      _vm.flowInterfaces && _vm.flowInterfaces.length > 0
        ? _c("div", { staticClass: "table-responsive" }, [
            _c(
              "table",
              {
                staticClass: "table",
                attrs: { "aria-describedby": "flowInterfaces" },
              },
              [
                _vm._m(0),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.flowInterfaces, function (flowInterface) {
                    return _c(
                      "tr",
                      {
                        key: flowInterface.id,
                        class: flowInterface.colored,
                        attrs: { "data-cy": "entityTable" },
                      },
                      [
                        _c(
                          "td",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "FlowInterfaceView",
                                    params: {
                                      flowInterfaceId: flowInterface.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(flowInterface.alias))]
                            ),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "td",
                          _vm._l(
                            flowInterface.functionalFlows,
                            function (functionalFlow, i) {
                              return _c(
                                "span",
                                { key: functionalFlow.id },
                                [
                                  _vm._v(
                                    "\n              " +
                                      _vm._s(i > 0 ? ", " : "") +
                                      "\n              "
                                  ),
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "FunctionalFlowView",
                                          params: {
                                            functionalFlowId: functionalFlow.id,
                                          },
                                        },
                                      },
                                    },
                                    [_vm._v(_vm._s(functionalFlow.alias))]
                                  ),
                                ],
                                1
                              )
                            }
                          ),
                          0
                        ),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(flowInterface.status))]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "a",
                            { attrs: { href: flowInterface.documentationURL } },
                            [_vm._v(_vm._s(flowInterface.documentationURL))]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "a",
                            {
                              attrs: { href: flowInterface.documentationURL2 },
                            },
                            [_vm._v(_vm._s(flowInterface.documentationURL2))]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(flowInterface.startDate))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(flowInterface.endDate))]),
                        _vm._v(" "),
                        _c("td", [
                          flowInterface.source
                            ? _c(
                                "div",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "ApplicationView",
                                          params: {
                                            applicationId:
                                              flowInterface.source.id,
                                          },
                                        },
                                      },
                                    },
                                    [_vm._v(_vm._s(flowInterface.source.name))]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          flowInterface.target
                            ? _c(
                                "div",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "ApplicationView",
                                          params: {
                                            applicationId:
                                              flowInterface.target.id,
                                          },
                                        },
                                      },
                                    },
                                    [_vm._v(_vm._s(flowInterface.target.name))]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          flowInterface.sourceComponent
                            ? _c(
                                "div",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "ApplicationComponentView",
                                          params: {
                                            applicationComponentId:
                                              flowInterface.sourceComponent.id,
                                          },
                                        },
                                      },
                                    },
                                    [
                                      _vm._v(
                                        _vm._s(
                                          flowInterface.sourceComponent.name
                                        )
                                      ),
                                    ]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          flowInterface.targetComponent
                            ? _c(
                                "div",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "ApplicationComponentView",
                                          params: {
                                            applicationComponentId:
                                              flowInterface.targetComponent.id,
                                          },
                                        },
                                      },
                                    },
                                    [
                                      _vm._v(
                                        _vm._s(
                                          flowInterface.targetComponent.name
                                        )
                                      ),
                                    ]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          flowInterface.protocol
                            ? _c(
                                "div",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "ProtocolView",
                                          params: {
                                            protocolId:
                                              flowInterface.protocol.id,
                                          },
                                        },
                                      },
                                    },
                                    [
                                      _vm._v(
                                        _vm._s(flowInterface.protocol.name)
                                      ),
                                    ]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          flowInterface.owner
                            ? _c(
                                "div",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "OwnerView",
                                          params: {
                                            ownerId: flowInterface.owner.id,
                                          },
                                        },
                                      },
                                    },
                                    [_vm._v(_vm._s(flowInterface.owner.name))]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ]),
                        _vm._v(" "),
                        _c(
                          "td",
                          _vm._l(
                            flowInterface.dataFlows,
                            function (dataFlow, i) {
                              return _c(
                                "span",
                                { key: dataFlow.id },
                                [
                                  _vm._v(
                                    _vm._s(i > 0 ? ", " : "") +
                                      "\n              "
                                  ),
                                  _c(
                                    "router-link",
                                    {
                                      staticClass: "form-control-static",
                                      attrs: {
                                        to: {
                                          name: "DataFlowView",
                                          params: { dataFlowId: dataFlow.id },
                                        },
                                      },
                                    },
                                    [
                                      _vm._v(_vm._s(dataFlow.id)),
                                      dataFlow.items &&
                                      dataFlow.items.length > 0
                                        ? _c("sup", [
                                            _vm._v(
                                              "(" +
                                                _vm._s(dataFlow.items.length) +
                                                ")"
                                            ),
                                          ])
                                        : _vm._e(),
                                    ]
                                  ),
                                ],
                                1
                              )
                            }
                          ),
                          0
                        ),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-right" }, [
                          _c(
                            "div",
                            { staticClass: "btn-group" },
                            [
                              _c(
                                "b-button",
                                {
                                  directives: [
                                    {
                                      name: "b-modal",
                                      rawName: "v-b-modal.mergeEntity",
                                      modifiers: { mergeEntity: true },
                                    },
                                  ],
                                  staticClass: "btn btn-sm",
                                  attrs: {
                                    variant: "warning",
                                    "data-cy": "entityDeleteButton",
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.prepareMerge(flowInterface)
                                    },
                                  },
                                },
                                [
                                  _c("font-awesome-icon", {
                                    attrs: { icon: "asterisk" },
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "span",
                                    { staticClass: "d-none d-md-inline" },
                                    [_vm._v("Merge")]
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ]),
                      ]
                    )
                  }),
                  0
                ),
              ]
            ),
          ])
        : _vm._e(),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          ref: "mergeEntity",
          staticClass: "mymodalclass",
          attrs: { id: "mergeEntity" },
        },
        [
          _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
            _c(
              "span",
              {
                attrs: {
                  id: "eaDesignItApp.flowInterface.delete.question",
                  "data-cy": "flowInterfaceDeleteDialogHeading",
                },
              },
              [_vm._v("Confirm merge operation")]
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-body" }, [
            _vm.interfaceToKeep
              ? _c("p", { attrs: { id: "jhi-delete-flowInterface-heading" } }, [
                  _vm._v(
                    "\n        Are you sure you want to merge flows Interface between "
                  ),
                  _c("strong", [
                    _vm._v(_vm._s(_vm.interfaceToKeep.source.name)),
                  ]),
                  _vm._v(" and\n        "),
                  _c("strong", [
                    _vm._v(_vm._s(_vm.interfaceToKeep.target.name)),
                  ]),
                  _vm._v(" ?\n      "),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.interfaceToKeep
              ? _c("p", { attrs: { id: "jhi-delete-flowInterface-heading" } }, [
                  _vm._v("\n        Interface "),
                  _c("strong", [_vm._v(_vm._s(_vm.interfaceToKeep.alias))]),
                  _vm._v(" will replace "),
                  _c("strong", [_vm._v(_vm._s(_vm.checkToMerge))]),
                  _vm._v(" ?\n      "),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("strong", [_vm._v("Data Flow Comparison")]),
            _vm._v(" "),
            _c("div", { staticClass: "table-responsive" }, [
              _c(
                "table",
                { staticClass: "table" },
                [
                  _c("thead", [
                    _c("tr", [
                      _c("th", { attrs: { scope: "row" } }, [_vm._v("keep")]),
                      _vm._v(" "),
                      _c("th", { attrs: { scope: "row" } }, [_vm._v("merge")]),
                      _vm._v(" "),
                      _c("th", { attrs: { scope: "row", colspan: "3" } }, [
                        _c("span", [_vm._v("Interface")]),
                      ]),
                      _vm._v(" "),
                      _c("th", { attrs: { scope: "row" } }, [
                        _c("span", [_vm._v("Flow")]),
                      ]),
                      _vm._v(" "),
                      _c("th", { attrs: { scope: "row" } }, [
                        _c("span", [_vm._v("Data Id")]),
                      ]),
                      _vm._v(" "),
                      _c("th", { attrs: { scope: "row" } }, [
                        _c("span", [_vm._v("Data Resource Name")]),
                      ]),
                      _vm._v(" "),
                      _c("th", { attrs: { scope: "row" } }, [
                        _c("span", [_vm._v("Data Frequency")]),
                      ]),
                      _vm._v(" "),
                      _c("th", { attrs: { scope: "row" } }, [
                        _c("span", [_vm._v("Data Format")]),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _vm._l(_vm.interfacesToMerge, function (inter, i) {
                    return [
                      _vm._l(inter.dataFlows, function (dataFlowToMerge, j) {
                        return [
                          _c(
                            "tr",
                            {
                              key: dataFlowToMerge.id,
                              class: i % 2 == 0 ? "mycolor" : "",
                            },
                            [
                              _c("td", [
                                j == 0
                                  ? _c("input", {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value: _vm.interfaceToKeep,
                                          expression: "interfaceToKeep",
                                        },
                                      ],
                                      attrs: { type: "radio" },
                                      domProps: {
                                        value: inter,
                                        checked: _vm._q(
                                          _vm.interfaceToKeep,
                                          inter
                                        ),
                                      },
                                      on: {
                                        change: [
                                          function ($event) {
                                            _vm.interfaceToKeep = inter
                                          },
                                          function ($event) {
                                            return _vm.prepareMerge(inter)
                                          },
                                        ],
                                      },
                                    })
                                  : _vm._e(),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                j == 0
                                  ? _c("input", {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value: _vm.checkToMerge,
                                          expression: "checkToMerge",
                                        },
                                      ],
                                      attrs: {
                                        disabled:
                                          inter.alias ==
                                          _vm.interfaceToKeep.alias,
                                        type: "checkbox",
                                        id: inter.alias,
                                      },
                                      domProps: {
                                        value: inter.alias,
                                        checked: Array.isArray(_vm.checkToMerge)
                                          ? _vm._i(
                                              _vm.checkToMerge,
                                              inter.alias
                                            ) > -1
                                          : _vm.checkToMerge,
                                      },
                                      on: {
                                        change: function ($event) {
                                          var $$a = _vm.checkToMerge,
                                            $$el = $event.target,
                                            $$c = $$el.checked ? true : false
                                          if (Array.isArray($$a)) {
                                            var $$v = inter.alias,
                                              $$i = _vm._i($$a, $$v)
                                            if ($$el.checked) {
                                              $$i < 0 &&
                                                (_vm.checkToMerge = $$a.concat([
                                                  $$v,
                                                ]))
                                            } else {
                                              $$i > -1 &&
                                                (_vm.checkToMerge = $$a
                                                  .slice(0, $$i)
                                                  .concat($$a.slice($$i + 1)))
                                            }
                                          } else {
                                            _vm.checkToMerge = $$c
                                          }
                                        },
                                      },
                                    })
                                  : _vm._e(),
                              ]),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(inter.alias))]),
                              _vm._v(" "),
                              _c("td", [
                                inter.documentationURL
                                  ? _c("span", [
                                      _c(
                                        "a",
                                        {
                                          attrs: {
                                            href: inter.documentationURL,
                                            title: inter.alias,
                                            target: "_blank",
                                          },
                                        },
                                        [_vm._v(_vm._s(inter.documentationURL))]
                                      ),
                                    ])
                                  : _vm._e(),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                inter.documentationURL2
                                  ? _c("span", [
                                      _c(
                                        "a",
                                        {
                                          attrs: {
                                            href: inter.documentationURL2,
                                            title: inter.alias,
                                            target: "_blank",
                                          },
                                        },
                                        [
                                          _vm._v(
                                            _vm._s(inter.documentationURL2)
                                          ),
                                        ]
                                      ),
                                    ])
                                  : _vm._e(),
                              ]),
                              _vm._v(" "),
                              _c(
                                "td",
                                _vm._l(
                                  inter.functionalFlows,
                                  function (flow, k) {
                                    return _c(
                                      "span",
                                      {
                                        key: flow.id,
                                        attrs: { title: flow.description },
                                      },
                                      [
                                        _vm._v(
                                          "\n                    " +
                                            _vm._s(k > 0 ? ", " : "") +
                                            "\n                    " +
                                            _vm._s(flow.alias) +
                                            "\n                  "
                                        ),
                                      ]
                                    )
                                  }
                                ),
                                0
                              ),
                              _vm._v(" "),
                              _c("td", [_vm._v(_vm._s(dataFlowToMerge.id))]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(dataFlowToMerge.resourceName)),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(dataFlowToMerge.frequency)),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(
                                  _vm._s(
                                    dataFlowToMerge.format
                                      ? dataFlowToMerge.format.name
                                      : ""
                                  )
                                ),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(dataFlowToMerge.resourceType)),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                dataFlowToMerge.contractURL
                                  ? _c("span", [
                                      _c(
                                        "a",
                                        {
                                          attrs: {
                                            href: dataFlowToMerge.contractURL,
                                            title:
                                              "dataFlow " +
                                              dataFlowToMerge.id +
                                              " : " +
                                              dataFlowToMerge.resourceName,
                                            target: "_blank",
                                          },
                                        },
                                        [
                                          _vm._v(
                                            _vm._s(dataFlowToMerge.contractURL)
                                          ),
                                        ]
                                      ),
                                    ])
                                  : _vm._e(),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                dataFlowToMerge.documentationURL
                                  ? _c("span", [
                                      _c(
                                        "a",
                                        {
                                          attrs: {
                                            href: dataFlowToMerge.documentationURL,
                                            title: dataFlowToMerge.resourceName,
                                            target: "_blank",
                                          },
                                        },
                                        [
                                          _vm._v(
                                            _vm._s(
                                              dataFlowToMerge.documentationURL
                                            )
                                          ),
                                        ]
                                      ),
                                    ])
                                  : _vm._e(),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(dataFlowToMerge.startDate)),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(dataFlowToMerge.endDate)),
                              ]),
                              _vm._v(" "),
                              _c(
                                "td",
                                { attrs: { title: "dataFlow description" } },
                                [_vm._v(_vm._s(dataFlowToMerge.description))]
                              ),
                            ]
                          ),
                        ]
                      }),
                    ]
                  }),
                ],
                2
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { attrs: { slot: "modal-footer" }, slot: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: { type: "button" },
                on: {
                  click: function ($event) {
                    return _vm.closeMergeDialog()
                  },
                },
              },
              [_vm._v("Cancel")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                ref: "mergeflowInterfaceButtonRef",
                staticClass: "btn btn-primary",
                attrs: {
                  type: "button",
                  id: "mergeflowInterfaceButtonID",
                  "data-cy": "entityConfirmDeleteButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.mergeFlowInterface()
                  },
                },
              },
              [_vm._v("\n        Merge\n      ")]
            ),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Alias")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Flows")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Status")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Documentation URL")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Documentation URL 2")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Start Date")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("End Date")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Source")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Target")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Source Component")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Target Component")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Protocol")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Owner")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Data Flow")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./reporting-flow-interface.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/reporting-flow-interface.vue?vue&type=style&index=0&lang=css&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(/*! !../../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js")["default"])
var update = add("0fa89d54", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_flow-interface_reporting-flow-interface_vue.js.map