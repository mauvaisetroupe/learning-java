"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_landscape-view_landscape-view-update_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/landscape-view/landscape-view-update.component.ts?vue&type=script&lang=ts&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/landscape-view/landscape-view-update.component.ts?vue&type=script&lang=ts& ***!
  \***************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vue_class_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-class-component */ "./node_modules/vue-class-component/dist/vue-class-component.esm.js");
/* harmony import */ var _shared_data_data_utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/shared/data/data-utils.service */ "./src/main/webapp/app/shared/data/data-utils.service.ts");
/* harmony import */ var _shared_model_landscape_view_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/shared/model/landscape-view.model */ "./src/main/webapp/app/shared/model/landscape-view.model.ts");
/* harmony import */ var _shared_model_enumerations_view_point_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/shared/model/enumerations/view-point.model */ "./src/main/webapp/app/shared/model/enumerations/view-point.model.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var validations = {
    landscapeView: {
        viewpoint: {},
        diagramName: {},
        compressedDrawXML: {},
        compressedDrawSVG: {},
    },
};
var LandscapeViewUpdate = /** @class */ (function (_super) {
    __extends(LandscapeViewUpdate, _super);
    function LandscapeViewUpdate() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.landscapeView = new _shared_model_landscape_view_model__WEBPACK_IMPORTED_MODULE_2__.LandscapeView();
        _this.owners = [];
        _this.functionalFlows = [];
        _this.capabilities = [];
        _this.viewPointValues = Object.keys(_shared_model_enumerations_view_point_model__WEBPACK_IMPORTED_MODULE_3__.ViewPoint);
        _this.isSaving = false;
        _this.currentLanguage = '';
        return _this;
    }
    LandscapeViewUpdate.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.landscapeViewId) {
                vm.retrieveLandscapeView(to.params.landscapeViewId);
            }
            vm.initRelationships();
        });
    };
    LandscapeViewUpdate.prototype.created = function () {
        var _this = this;
        this.currentLanguage = this.$store.getters.currentLanguage;
        this.$store.watch(function () { return _this.$store.getters.currentLanguage; }, function () {
            _this.currentLanguage = _this.$store.getters.currentLanguage;
        });
        this.landscapeView.flows = [];
        this.landscapeView.capabilities = [];
    };
    LandscapeViewUpdate.prototype.save = function () {
        var _this = this;
        this.isSaving = true;
        if (this.landscapeView.id) {
            this.landscapeViewService()
                .update(this.landscapeView)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A LandscapeView is updated with identifier ' + param.id;
                return _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Info',
                    variant: 'info',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
        else {
            this.landscapeViewService()
                .create(this.landscapeView)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A LandscapeView is created with identifier ' + param.id;
                _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Success',
                    variant: 'success',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
    };
    LandscapeViewUpdate.prototype.retrieveLandscapeView = function (landscapeViewId) {
        var _this = this;
        this.landscapeViewService()
            .find(landscapeViewId)
            .then(function (res) {
            _this.landscapeView = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    LandscapeViewUpdate.prototype.previousState = function () {
        this.$router.go(-1);
    };
    LandscapeViewUpdate.prototype.initRelationships = function () {
        var _this = this;
        this.ownerService()
            .retrieve()
            .then(function (res) {
            _this.owners = res.data;
        });
        this.functionalFlowService()
            .retrieve()
            .then(function (res) {
            _this.functionalFlows = res.data;
        });
        this.capabilityService()
            .retrieve()
            .then(function (res) {
            _this.capabilities = res.data;
        });
    };
    LandscapeViewUpdate.prototype.getSelected = function (selectedVals, option) {
        var _a;
        if (selectedVals) {
            return (_a = selectedVals.find(function (value) { return option.id === value.id; })) !== null && _a !== void 0 ? _a : option;
        }
        return option;
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('landscapeViewService'),
        __metadata("design:type", Function)
    ], LandscapeViewUpdate.prototype, "landscapeViewService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], LandscapeViewUpdate.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('ownerService'),
        __metadata("design:type", Function)
    ], LandscapeViewUpdate.prototype, "ownerService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowService'),
        __metadata("design:type", Function)
    ], LandscapeViewUpdate.prototype, "functionalFlowService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('capabilityService'),
        __metadata("design:type", Function)
    ], LandscapeViewUpdate.prototype, "capabilityService", void 0);
    LandscapeViewUpdate = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            validations: validations,
        })
    ], LandscapeViewUpdate);
    return LandscapeViewUpdate;
}((0,vue_class_component__WEBPACK_IMPORTED_MODULE_4__.mixins)(_shared_data_data_utils_service__WEBPACK_IMPORTED_MODULE_1__["default"])));
/* harmony default export */ __webpack_exports__["default"] = (LandscapeViewUpdate);


/***/ }),

/***/ "./src/main/webapp/app/shared/data/data-utils.service.ts":
/*!***************************************************************!*\
  !*** ./src/main/webapp/app/shared/data/data-utils.service.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

/**
 * An utility service for data.
 */
var JhiDataUtils = /** @class */ (function (_super) {
    __extends(JhiDataUtils, _super);
    function JhiDataUtils() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * Method to abbreviate the text given
     */
    JhiDataUtils.prototype.abbreviate = function (text, append) {
        if (append === void 0) { append = '...'; }
        if (text.length < 30) {
            return text;
        }
        return text ? text.substring(0, 15) + append + text.slice(-10) : '';
    };
    /**
     * Method to find the byte size of the string provides
     */
    JhiDataUtils.prototype.byteSize = function (base64String) {
        return this.formatAsBytes(this.size(base64String));
    };
    /**
     * Method to open file
     */
    JhiDataUtils.prototype.openFile = function (contentType, data) {
        var byteCharacters = atob(data);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], {
            type: contentType,
        });
        var objectURL = URL.createObjectURL(blob);
        var win = window.open(objectURL);
        if (win) {
            win.onload = function () { return URL.revokeObjectURL(objectURL); };
        }
    };
    /**
     * Method to convert the file to base64
     */
    JhiDataUtils.prototype.toBase64 = function (file, cb) {
        var fileReader = new FileReader();
        fileReader.readAsDataURL(file);
        fileReader.onload = function (e) {
            var base64Data = e.target.result.substr(e.target.result.indexOf('base64,') + 'base64,'.length);
            cb(base64Data);
        };
    };
    /**
     * Method to clear the input
     */
    JhiDataUtils.prototype.clearInputImage = function (entity, elementRef, field, fieldContentType, idInput) {
        if (entity && field && fieldContentType) {
            if (Object.prototype.hasOwnProperty.call(entity, field)) {
                entity[field] = null;
            }
            if (Object.prototype.hasOwnProperty.call(entity, fieldContentType)) {
                entity[fieldContentType] = null;
            }
            if (elementRef && idInput && elementRef.nativeElement.querySelector('#' + idInput)) {
                elementRef.nativeElement.querySelector('#' + idInput).value = null;
            }
        }
    };
    JhiDataUtils.prototype.endsWith = function (suffix, str) {
        return str.indexOf(suffix, str.length - suffix.length) !== -1;
    };
    JhiDataUtils.prototype.paddingSize = function (value) {
        if (this.endsWith('==', value)) {
            return 2;
        }
        if (this.endsWith('=', value)) {
            return 1;
        }
        return 0;
    };
    JhiDataUtils.prototype.size = function (value) {
        return (value.length / 4) * 3 - this.paddingSize(value);
    };
    JhiDataUtils.prototype.formatAsBytes = function (size) {
        return size.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' bytes';
    };
    JhiDataUtils.prototype.setFileData = function (event, entity, field, isImage) {
        if (event && event.target.files && event.target.files[0]) {
            var file_1 = event.target.files[0];
            if (isImage && !/^image\//.test(file_1.type)) {
                return;
            }
            this.toBase64(file_1, function (base64Data) {
                entity[field] = base64Data;
                entity["".concat(field, "ContentType")] = file_1.type;
            });
        }
    };
    /**
     * Method to download file
     */
    JhiDataUtils.prototype.downloadFile = function (contentType, data, fileName) {
        var byteCharacters = atob(data);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], {
            type: contentType,
        });
        var tempLink = document.createElement('a');
        tempLink.href = window.URL.createObjectURL(blob);
        tempLink.download = fileName;
        tempLink.target = '_blank';
        tempLink.click();
    };
    /**
     * Method to parse header links
     */
    JhiDataUtils.prototype.parseLinks = function (header) {
        var links = {};
        if (header === null || header.indexOf(',') === -1) {
            return links;
        }
        // Split parts by comma
        var parts = header.split(',');
        // Parse each part into a named link
        parts.forEach(function (p) {
            if (p.indexOf('>;') === -1) {
                return;
            }
            var section = p.split('>;');
            var url = section[0].replace(/<(.*)/, '$1').trim();
            var queryString = { page: null };
            url.replace(new RegExp(/([^?=&]+)(=([^&]*))?/g), function ($0, $1, $2, $3) {
                queryString[$1] = $3;
            });
            var page = queryString.page;
            if (typeof page === 'string') {
                page = parseInt(page, 10);
            }
            var name = section[1].replace(/rel="(.*)"/, '$1').trim();
            links[name] = page;
        });
        return links;
    };
    JhiDataUtils = __decorate([
        vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component
    ], JhiDataUtils);
    return JhiDataUtils;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (JhiDataUtils);


/***/ }),

/***/ "./src/main/webapp/app/shared/model/enumerations/view-point.model.ts":
/*!***************************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/enumerations/view-point.model.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewPoint": function() { return /* binding */ ViewPoint; }
/* harmony export */ });
var ViewPoint;
(function (ViewPoint) {
    ViewPoint["APPLICATION_LANDSCAPE"] = "APPLICATION_LANDSCAPE";
})(ViewPoint || (ViewPoint = {}));


/***/ }),

/***/ "./src/main/webapp/app/shared/model/landscape-view.model.ts":
/*!******************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/landscape-view.model.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandscapeView": function() { return /* binding */ LandscapeView; }
/* harmony export */ });
var LandscapeView = /** @class */ (function () {
    function LandscapeView(id, viewpoint, diagramName, compressedDrawXML, compressedDrawSVG, owner, flows, capabilities) {
        this.id = id;
        this.viewpoint = viewpoint;
        this.diagramName = diagramName;
        this.compressedDrawXML = compressedDrawXML;
        this.compressedDrawSVG = compressedDrawSVG;
        this.owner = owner;
        this.flows = flows;
        this.capabilities = capabilities;
    }
    return LandscapeView;
}());



/***/ }),

/***/ "./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue":
/*!*******************************************************************************!*\
  !*** ./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _landscape_view_update_vue_vue_type_template_id_19ffcf32___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./landscape-view-update.vue?vue&type=template&id=19ffcf32& */ "./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue?vue&type=template&id=19ffcf32&");
/* harmony import */ var _landscape_view_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./landscape-view-update.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/landscape-view/landscape-view-update.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _landscape_view_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _landscape_view_update_vue_vue_type_template_id_19ffcf32___WEBPACK_IMPORTED_MODULE_0__.render,
  _landscape_view_update_vue_vue_type_template_id_19ffcf32___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/landscape-view/landscape-view-update.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/landscape-view/landscape-view-update.component.ts?vue&type=script&lang=ts&":
/*!*****************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/landscape-view/landscape-view-update.component.ts?vue&type=script&lang=ts& ***!
  \*****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_landscape_view_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./landscape-view-update.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/landscape-view/landscape-view-update.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_landscape_view_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue?vue&type=template&id=19ffcf32&":
/*!**************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue?vue&type=template&id=19ffcf32& ***!
  \**************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_update_vue_vue_type_template_id_19ffcf32___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_update_vue_vue_type_template_id_19ffcf32___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_update_vue_vue_type_template_id_19ffcf32___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./landscape-view-update.vue?vue&type=template&id=19ffcf32& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue?vue&type=template&id=19ffcf32&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue?vue&type=template&id=19ffcf32&":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-update.vue?vue&type=template&id=19ffcf32& ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row justify-content-center" }, [
    _c("div", { staticClass: "col-8" }, [
      _c(
        "form",
        {
          attrs: { name: "editForm", role: "form", novalidate: "" },
          on: {
            submit: function ($event) {
              $event.preventDefault()
              return _vm.save()
            },
          },
        },
        [
          _c(
            "h2",
            {
              attrs: {
                id: "eaDesignItApp.landscapeView.home.createOrEditLabel",
                "data-cy": "LandscapeViewCreateUpdateHeading",
              },
            },
            [
              _c("font-awesome-icon", {
                staticStyle: { color: "Tomato", "font-size": "0.7em" },
                attrs: { icon: "map" },
              }),
              _vm._v(" Create or edit a LandscapeView\n      "),
            ],
            1
          ),
          _vm._v(" "),
          _c("div", [
            _vm.landscapeView.id
              ? _c("div", { staticClass: "form-group" }, [
                  _c("label", { attrs: { for: "id" } }, [_vm._v("ID")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.landscapeView.id,
                        expression: "landscapeView.id",
                      },
                    ],
                    staticClass: "form-control",
                    attrs: { type: "text", id: "id", name: "id", readonly: "" },
                    domProps: { value: _vm.landscapeView.id },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.landscapeView, "id", $event.target.value)
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "landscape-view-viewpoint" },
                },
                [_vm._v("Viewpoint")]
              ),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.$v.landscapeView.viewpoint.$model,
                      expression: "$v.landscapeView.viewpoint.$model",
                    },
                  ],
                  staticClass: "form-control",
                  class: {
                    valid: !_vm.$v.landscapeView.viewpoint.$invalid,
                    invalid: _vm.$v.landscapeView.viewpoint.$invalid,
                  },
                  attrs: {
                    name: "viewpoint",
                    id: "landscape-view-viewpoint",
                    "data-cy": "viewpoint",
                  },
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.$v.landscapeView.viewpoint,
                        "$model",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                _vm._l(_vm.viewPointValues, function (viewPoint) {
                  return _c(
                    "option",
                    { key: viewPoint, domProps: { value: viewPoint } },
                    [_vm._v(_vm._s(viewPoint))]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "landscape-view-diagramName" },
                },
                [_vm._v("Diagram Name")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.landscapeView.diagramName.$model,
                    expression: "$v.landscapeView.diagramName.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.landscapeView.diagramName.$invalid,
                  invalid: _vm.$v.landscapeView.diagramName.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "diagramName",
                  id: "landscape-view-diagramName",
                  "data-cy": "diagramName",
                },
                domProps: { value: _vm.$v.landscapeView.diagramName.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.landscapeView.diagramName,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "landscape-view-owner" },
                },
                [_vm._v("Owner")]
              ),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.landscapeView.owner,
                      expression: "landscapeView.owner",
                    },
                  ],
                  staticClass: "form-control",
                  attrs: {
                    id: "landscape-view-owner",
                    "data-cy": "owner",
                    name: "owner",
                  },
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.landscapeView,
                        "owner",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                [
                  _c("option", { domProps: { value: null } }),
                  _vm._v(" "),
                  _vm._l(_vm.owners, function (ownerOption) {
                    return _c(
                      "option",
                      {
                        key: ownerOption.id,
                        domProps: {
                          value:
                            _vm.landscapeView.owner &&
                            ownerOption.id === _vm.landscapeView.owner.id
                              ? _vm.landscapeView.owner
                              : ownerOption,
                        },
                      },
                      [
                        _vm._v(
                          "\n              " +
                            _vm._s(ownerOption.name) +
                            "\n            "
                        ),
                      ]
                    )
                  }),
                ],
                2
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("div", [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: {
                  type: "button",
                  id: "cancel-save",
                  "data-cy": "entityCreateCancelButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.previousState()
                  },
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "ban" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Cancel")]),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "submit",
                  id: "save-entity",
                  "data-cy": "entityCreateSaveButton",
                  disabled: _vm.$v.landscapeView.$invalid || _vm.isSaving,
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "save" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Save")]),
              ],
              1
            ),
          ]),
        ]
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_landscape-view_landscape-view-update_vue.js.map