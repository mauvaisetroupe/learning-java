"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_functional-flow_functional-flow_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/functional-flow/functional-flow.component.ts?vue&type=script&lang=ts&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/functional-flow/functional-flow.component.ts?vue&type=script&lang=ts& ***!
  \**********************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vue2_filters__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue2-filters */ "./node_modules/vue2-filters/dist/vue2-filters.js");
/* harmony import */ var vue2_filters__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue2_filters__WEBPACK_IMPORTED_MODULE_1__);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FunctionalFlow = /** @class */ (function (_super) {
    __extends(FunctionalFlow, _super);
    function FunctionalFlow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.removeId = null;
        _this.functionalFlows = [];
        _this.isFetching = false;
        _this.filter = '';
        _this.deleteInterfaces = true;
        _this.deleteDatas = true;
        return _this;
    }
    FunctionalFlow.prototype.deleteCoherence = function () {
        if (!this.deleteInterfaces) {
            this.deleteDatas = false;
        }
    };
    FunctionalFlow.prototype.mounted = function () {
        this.retrieveAllFunctionalFlows();
    };
    FunctionalFlow.prototype.clear = function () {
        this.retrieveAllFunctionalFlows();
    };
    FunctionalFlow.prototype.retrieveAllFunctionalFlows = function () {
        var _this = this;
        this.isFetching = true;
        this.functionalFlowService()
            .retrieve()
            .then(function (res) {
            _this.functionalFlows = res.data;
            _this.isFetching = false;
        }, function (err) {
            _this.isFetching = false;
            _this.alertService().showHttpError(_this, err.response);
        });
    };
    FunctionalFlow.prototype.handleSyncList = function () {
        this.clear();
    };
    FunctionalFlow.prototype.prepareRemove = function (instance) {
        this.removeId = instance.id;
        if (this.$refs.removeEntity) {
            this.$refs.removeEntity.show();
        }
    };
    FunctionalFlow.prototype.removeFunctionalFlow = function () {
        var _this = this;
        this.functionalFlowService()
            .delete(this.removeId, this.deleteInterfaces, this.deleteDatas)
            .then(function () {
            var message = 'A FunctionalFlow is deleted with identifier ' + _this.removeId;
            _this.$bvToast.toast(message.toString(), {
                toaster: 'b-toaster-top-center',
                title: 'Info',
                variant: 'danger',
                solid: true,
                autoHideDelay: 5000,
            });
            _this.removeId = null;
            _this.retrieveAllFunctionalFlows();
            _this.closeDialog();
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    FunctionalFlow.prototype.closeDialog = function () {
        this.$refs.removeEntity.hide();
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowService'),
        __metadata("design:type", Function)
    ], FunctionalFlow.prototype, "functionalFlowService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], FunctionalFlow.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('accountService'),
        __metadata("design:type", Function)
    ], FunctionalFlow.prototype, "accountService", void 0);
    FunctionalFlow = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            mixins: [(vue2_filters__WEBPACK_IMPORTED_MODULE_1___default().mixin)],
        }),
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            computed: {
                filteredRows: function () {
                    var _this = this;
                    return this.functionalFlows.filter(function (row) {
                        var alias = row.alias ? row.alias.toString().toLowerCase() : '';
                        var id = row.id.toString().toLowerCase();
                        var description = row.description ? row.description.toString().toLowerCase() : '';
                        var inFFF = row.steps
                            .map(function (i) { return i.flowInterface; })
                            .map(function (i) { return i.alias; })
                            .join(' ')
                            .toString()
                            .toLowerCase();
                        var searchTerm = _this.filter.toLowerCase();
                        return alias.includes(searchTerm) || id.includes(searchTerm) || inFFF.includes(searchTerm) || description.includes(searchTerm);
                    });
                },
            },
        })
    ], FunctionalFlow);
    return FunctionalFlow;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (FunctionalFlow);


/***/ }),

/***/ "./src/main/webapp/app/entities/functional-flow/functional-flow.vue":
/*!**************************************************************************!*\
  !*** ./src/main/webapp/app/entities/functional-flow/functional-flow.vue ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _functional_flow_vue_vue_type_template_id_a3c4ca74___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./functional-flow.vue?vue&type=template&id=a3c4ca74& */ "./src/main/webapp/app/entities/functional-flow/functional-flow.vue?vue&type=template&id=a3c4ca74&");
/* harmony import */ var _functional_flow_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./functional-flow.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/functional-flow/functional-flow.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _functional_flow_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _functional_flow_vue_vue_type_template_id_a3c4ca74___WEBPACK_IMPORTED_MODULE_0__.render,
  _functional_flow_vue_vue_type_template_id_a3c4ca74___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/functional-flow/functional-flow.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/functional-flow/functional-flow.component.ts?vue&type=script&lang=ts&":
/*!************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/functional-flow/functional-flow.component.ts?vue&type=script&lang=ts& ***!
  \************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_functional_flow_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./functional-flow.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/functional-flow/functional-flow.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_functional_flow_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/functional-flow/functional-flow.vue?vue&type=template&id=a3c4ca74&":
/*!*********************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/functional-flow/functional-flow.vue?vue&type=template&id=a3c4ca74& ***!
  \*********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_vue_vue_type_template_id_a3c4ca74___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_vue_vue_type_template_id_a3c4ca74___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_vue_vue_type_template_id_a3c4ca74___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./functional-flow.vue?vue&type=template&id=a3c4ca74& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow.vue?vue&type=template&id=a3c4ca74&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow.vue?vue&type=template&id=a3c4ca74&":
/*!************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow.vue?vue&type=template&id=a3c4ca74& ***!
  \************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "h2",
        { attrs: { id: "page-heading", "data-cy": "FunctionalFlowHeading" } },
        [
          _c(
            "span",
            { attrs: { id: "functional-flow-heading" } },
            [
              _c("font-awesome-icon", {
                staticStyle: { color: "Tomato", "font-size": "0.7em" },
                attrs: { icon: "project-diagram" },
              }),
              _vm._v(" Functional Flows"),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "d-flex justify-content-end" },
            [
              _c(
                "button",
                {
                  staticClass: "btn btn-info mr-2",
                  attrs: { disabled: _vm.isFetching },
                  on: { click: _vm.handleSyncList },
                },
                [
                  _c("font-awesome-icon", {
                    attrs: { icon: "sync", spin: _vm.isFetching },
                  }),
                  _vm._v(" "),
                  _c("span", [_vm._v("Refresh List")]),
                ],
                1
              ),
              _vm._v(" "),
              _vm.accountService().writeAuthorities
                ? _c("router-link", {
                    attrs: { to: { name: "FunctionalFlowCreate" }, custom: "" },
                    scopedSlots: _vm._u(
                      [
                        {
                          key: "default",
                          fn: function (ref) {
                            var navigate = ref.navigate
                            return [
                              _c(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-primary jh-create-entity create-functional-flow",
                                  attrs: {
                                    id: "jh-create-entity",
                                    "data-cy": "entityCreateButton",
                                  },
                                  on: { click: navigate },
                                },
                                [
                                  _c("font-awesome-icon", {
                                    attrs: { icon: "plus" },
                                  }),
                                  _vm._v(" "),
                                  _c("span", [
                                    _vm._v(" Create a new Functional Flow "),
                                  ]),
                                ],
                                1
                              ),
                            ]
                          },
                        },
                      ],
                      null,
                      false,
                      662728908
                    ),
                  })
                : _vm._e(),
            ],
            1
          ),
        ]
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      !_vm.isFetching && _vm.functionalFlows && _vm.functionalFlows.length === 0
        ? _c("div", { staticClass: "alert alert-warning" }, [
            _c("span", [_vm._v("No functionalFlows found")]),
          ])
        : _vm._e(),
      _vm._v(" "),
      _c("div", [
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.filter,
              expression: "filter",
            },
          ],
          attrs: { type: "text", placeholder: "Filter by text" },
          domProps: { value: _vm.filter },
          on: {
            input: function ($event) {
              if ($event.target.composing) {
                return
              }
              _vm.filter = $event.target.value
            },
          },
        }),
      ]),
      _vm._v(" "),
      _vm.functionalFlows && _vm.functionalFlows.length > 0
        ? _c("div", { staticClass: "table-responsive" }, [
            _c(
              "table",
              {
                staticClass: "table table-striped",
                attrs: { "aria-describedby": "functionalFlows" },
              },
              [
                _vm._m(0),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.filteredRows, function (functionalFlow) {
                    return _c(
                      "tr",
                      {
                        key: functionalFlow.id,
                        attrs: { "data-cy": "entityTable" },
                      },
                      [
                        _c(
                          "td",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "FunctionalFlowView",
                                    params: {
                                      functionalFlowId: functionalFlow.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(functionalFlow.id))]
                            ),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(functionalFlow.alias))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(functionalFlow.description))]),
                        _vm._v(" "),
                        _c("td", [
                          _vm._v(
                            _vm._s(
                              functionalFlow.comment
                                ? functionalFlow.comment.substring(0, 30)
                                : ""
                            )
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(functionalFlow.status))]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "a",
                            {
                              attrs: { href: functionalFlow.documentationURL },
                            },
                            [
                              _vm._v(
                                _vm._s(
                                  functionalFlow.documentationURL
                                    ? functionalFlow.documentationURL.substring(
                                        0,
                                        20
                                      )
                                    : ""
                                )
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "a",
                            {
                              attrs: { href: functionalFlow.documentationURL2 },
                            },
                            [
                              _vm._v(
                                _vm._s(
                                  functionalFlow.documentationURL2
                                    ? functionalFlow.documentationURL2.substring(
                                        0,
                                        20
                                      )
                                    : ""
                                )
                              ),
                            ]
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(functionalFlow.startDate))]),
                        _vm._v(" "),
                        _c("td", [_vm._v(_vm._s(functionalFlow.endDate))]),
                        _vm._v(" "),
                        _c("td", [
                          functionalFlow.owner
                            ? _c(
                                "div",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "OwnerView",
                                          params: {
                                            ownerId: functionalFlow.owner.id,
                                          },
                                        },
                                      },
                                    },
                                    [_vm._v(_vm._s(functionalFlow.owner.name))]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ]),
                        _vm._v(" "),
                        _c(
                          "td",
                          _vm._l(functionalFlow.steps, function (step, i) {
                            return _c(
                              "span",
                              { key: step.id },
                              [
                                _vm._v(
                                  _vm._s(i > 0 ? ", " : "") + "\n              "
                                ),
                                _c(
                                  "router-link",
                                  {
                                    staticClass: "form-control-static",
                                    attrs: {
                                      title:
                                        "[ " +
                                        step.flowInterface.source.name +
                                        " / " +
                                        step.flowInterface.target.name +
                                        " ]" +
                                        (step.flowInterface.protocol
                                          ? " (" +
                                            step.flowInterface.protocol.type +
                                            ") "
                                          : ""),
                                      to: {
                                        name: "FlowInterfaceView",
                                        params: {
                                          flowInterfaceId:
                                            step.flowInterface.id,
                                        },
                                      },
                                    },
                                  },
                                  [_vm._v(_vm._s(step.flowInterface.alias))]
                                ),
                              ],
                              1
                            )
                          }),
                          0
                        ),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-right" }, [
                          _c(
                            "div",
                            { staticClass: "btn-group" },
                            [
                              _c("router-link", {
                                attrs: {
                                  to: {
                                    name: "FunctionalFlowView",
                                    params: {
                                      functionalFlowId: functionalFlow.id,
                                    },
                                  },
                                  custom: "",
                                },
                                scopedSlots: _vm._u(
                                  [
                                    {
                                      key: "default",
                                      fn: function (ref) {
                                        var navigate = ref.navigate
                                        return [
                                          _c(
                                            "button",
                                            {
                                              staticClass:
                                                "btn btn-info btn-sm details",
                                              attrs: {
                                                "data-cy":
                                                  "entityDetailsButton",
                                              },
                                              on: { click: navigate },
                                            },
                                            [
                                              _c("font-awesome-icon", {
                                                attrs: { icon: "eye" },
                                              }),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "d-none d-md-inline",
                                                },
                                                [_vm._v("View")]
                                              ),
                                            ],
                                            1
                                          ),
                                        ]
                                      },
                                    },
                                  ],
                                  null,
                                  true
                                ),
                              }),
                              _vm._v(" "),
                              _vm.accountService().writeAuthorities
                                ? _c("router-link", {
                                    attrs: {
                                      to: {
                                        name: "FunctionalFlowEdit",
                                        params: {
                                          functionalFlowId: functionalFlow.id,
                                        },
                                      },
                                      custom: "",
                                    },
                                    scopedSlots: _vm._u(
                                      [
                                        {
                                          key: "default",
                                          fn: function (ref) {
                                            var navigate = ref.navigate
                                            return [
                                              _c(
                                                "button",
                                                {
                                                  staticClass:
                                                    "btn btn-primary btn-sm edit",
                                                  attrs: {
                                                    "data-cy":
                                                      "entityEditButton",
                                                  },
                                                  on: { click: navigate },
                                                },
                                                [
                                                  _c("font-awesome-icon", {
                                                    attrs: {
                                                      icon: "pencil-alt",
                                                    },
                                                  }),
                                                  _vm._v(" "),
                                                  _c(
                                                    "span",
                                                    {
                                                      staticClass:
                                                        "d-none d-md-inline",
                                                    },
                                                    [_vm._v("Edit")]
                                                  ),
                                                ],
                                                1
                                              ),
                                            ]
                                          },
                                        },
                                      ],
                                      null,
                                      true
                                    ),
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.accountService().deleteAuthorities
                                ? _c(
                                    "b-button",
                                    {
                                      directives: [
                                        {
                                          name: "b-modal",
                                          rawName: "v-b-modal.removeEntity",
                                          modifiers: { removeEntity: true },
                                        },
                                      ],
                                      staticClass: "btn btn-sm",
                                      attrs: {
                                        variant: "danger",
                                        "data-cy": "entityDeleteButton",
                                        disabled:
                                          functionalFlow.landscapes &&
                                          functionalFlow.landscapes.length > 0,
                                        title:
                                          !functionalFlow.landscapes ||
                                          functionalFlow.landscapes.length == 0
                                            ? ""
                                            : "Cannot be deleted, please detache from all landscapes first",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.prepareRemove(
                                            functionalFlow
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c("font-awesome-icon", {
                                        attrs: { icon: "times" },
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "span",
                                        { staticClass: "d-none d-md-inline" },
                                        [_vm._v("Delete")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ]),
                      ]
                    )
                  }),
                  0
                ),
              ]
            ),
          ])
        : _vm._e(),
      _vm._v(" "),
      _c("b-modal", { ref: "removeEntity", attrs: { id: "removeEntity" } }, [
        _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
          _c(
            "span",
            {
              attrs: {
                id: "eaDesignItApp.functionalFlow.delete.question",
                "data-cy": "functionalFlowDeleteDialogHeading",
              },
            },
            [_vm._v("Confirm delete operation")]
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "modal-body" }, [
          _c("p", { attrs: { id: "jhi-delete-functionalFlow-heading" } }, [
            _vm._v("Are you sure you want to delete this Functional Flow?"),
          ]),
          _vm._v(" "),
          _c("p", [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.deleteInterfaces,
                  expression: "deleteInterfaces",
                },
              ],
              attrs: { type: "checkbox" },
              domProps: {
                checked: Array.isArray(_vm.deleteInterfaces)
                  ? _vm._i(_vm.deleteInterfaces, null) > -1
                  : _vm.deleteInterfaces,
              },
              on: {
                change: [
                  function ($event) {
                    var $$a = _vm.deleteInterfaces,
                      $$el = $event.target,
                      $$c = $$el.checked ? true : false
                    if (Array.isArray($$a)) {
                      var $$v = null,
                        $$i = _vm._i($$a, $$v)
                      if ($$el.checked) {
                        $$i < 0 && (_vm.deleteInterfaces = $$a.concat([$$v]))
                      } else {
                        $$i > -1 &&
                          (_vm.deleteInterfaces = $$a
                            .slice(0, $$i)
                            .concat($$a.slice($$i + 1)))
                      }
                    } else {
                      _vm.deleteInterfaces = $$c
                    }
                  },
                  function ($event) {
                    return _vm.deleteCoherence()
                  },
                ],
              },
            }),
            _vm._v(" Delete unused Interfaces"),
          ]),
          _vm._v(" "),
          _c("p", [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.deleteDatas,
                  expression: "deleteDatas",
                },
              ],
              attrs: { type: "checkbox", disabled: !_vm.deleteInterfaces },
              domProps: {
                checked: Array.isArray(_vm.deleteDatas)
                  ? _vm._i(_vm.deleteDatas, null) > -1
                  : _vm.deleteDatas,
              },
              on: {
                change: [
                  function ($event) {
                    var $$a = _vm.deleteDatas,
                      $$el = $event.target,
                      $$c = $$el.checked ? true : false
                    if (Array.isArray($$a)) {
                      var $$v = null,
                        $$i = _vm._i($$a, $$v)
                      if ($$el.checked) {
                        $$i < 0 && (_vm.deleteDatas = $$a.concat([$$v]))
                      } else {
                        $$i > -1 &&
                          (_vm.deleteDatas = $$a
                            .slice(0, $$i)
                            .concat($$a.slice($$i + 1)))
                      }
                    } else {
                      _vm.deleteDatas = $$c
                    }
                  },
                  function ($event) {
                    return _vm.deleteCoherence()
                  },
                ],
              },
            }),
            _vm._v(
              " Delete unused Data Flows\n        & Data Flow Items\n      "
            ),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { attrs: { slot: "modal-footer" }, slot: "modal-footer" }, [
          _c(
            "button",
            {
              staticClass: "btn btn-secondary",
              attrs: { type: "button" },
              on: {
                click: function ($event) {
                  return _vm.closeDialog()
                },
              },
            },
            [_vm._v("Cancel")]
          ),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "btn btn-primary",
              attrs: {
                type: "button",
                id: "jhi-confirm-delete-functionalFlow",
                "data-cy": "entityConfirmDeleteButton",
              },
              on: {
                click: function ($event) {
                  return _vm.removeFunctionalFlow()
                },
              },
            },
            [_vm._v("\n        Delete\n      ")]
          ),
        ]),
      ]),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("ID")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Alias")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Description")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Comment")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Status")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Documentation URL")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Documentation URL 2")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Start Date")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("End Date")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Owner")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }),
      ]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_functional-flow_functional-flow_vue.js.map