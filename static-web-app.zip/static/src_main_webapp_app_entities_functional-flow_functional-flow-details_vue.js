(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_functional-flow_functional-flow-details_vue"],{

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.modal-dialog {\n  max-width: 80%;\n}\n.fa-project-diagram g g path {\n  stroke: red;\n  stroke-width: 10;\n}\n", "",{"version":3,"sources":["webpack://./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue"],"names":[],"mappings":";AAsbA;EACA,cAAA;AACA;AACA;EACA,WAAA;EACA,gBAAA;AACA","sourcesContent":["<template>\n  <div class=\"row justify-content-center\">\n    <div class=\"col-8\">\n      <div v-if=\"functionalFlow\">\n        <h2 class=\"jh-entity-heading\" data-cy=\"functionalFlowDetailsHeading\">\n          <font-awesome-icon icon=\"project-diagram\" style=\"color: Tomato; font-size: 0.7em\"></font-awesome-icon>\n          <span>Functional Flow</span> - {{ functionalFlow.alias }}\n        </h2>\n        <dl class=\"row jh-entity-details\">\n          <dt>\n            <span>Alias</span>\n          </dt>\n          <dd>\n            <span>{{ functionalFlow.alias }}</span>\n          </dd>\n          <dt>\n            <span>Description</span>\n          </dt>\n          <dd>\n            <span>{{ functionalFlow.description }}</span>\n          </dd>\n          <dt>\n            <span>Comment</span>\n          </dt>\n          <dd>\n            <span>{{ functionalFlow.comment }}</span>\n          </dd>\n          <dt>\n            <span>Status</span>\n          </dt>\n          <dd>\n            <span>{{ functionalFlow.status }}</span>\n          </dd>\n          <dt>\n            <span>Documentation URL</span>\n          </dt>\n          <dd>\n            <span\n              ><a v-bind:href=\"functionalFlow.documentationURL\">{{ functionalFlow.documentationURL }}</a></span\n            >\n          </dd>\n          <dt>\n            <span>Documentation URL 2</span>\n          </dt>\n          <dd>\n            <span\n              ><a v-bind:href=\"functionalFlow.documentationURL2\">{{ functionalFlow.documentationURL2 }}</a></span\n            >\n          </dd>\n          <dt>\n            <span>Start Date</span>\n          </dt>\n          <dd>\n            <span>{{ functionalFlow.startDate }}</span>\n          </dd>\n          <dt>\n            <span>End Date</span>\n          </dt>\n          <dd>\n            <span>{{ functionalFlow.endDate }}</span>\n          </dd>\n          <dt>\n            <span>Owner</span>\n          </dt>\n          <dd>\n            <div v-if=\"functionalFlow.owner\">\n              <router-link :to=\"{ name: 'OwnerView', params: { ownerId: functionalFlow.owner.id } }\">{{\n                functionalFlow.owner.name\n              }}</router-link>\n            </div>\n          </dd>\n        </dl>\n        <button type=\"submit\" v-on:click.prevent=\"previousState()\" class=\"btn btn-info\" data-cy=\"entityDetailsBackButton\">\n          <font-awesome-icon icon=\"arrow-left\"></font-awesome-icon>&nbsp;<span> Back</span>\n        </button>\n        <router-link\n          v-if=\"functionalFlow.id\"\n          :to=\"{ name: 'FunctionalFlowEdit', params: { functionalFlowId: functionalFlow.id } }\"\n          custom\n          v-slot=\"{ navigate }\"\n        >\n          <button @click=\"navigate\" class=\"btn btn-primary\" v-if=\"accountService().writeAuthorities\">\n            <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon>&nbsp;<span> Edit Information</span>\n          </button>\n        </router-link>\n      </div>\n\n      <br />\n\n      <h3>{{ functionalFlow.alias }} - {{ functionalFlow.description }}</h3>\n\n      <div>\n        <div v-html=\"plantUMLImage\"></div>\n        <div class=\"col-12\">\n          <!-- <button class=\"btn btn-success float-right\" v-on:click=\"exportDiagram()\" style=\"font-size: 0.7em; padding: 3px; margin: 3px\">\n            <font-awesome-icon icon=\"sync\"></font-awesome-icon> <span>Export</span>\n          </button>         -->\n          <button\n            class=\"btn btn-warning\"\n            v-on:click=\"changeDiagram()\"\n            style=\"font-size: 0.7em; padding: 3px; margin: 3px\"\n            :disabled=\"isFetching\"\n          >\n            <font-awesome-icon icon=\"sync\" :spin=\"isFetching\"></font-awesome-icon>\n            <span v-text=\"sequenceDiagram ? 'component diagram' : 'sequence diagram'\" />\n          </button>\n          <button\n            class=\"btn btn-warning\"\n            v-on:click=\"exportPlantUML()\"\n            style=\"font-size: 0.7em; padding: 3px; margin: 3px\"\n            v-if=\"plantUMLImage\"\n            :disabled=\"isFetching\"\n          >\n            <span>Export plantuml</span>\n          </button>\n        </div>\n      </div>\n      <div class=\"table-responsive\" v-if=\"functionalFlow.steps && functionalFlow.steps.length > 0\">\n        <table class=\"table table-striped\">\n          <thead>\n            <tr>\n              <th scope=\"row\"><span>Step</span></th>\n              <th scope=\"row\" v-if=\"reorderAlias\"></th>\n              <th scope=\"row\" v-if=\"reorderAlias\"></th>\n              <th scope=\"row\"><span>Interface</span></th>\n              <th scope=\"row\"><span>Source</span></th>\n              <th scope=\"row\"><span>Target</span></th>\n              <th scope=\"row\"><span>Protocol</span></th>\n              <th scope=\"row\"><span>Data Flows</span></th>\n              <th scope=\"row\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            <tr v-for=\"(step, i) in functionalFlow.steps\" v-bind:key=\"step.id\" :set=\"(inter = step.flowInterface)\">\n              <td>\n                {{ step.stepOrder }}.\n                <span v-if=\"!reorderAlias\">{{ step.description }}</span>\n                <span v-else>\n                  <textarea\n                    style=\"width: 100%; min-width: 600px\"\n                    rows=\"1\"\n                    v-model=\"step.description\"\n                    @change=\"changeStepDescription(functionalFlow, step)\"\n                  ></textarea>\n                </span>\n              </td>\n              <td v-if=\"reorderAlias\">\n                <font-awesome-icon icon=\"chevron-up\" class=\"btn-success\" v-if=\"i != 0\" @click=\"swap(i, i - 1)\"></font-awesome-icon>\n              </td>\n              <td v-if=\"reorderAlias\">\n                <font-awesome-icon\n                  icon=\"chevron-down\"\n                  class=\"btn-success\"\n                  v-if=\"i != functionalFlow.steps.length - 1\"\n                  @click=\"swap(i, i + 1)\"\n                ></font-awesome-icon>\n              </td>\n              <td>\n                <router-link :to=\"{ name: 'FlowInterfaceView', params: { flowInterfaceId: inter.id } }\">{{ inter.alias }}</router-link>\n              </td>\n              <td>\n                <router-link :to=\"{ name: 'ApplicationView', params: { applicationId: inter.source.id } }\">\n                  {{ inter.source.name }}\n                </router-link>\n              </td>\n              <td>\n                <router-link :to=\"{ name: 'ApplicationView', params: { applicationId: inter.target.id } }\">\n                  {{ inter.target.name }}\n                </router-link>\n              </td>\n              <td>\n                <router-link v-if=\"inter.protocol\" :to=\"{ name: 'ProtocolView', params: { protocolId: inter.protocol.id } }\">\n                  {{ inter.protocol.name }}\n                </router-link>\n              </td>\n              <td>\n                <span v-for=\"dataflow in inter.dataFlows\" :key=\"dataflow.id\">\n                  <router-link\n                    :to=\"{ name: 'DataFlowView', params: { dataFlowId: dataflow.id } }\"\n                    :title=\"dataflow.resourceName + (dataflow.items.length > 0 ? ' / ' + dataflow.items.length + ' items ' : ' / no items')\"\n                    >{{ dataflow.id }}</router-link\n                  ><sup v-if=\"dataflow.items && dataflow.items.length > 0\">({{ dataflow.items.length }})</sup>&nbsp;\n                </span>\n              </td>\n              <td class=\"text-right\">\n                <div class=\"btn-group\">\n                  <router-link :to=\"{ name: 'FlowInterfaceView', params: { flowInterfaceId: inter.id } }\" custom v-slot=\"{ navigate }\">\n                    <button\n                      @click=\"navigate\"\n                      class=\"btn btn-info btn-sm details\"\n                      data-cy=\"entityDetailsButton\"\n                      v-if=\"!accountService().writeAuthorities\"\n                    >\n                      <font-awesome-icon icon=\"eye\"></font-awesome-icon>\n                      <span class=\"d-none d-md-inline\">View</span>\n                    </button>\n                    <button\n                      @click=\"navigate\"\n                      class=\"btn btn-primary btn-sm edit\"\n                      data-cy=\"entityEditButton\"\n                      v-if=\"accountService().writeAuthorities\"\n                    >\n                      <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon>\n                      <span class=\"d-none d-md-inline\">Edit</span>\n                    </button>\n                  </router-link>\n                  <b-button v-if=\"accountService().writeAuthorities\" v-on:click=\"prepareToDetach(i)\" variant=\"warning\" class=\"btn btn-sm\">\n                    <font-awesome-icon icon=\"times\"></font-awesome-icon>\n                    <span class=\"d-none d-md-inline\">Detach</span>\n                  </b-button>\n                </div>\n              </td>\n            </tr>\n          </tbody>\n        </table>\n      </div>\n      <div class=\"row\">\n        <div class=\"col-md-6\">\n          <button\n            @click=\"startReorder()\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-success jh-create-entity create-functional-flow\"\n            title=\"Edit Flow Alias in order to move interfaces from on flow to another\"\n            v-if=\"accountService().writeAuthorities && !reorderAlias\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span> Organize Flows</span>\n          </button>\n\n          <button\n            @click=\"saveReorder()\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-success jh-create-entity create-functional-flow\"\n            title=\"Edit Flow Alias in order to move interfaces from on flow to another\"\n            v-if=\"reorderAlias && (reorderAliasflowToSave.length > 0 || reorderStepToSave.length > 0)\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span>Save</span>\n          </button>\n\n          <button\n            @click=\"cancelReorder()\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-success jh-create-entity create-functional-flow\"\n            title=\"Edit Flow Alias in order to move interfaces from on flow to another\"\n            v-if=\"reorderAlias\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span>Cancel</span>\n          </button>\n        </div>\n\n        <div class=\"d-flex justify-content-end col-md-6\">\n          <span>\n            <button\n              class=\"btn btn-primary jh-create-entity create-functional-flow\"\n              v-if=\"accountService().writeAuthorities\"\n              @click=\"prepareSearchInterfaces()\"\n            >\n              <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n              <span>Add Interface</span>\n            </button>\n            <button\n              class=\"btn btn-primary jh-create-entity create-functional-flow\"\n              v-if=\"accountService().writeAuthorities && toBeSaved\"\n              @click=\"saveFunctionalFlow()\"\n            >\n              <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n              <span>Save</span>\n            </button>\n          </span>\n        </div>\n      </div>\n\n      <div class=\"table-responsive\" v-if=\"functionalFlow.landscapes && functionalFlow.landscapes.length > 0\">\n        <br />\n        <br />\n        <h3>\n          <font-awesome-icon icon=\"map\" style=\"color: Tomato; font-size: 0.7em\"></font-awesome-icon> Landscapes using Functional Flow\n          {{ functionalFlow.alias }}\n        </h3>\n\n        <table class=\"table table-striped\">\n          <thead>\n            <tr>\n              <th scope=\"row\"><span>Id</span></th>\n              <th scope=\"row\"><span>Diagram Name</span></th>\n            </tr>\n          </thead>\n          <tbody>\n            <tr v-for=\"landscape in functionalFlow.landscapes\" v-bind:key=\"landscape.id\">\n              <td>\n                <router-link :to=\"{ name: 'LandscapeViewView', params: { landscapeViewId: landscape.id } }\">{{ landscape.id }}</router-link>\n              </td>\n              <td>\n                <router-link :to=\"{ name: 'LandscapeViewView', params: { landscapeViewId: landscape.id } }\">{{\n                  landscape.diagramName\n                }}</router-link>\n              </td>\n            </tr>\n          </tbody>\n        </table>\n      </div>\n    </div>\n    <b-modal ref=\"searchEntity\" id=\"searchEntity\" class=\"mymodalclass\">\n      <span slot=\"modal-title\"\n        ><span id=\"eaDesignItApp.flowInterface.delete.question\" data-cy=\"flowInterfaceDeleteDialogHeading\"\n          >Find or create Interface</span\n        ></span\n      >\n      <div class=\"modal-body\">\n        <datalist id=\"applications\">\n          <option v-for=\"applcation in applications\" :key=\"applcation.id\">{{ applcation.name }}</option>\n        </datalist>\n        <datalist id=\"protocols\">\n          <option v-for=\"protocol in protocols\" :key=\"protocol.id\">{{ protocol.name }}</option>\n        </datalist>\n        <span>\n          Source : <input list=\"applications\" v-model=\"searchSourceName\" /> Target :\n          <input list=\"applications\" v-model=\"searchTargetName\" /> Protocol : <input list=\"protocols\" v-model=\"searchProtocolName\" />\n          <button type=\"button\" class=\"btn btn-primary\" v-on:click=\"searchInterfaces()\">Search Interface</button>\n        </span>\n        <div class=\"table-responsive\" v-if=\"interfaces && interfaces.length > 0\">\n          <table class=\"table\">\n            <thead>\n              <tr>\n                <th></th>\n                <th scope=\"row\"><span>Alias</span></th>\n                <th scope=\"row\"><span>Source</span></th>\n                <th scope=\"row\"><span>Target</span></th>\n                <th scope=\"row\"><span>Protocol</span></th>\n                <th scope=\"row\"><span>DataFlows</span></th>\n                <th scope=\"row\"><span>Functional Flows (used by)</span></th>\n              </tr>\n            </thead>\n            <tr v-for=\"inter in interfaces\" :key=\"inter.id\">\n              <td>\n                <input type=\"checkbox\" :id=\"inter.id\" :value=\"inter\" v-model=\"checkedInterface\" />\n              </td>\n              <td>{{ inter.alias }}</td>\n              <td>{{ inter.source.name }}</td>\n              <td>{{ inter.target.name }}</td>\n              <td>\n                <span v-if=\"inter.protocol\">{{ inter.protocol.name }}</span>\n              </td>\n              <td>\n                <span\n                  v-for=\"dataflow in inter.dataFlows\"\n                  :key=\"dataflow.id\"\n                  :title=\"'frequency : [' + dataflow.frequency + ']' + (dataflow.format ? ', format : [' + dataflow.format.name + ']' : '')\"\n                >\n                  {{ dataflow.resourceName }}\n                </span>\n              </td>\n              <td>\n                <span v-for=\"flow in inter.functionalFlows\" :key=\"flow.id\" :title=\"flow.description\">\n                  {{ flow.alias }}\n                </span>\n              </td>\n            </tr>\n          </table>\n        </div>\n        <div v-if=\"searchDone && (!checkedInterface || checkedInterface.length === 0)\">\n          <p />\n          <p>Nothing found. Do you want to create new Interface?</p>\n        </div>\n      </div>\n      <div slot=\"modal-footer\">\n        <button type=\"button\" class=\"btn btn-secondary\" v-on:click=\"closeSearchDialog()\">Cancel</button>\n        <button\n          type=\"button\"\n          class=\"btn btn-primary\"\n          id=\"mergeflowInterfaceButtonID\"\n          ref=\"mergeflowInterfaceButtonRef\"\n          data-cy=\"entityConfirmDeleteButton\"\n          v-on:click=\"addOrCreateInterface()\"\n          v-if=\"checkedInterface && checkedInterface.length > 0\"\n        >\n          Add\n        </button>\n        <router-link\n          :to=\"{\n            name: 'FlowInterfaceCreate',\n            query: {\n              functionalFlowId: functionalFlow.id,\n              sourceId: searchSourceId,\n              targetId: searchTargetId,\n              protocolId: searchProtocolId,\n            },\n          }\"\n          custom\n          v-slot=\"{ navigate }\"\n          v-if=\"accountService().writeAuthorities\"\n        >\n          <button\n            @click=\"navigate\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-primary jh-create-entity create-flow-interface\"\n            v-if=\"searchDone && (!checkedInterface || checkedInterface.length === 0)\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span> Create a new Flow Interface </span>\n          </button>\n        </router-link>\n      </div>\n    </b-modal>\n    <b-modal ref=\"detachInterfaceEntity\" id=\"detachInterfaceEntity\">\n      <span slot=\"modal-title\"\n        ><span id=\"eaDesignItApp.landscapeView.delete.question\" data-cy=\"landscapeViewDeleteDialogHeading\"\n          >Confirm delete operation</span\n        ></span\n      >\n      <div class=\"modal-body\">\n        <p id=\"jhi-delete-landscapeView-heading\">Are you sure you want to detach this Interface?</p>\n      </div>\n      <div slot=\"modal-footer\">\n        <button type=\"button\" class=\"btn btn-secondary\" v-on:click=\"closeDetachDialog()\">Cancel</button>\n        <button\n          type=\"button\"\n          class=\"btn btn-primary\"\n          id=\"jhi-confirm-delete-landscapeView\"\n          data-cy=\"entityConfirmDeleteButton\"\n          v-on:click=\"detachInterface()\"\n        >\n          Detach\n        </button>\n      </div>\n    </b-modal>\n  </div>\n</template>\n\n<script lang=\"ts\" src=\"./functional-flow-details.component.ts\"></script>\n\n<style>\n.modal-dialog {\n  max-width: 80%;\n}\n.fa-project-diagram g g path {\n  stroke: red;\n  stroke-width: 10;\n}\n</style>\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/functional-flow/functional-flow-details.component.ts?vue&type=script&lang=ts&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/functional-flow/functional-flow-details.component.ts?vue&type=script&lang=ts& ***!
  \******************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var _shared_model_functional_flow_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/shared/model/functional-flow.model */ "./src/main/webapp/app/shared/model/functional-flow.model.ts");
/* harmony import */ var _shared_model_functional_flow_step_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/shared/model/functional-flow-step.model */ "./src/main/webapp/app/shared/model/functional-flow-step.model.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var FunctionalFlowDetails = /** @class */ (function (_super) {
    __extends(FunctionalFlowDetails, _super);
    function FunctionalFlowDetails() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.applications = [];
        _this.protocols = [];
        _this.interfaces = [];
        _this.checkedInterface = [];
        _this.sequenceDiagram = true;
        _this.functionalFlow = {};
        _this.plantUMLImage = '';
        _this.searchSourceName = '';
        _this.searchTargetName = '';
        _this.searchProtocolName = '';
        _this.toBeSaved = false;
        _this.searchDone = false;
        _this.reorderAlias = false;
        _this.isFetching = false;
        _this.applicationIds = [];
        //for description update
        _this.reorderAliasflowToSave = [];
        //for reordering update
        _this.reorderStepToSave = [];
        return _this;
    }
    Object.defineProperty(FunctionalFlowDetails.prototype, "searchSourceId", {
        get: function () {
            var _this = this;
            if (!this.searchSourceName)
                return null;
            return this.applications.find(function (i) { return i.name == _this.searchSourceName; }).id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(FunctionalFlowDetails.prototype, "searchTargetId", {
        get: function () {
            var _this = this;
            if (!this.searchTargetName)
                return null;
            return this.applications.find(function (i) { return i.name == _this.searchTargetName; }).id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(FunctionalFlowDetails.prototype, "searchProtocolId", {
        get: function () {
            var _this = this;
            if (!this.searchProtocolName)
                return null;
            return this.protocols.find(function (i) { return i.name == _this.searchProtocolName; }).id;
        },
        enumerable: false,
        configurable: true
    });
    FunctionalFlowDetails.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.functionalFlowId) {
                vm.retrieveFunctionalFlow(to.params.functionalFlowId);
            }
        });
    };
    FunctionalFlowDetails.prototype.changeDiagram = function () {
        this.isFetching = true;
        this.sequenceDiagram = !this.sequenceDiagram;
        this.getPlantUML(this.functionalFlow.id);
    };
    FunctionalFlowDetails.prototype.retrieveFunctionalFlow = function (functionalFlowId) {
        var _this = this;
        this.functionalFlowService()
            .find(functionalFlowId)
            .then(function (res) {
            _this.functionalFlow = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
        this.getPlantUML(functionalFlowId);
    };
    FunctionalFlowDetails.prototype.previousState = function () {
        this.$router.go(-1);
    };
    FunctionalFlowDetails.prototype.getPlantUML = function (functionalFlowId) {
        var _this = this;
        console.log('Entering in method getPlantUML');
        this.functionalFlowService()
            .getPlantUML(functionalFlowId, this.sequenceDiagram)
            .then(function (res) {
            _this.plantUMLImage = res.data;
            _this.isFetching = false;
        }, function (err) {
            console.log(err);
        });
    };
    FunctionalFlowDetails.prototype.exportPlantUML = function () {
        var _this = this;
        this.functionalFlowService()
            .getPlantUMLSource(this.functionalFlow.id, this.sequenceDiagram)
            .then(function (response) {
            var url = URL.createObjectURL(new Blob([response.data], {
                type: 'text/plain',
            }));
            var link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', _this.functionalFlow.alias + '-plantuml.txt');
            document.body.appendChild(link);
            link.click();
        });
    };
    FunctionalFlowDetails.prototype.prepareSearchInterfaces = function () {
        var _this = this;
        this.applicationService()
            .retrieve()
            .then(function (res) {
            _this.applications = res.data;
        });
        this.protocolService()
            .retrieve()
            .then(function (res) {
            _this.protocols = res.data;
        });
        if (this.$refs.searchEntity) {
            this.$refs.searchEntity.show();
        }
    };
    FunctionalFlowDetails.prototype.searchInterfaces = function () {
        var _this = this;
        this.searchDone = false;
        this.checkedInterface = [];
        this.flowInterfaceService()
            .search(this.searchSourceId, this.searchTargetId, this.searchProtocolId)
            .then(function (res) {
            _this.interfaces = res.data;
            _this.searchDone = true;
        });
    };
    FunctionalFlowDetails.prototype.addOrCreateInterface = function () {
        var _this = this;
        var _a;
        var maxStepOrder = ((_a = this.functionalFlow.steps) === null || _a === void 0 ? void 0 : _a.length) > 0 ? Math.max.apply(Math, this.functionalFlow.steps.map(function (o) { return o.stepOrder; })) : 0;
        if (this.checkedInterface && this.checkedInterface.length > 0) {
            if (!this.functionalFlow.steps) {
                this.functionalFlow.steps = [];
            }
            this.checkedInterface.forEach(function (inter) {
                maxStepOrder = maxStepOrder + 1;
                var step = new _shared_model_functional_flow_step_model__WEBPACK_IMPORTED_MODULE_2__.FunctionalFlowStep();
                step.flowInterface = inter;
                step.flow = _this.functionalFlow;
                step.stepOrder = maxStepOrder;
                _this.functionalFlowStepService()
                    .create(step)
                    .then(function (res) {
                    _this.retrieveFunctionalFlow(_this.functionalFlow.id);
                    _this.closeSearchDialog();
                    _this.toBeSaved = false;
                    //this.getPlantUML(this.functionalFlow.id);
                });
            });
            this.toBeSaved = true;
        }
    };
    FunctionalFlowDetails.prototype.closeSearchDialog = function () {
        this.$refs.searchEntity.hide();
    };
    FunctionalFlowDetails.prototype.detachInterface = function () {
        var _this = this;
        var stepToDelete = this.functionalFlow.steps[this.indexStepToDetach];
        console.log('about to delete : ' + stepToDelete.id);
        this.functionalFlowStepService()
            .delete(stepToDelete.id)
            .then(function (res) {
            _this.retrieveFunctionalFlow(_this.functionalFlow.id);
            _this.closeDetachDialog();
            _this.toBeSaved = false;
        });
    };
    FunctionalFlowDetails.prototype.prepareToDetach = function (index) {
        console.log(index);
        if (this.$refs.detachInterfaceEntity) {
            this.$refs.detachInterfaceEntity.show();
        }
        this.indexStepToDetach = index;
    };
    FunctionalFlowDetails.prototype.closeDetachDialog = function () {
        this.$refs.detachInterfaceEntity.hide();
    };
    FunctionalFlowDetails.prototype.startReorder = function () {
        this.reorderAlias = true;
        this.reorderAliasflowToSave = [];
        this.reorderStepToSave = [];
    };
    FunctionalFlowDetails.prototype.swap = function (i, j) {
        var tmp = this.functionalFlow.steps[i];
        this.functionalFlow.steps.splice(i, 1, this.functionalFlow.steps[j]);
        this.functionalFlow.steps.splice(j, 1, tmp);
        // reorder all steps in flow
        this.reorderAllSteps(this.functionalFlow);
    };
    FunctionalFlowDetails.prototype.reorderAllSteps = function (flow) {
        var _this = this;
        flow.steps.forEach(function (step, i) {
            if (step.stepOrder !== i + 1) {
                step.stepOrder = i + 1;
                _this.addStepToSave(step);
            }
        });
    };
    FunctionalFlowDetails.prototype.saveReorder = function () {
        var _this = this;
        var promises = [];
        this.reorderAliasflowToSave.forEach(function (flow) {
            promises.push(_this.functionalFlowService().update(flow));
        });
        this.reorderStepToSave.forEach(function (step) {
            promises.push(_this.functionalFlowStepService().update(step));
        });
        Promise.all(promises).then(function (res) {
            _this.retrieveFunctionalFlow(_this.functionalFlow.id);
            _this.reorderAlias = false;
            _this.reorderAliasflowToSave = [];
        });
    };
    FunctionalFlowDetails.prototype.cancelReorder = function () {
        var _this = this;
        this.functionalFlowService()
            .find(this.functionalFlow.id)
            .then(function (res) {
            _this.functionalFlow = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
        this.reorderAlias = false;
        this.reorderAliasflowToSave = [];
    };
    FunctionalFlowDetails.prototype.addStepToSave = function (step) {
        this.reorderStepToSave = this.reorderStepToSave.filter(function (s) { return s.id != step.id; });
        // step.flow = newFunctionalFlow this cause an erro, for looping steps?
        var newFunctionalFlowSimplified = new _shared_model_functional_flow_model__WEBPACK_IMPORTED_MODULE_1__.FunctionalFlow();
        newFunctionalFlowSimplified = __assign({}, this.functionalFlow);
        newFunctionalFlowSimplified.steps = [];
        step.flow = newFunctionalFlowSimplified;
        this.reorderStepToSave.push(step);
    };
    FunctionalFlowDetails.prototype.changeStepDescription = function (functionalFlow, step) {
        // Add old & new Flows for later update by REST call
        this.reorderStepToSave = this.reorderStepToSave.filter(function (s) { return s.id != step.id; });
        var newFunctionalFlowSimplified = new _shared_model_functional_flow_model__WEBPACK_IMPORTED_MODULE_1__.FunctionalFlow();
        newFunctionalFlowSimplified = __assign({}, functionalFlow);
        newFunctionalFlowSimplified.steps = [];
        step.flow = newFunctionalFlowSimplified;
        this.reorderStepToSave.push(step);
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowStepService'),
        __metadata("design:type", Function)
    ], FunctionalFlowDetails.prototype, "functionalFlowStepService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowService'),
        __metadata("design:type", Function)
    ], FunctionalFlowDetails.prototype, "functionalFlowService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], FunctionalFlowDetails.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('accountService'),
        __metadata("design:type", Function)
    ], FunctionalFlowDetails.prototype, "accountService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('applicationService'),
        __metadata("design:type", Function)
    ], FunctionalFlowDetails.prototype, "applicationService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('protocolService'),
        __metadata("design:type", Function)
    ], FunctionalFlowDetails.prototype, "protocolService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('flowInterfaceService'),
        __metadata("design:type", Function)
    ], FunctionalFlowDetails.prototype, "flowInterfaceService", void 0);
    FunctionalFlowDetails = __decorate([
        vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component
    ], FunctionalFlowDetails);
    return FunctionalFlowDetails;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (FunctionalFlowDetails);


/***/ }),

/***/ "./src/main/webapp/app/shared/model/functional-flow-step.model.ts":
/*!************************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/functional-flow-step.model.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FunctionalFlowStep": function() { return /* binding */ FunctionalFlowStep; }
/* harmony export */ });
var FunctionalFlowStep = /** @class */ (function () {
    function FunctionalFlowStep(id, description, stepOrder, flowInterface, flow) {
        this.id = id;
        this.description = description;
        this.stepOrder = stepOrder;
        this.flowInterface = flowInterface;
        this.flow = flow;
    }
    return FunctionalFlowStep;
}());



/***/ }),

/***/ "./src/main/webapp/app/shared/model/functional-flow.model.ts":
/*!*******************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/functional-flow.model.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FunctionalFlow": function() { return /* binding */ FunctionalFlow; }
/* harmony export */ });
var FunctionalFlow = /** @class */ (function () {
    function FunctionalFlow(id, alias, description, comment, status, documentationURL, documentationURL2, startDate, endDate, steps, owner, landscapes, dataFlows) {
        this.id = id;
        this.alias = alias;
        this.description = description;
        this.comment = comment;
        this.status = status;
        this.documentationURL = documentationURL;
        this.documentationURL2 = documentationURL2;
        this.startDate = startDate;
        this.endDate = endDate;
        this.steps = steps;
        this.owner = owner;
        this.landscapes = landscapes;
        this.dataFlows = dataFlows;
    }
    return FunctionalFlow;
}());



/***/ }),

/***/ "./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue":
/*!**********************************************************************************!*\
  !*** ./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _functional_flow_details_vue_vue_type_template_id_5c24c08a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./functional-flow-details.vue?vue&type=template&id=5c24c08a& */ "./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=template&id=5c24c08a&");
/* harmony import */ var _functional_flow_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./functional-flow-details.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/functional-flow/functional-flow-details.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _functional_flow_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./functional-flow-details.vue?vue&type=style&index=0&lang=css& */ "./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _functional_flow_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _functional_flow_details_vue_vue_type_template_id_5c24c08a___WEBPACK_IMPORTED_MODULE_0__.render,
  _functional_flow_details_vue_vue_type_template_id_5c24c08a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/functional-flow/functional-flow-details.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/functional-flow/functional-flow-details.component.ts?vue&type=script&lang=ts&":
/*!********************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/functional-flow/functional-flow-details.component.ts?vue&type=script&lang=ts& ***!
  \********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_functional_flow_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./functional-flow-details.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/functional-flow/functional-flow-details.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_functional_flow_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=template&id=5c24c08a&":
/*!*****************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=template&id=5c24c08a& ***!
  \*****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_template_id_5c24c08a___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_template_id_5c24c08a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_template_id_5c24c08a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./functional-flow-details.vue?vue&type=template&id=5c24c08a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=template&id=5c24c08a&");


/***/ }),

/***/ "./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-style-loader/index.js!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./functional-flow-details.vue?vue&type=style&index=0&lang=css& */ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = function(key) { return _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_functional_flow_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }.bind(0, __WEBPACK_IMPORT_KEY__)
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=template&id=5c24c08a&":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=template&id=5c24c08a& ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "row justify-content-center" },
    [
      _c("div", { staticClass: "col-8" }, [
        _vm.functionalFlow
          ? _c(
              "div",
              [
                _c(
                  "h2",
                  {
                    staticClass: "jh-entity-heading",
                    attrs: { "data-cy": "functionalFlowDetailsHeading" },
                  },
                  [
                    _c("font-awesome-icon", {
                      staticStyle: { color: "Tomato", "font-size": "0.7em" },
                      attrs: { icon: "project-diagram" },
                    }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Functional Flow")]),
                    _vm._v(
                      " - " + _vm._s(_vm.functionalFlow.alias) + "\n      "
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("dl", { staticClass: "row jh-entity-details" }, [
                  _vm._m(0),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.functionalFlow.alias))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(1),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [
                      _vm._v(_vm._s(_vm.functionalFlow.description)),
                    ]),
                  ]),
                  _vm._v(" "),
                  _vm._m(2),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.functionalFlow.comment))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(3),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.functionalFlow.status))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(4),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [
                      _c(
                        "a",
                        {
                          attrs: { href: _vm.functionalFlow.documentationURL },
                        },
                        [_vm._v(_vm._s(_vm.functionalFlow.documentationURL))]
                      ),
                    ]),
                  ]),
                  _vm._v(" "),
                  _vm._m(5),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [
                      _c(
                        "a",
                        {
                          attrs: { href: _vm.functionalFlow.documentationURL2 },
                        },
                        [_vm._v(_vm._s(_vm.functionalFlow.documentationURL2))]
                      ),
                    ]),
                  ]),
                  _vm._v(" "),
                  _vm._m(6),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.functionalFlow.startDate))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(7),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.functionalFlow.endDate))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(8),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.functionalFlow.owner
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "OwnerView",
                                    params: {
                                      ownerId: _vm.functionalFlow.owner.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(_vm.functionalFlow.owner.name))]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                ]),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info",
                    attrs: {
                      type: "submit",
                      "data-cy": "entityDetailsBackButton",
                    },
                    on: {
                      click: function ($event) {
                        $event.preventDefault()
                        return _vm.previousState()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "arrow-left" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v(" Back")]),
                  ],
                  1
                ),
                _vm._v(" "),
                _vm.functionalFlow.id
                  ? _c("router-link", {
                      attrs: {
                        to: {
                          name: "FunctionalFlowEdit",
                          params: { functionalFlowId: _vm.functionalFlow.id },
                        },
                        custom: "",
                      },
                      scopedSlots: _vm._u(
                        [
                          {
                            key: "default",
                            fn: function (ref) {
                              var navigate = ref.navigate
                              return [
                                _vm.accountService().writeAuthorities
                                  ? _c(
                                      "button",
                                      {
                                        staticClass: "btn btn-primary",
                                        on: { click: navigate },
                                      },
                                      [
                                        _c("font-awesome-icon", {
                                          attrs: { icon: "pencil-alt" },
                                        }),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(" Edit Information"),
                                        ]),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ]
                            },
                          },
                        ],
                        null,
                        false,
                        874495339
                      ),
                    })
                  : _vm._e(),
              ],
              1
            )
          : _vm._e(),
        _vm._v(" "),
        _c("br"),
        _vm._v(" "),
        _c("h3", [
          _vm._v(
            _vm._s(_vm.functionalFlow.alias) +
              " - " +
              _vm._s(_vm.functionalFlow.description)
          ),
        ]),
        _vm._v(" "),
        _c("div", [
          _c("div", { domProps: { innerHTML: _vm._s(_vm.plantUMLImage) } }),
          _vm._v(" "),
          _c("div", { staticClass: "col-12" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-warning",
                staticStyle: {
                  "font-size": "0.7em",
                  padding: "3px",
                  margin: "3px",
                },
                attrs: { disabled: _vm.isFetching },
                on: {
                  click: function ($event) {
                    return _vm.changeDiagram()
                  },
                },
              },
              [
                _c("font-awesome-icon", {
                  attrs: { icon: "sync", spin: _vm.isFetching },
                }),
                _vm._v(" "),
                _c("span", {
                  domProps: {
                    textContent: _vm._s(
                      _vm.sequenceDiagram
                        ? "component diagram"
                        : "sequence diagram"
                    ),
                  },
                }),
              ],
              1
            ),
            _vm._v(" "),
            _vm.plantUMLImage
              ? _c(
                  "button",
                  {
                    staticClass: "btn btn-warning",
                    staticStyle: {
                      "font-size": "0.7em",
                      padding: "3px",
                      margin: "3px",
                    },
                    attrs: { disabled: _vm.isFetching },
                    on: {
                      click: function ($event) {
                        return _vm.exportPlantUML()
                      },
                    },
                  },
                  [_c("span", [_vm._v("Export plantuml")])]
                )
              : _vm._e(),
          ]),
        ]),
        _vm._v(" "),
        _vm.functionalFlow.steps && _vm.functionalFlow.steps.length > 0
          ? _c("div", { staticClass: "table-responsive" }, [
              _c("table", { staticClass: "table table-striped" }, [
                _c("thead", [
                  _c("tr", [
                    _vm._m(9),
                    _vm._v(" "),
                    _vm.reorderAlias
                      ? _c("th", { attrs: { scope: "row" } })
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.reorderAlias
                      ? _c("th", { attrs: { scope: "row" } })
                      : _vm._e(),
                    _vm._v(" "),
                    _vm._m(10),
                    _vm._v(" "),
                    _vm._m(11),
                    _vm._v(" "),
                    _vm._m(12),
                    _vm._v(" "),
                    _vm._m(13),
                    _vm._v(" "),
                    _vm._m(14),
                    _vm._v(" "),
                    _c("th", { attrs: { scope: "row" } }),
                  ]),
                ]),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.functionalFlow.steps, function (step, i) {
                    return _c(
                      "tr",
                      {
                        key: step.id,
                        attrs: { set: (_vm.inter = step.flowInterface) },
                      },
                      [
                        _c("td", [
                          _vm._v(
                            "\n              " +
                              _vm._s(step.stepOrder) +
                              ".\n              "
                          ),
                          !_vm.reorderAlias
                            ? _c("span", [_vm._v(_vm._s(step.description))])
                            : _c("span", [
                                _c("textarea", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: step.description,
                                      expression: "step.description",
                                    },
                                  ],
                                  staticStyle: {
                                    width: "100%",
                                    "min-width": "600px",
                                  },
                                  attrs: { rows: "1" },
                                  domProps: { value: step.description },
                                  on: {
                                    change: function ($event) {
                                      return _vm.changeStepDescription(
                                        _vm.functionalFlow,
                                        step
                                      )
                                    },
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        step,
                                        "description",
                                        $event.target.value
                                      )
                                    },
                                  },
                                }),
                              ]),
                        ]),
                        _vm._v(" "),
                        _vm.reorderAlias
                          ? _c(
                              "td",
                              [
                                i != 0
                                  ? _c("font-awesome-icon", {
                                      staticClass: "btn-success",
                                      attrs: { icon: "chevron-up" },
                                      on: {
                                        click: function ($event) {
                                          return _vm.swap(i, i - 1)
                                        },
                                      },
                                    })
                                  : _vm._e(),
                              ],
                              1
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.reorderAlias
                          ? _c(
                              "td",
                              [
                                i != _vm.functionalFlow.steps.length - 1
                                  ? _c("font-awesome-icon", {
                                      staticClass: "btn-success",
                                      attrs: { icon: "chevron-down" },
                                      on: {
                                        click: function ($event) {
                                          return _vm.swap(i, i + 1)
                                        },
                                      },
                                    })
                                  : _vm._e(),
                              ],
                              1
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _c(
                          "td",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "FlowInterfaceView",
                                    params: { flowInterfaceId: _vm.inter.id },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(_vm.inter.alias))]
                            ),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "td",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "ApplicationView",
                                    params: {
                                      applicationId: _vm.inter.source.id,
                                    },
                                  },
                                },
                              },
                              [
                                _vm._v(
                                  "\n                " +
                                    _vm._s(_vm.inter.source.name) +
                                    "\n              "
                                ),
                              ]
                            ),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "td",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "ApplicationView",
                                    params: {
                                      applicationId: _vm.inter.target.id,
                                    },
                                  },
                                },
                              },
                              [
                                _vm._v(
                                  "\n                " +
                                    _vm._s(_vm.inter.target.name) +
                                    "\n              "
                                ),
                              ]
                            ),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "td",
                          [
                            _vm.inter.protocol
                              ? _c(
                                  "router-link",
                                  {
                                    attrs: {
                                      to: {
                                        name: "ProtocolView",
                                        params: {
                                          protocolId: _vm.inter.protocol.id,
                                        },
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n                " +
                                        _vm._s(_vm.inter.protocol.name) +
                                        "\n              "
                                    ),
                                  ]
                                )
                              : _vm._e(),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "td",
                          _vm._l(_vm.inter.dataFlows, function (dataflow) {
                            return _c(
                              "span",
                              { key: dataflow.id },
                              [
                                _c(
                                  "router-link",
                                  {
                                    attrs: {
                                      to: {
                                        name: "DataFlowView",
                                        params: { dataFlowId: dataflow.id },
                                      },
                                      title:
                                        dataflow.resourceName +
                                        (dataflow.items.length > 0
                                          ? " / " +
                                            dataflow.items.length +
                                            " items "
                                          : " / no items"),
                                    },
                                  },
                                  [_vm._v(_vm._s(dataflow.id))]
                                ),
                                dataflow.items && dataflow.items.length > 0
                                  ? _c("sup", [
                                      _vm._v(
                                        "(" +
                                          _vm._s(dataflow.items.length) +
                                          ")"
                                      ),
                                    ])
                                  : _vm._e(),
                                _vm._v(" \n              "),
                              ],
                              1
                            )
                          }),
                          0
                        ),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-right" }, [
                          _c(
                            "div",
                            { staticClass: "btn-group" },
                            [
                              _c("router-link", {
                                attrs: {
                                  to: {
                                    name: "FlowInterfaceView",
                                    params: { flowInterfaceId: _vm.inter.id },
                                  },
                                  custom: "",
                                },
                                scopedSlots: _vm._u(
                                  [
                                    {
                                      key: "default",
                                      fn: function (ref) {
                                        var navigate = ref.navigate
                                        return [
                                          !_vm.accountService().writeAuthorities
                                            ? _c(
                                                "button",
                                                {
                                                  staticClass:
                                                    "btn btn-info btn-sm details",
                                                  attrs: {
                                                    "data-cy":
                                                      "entityDetailsButton",
                                                  },
                                                  on: { click: navigate },
                                                },
                                                [
                                                  _c("font-awesome-icon", {
                                                    attrs: { icon: "eye" },
                                                  }),
                                                  _vm._v(" "),
                                                  _c(
                                                    "span",
                                                    {
                                                      staticClass:
                                                        "d-none d-md-inline",
                                                    },
                                                    [_vm._v("View")]
                                                  ),
                                                ],
                                                1
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _vm.accountService().writeAuthorities
                                            ? _c(
                                                "button",
                                                {
                                                  staticClass:
                                                    "btn btn-primary btn-sm edit",
                                                  attrs: {
                                                    "data-cy":
                                                      "entityEditButton",
                                                  },
                                                  on: { click: navigate },
                                                },
                                                [
                                                  _c("font-awesome-icon", {
                                                    attrs: {
                                                      icon: "pencil-alt",
                                                    },
                                                  }),
                                                  _vm._v(" "),
                                                  _c(
                                                    "span",
                                                    {
                                                      staticClass:
                                                        "d-none d-md-inline",
                                                    },
                                                    [_vm._v("Edit")]
                                                  ),
                                                ],
                                                1
                                              )
                                            : _vm._e(),
                                        ]
                                      },
                                    },
                                  ],
                                  null,
                                  true
                                ),
                              }),
                              _vm._v(" "),
                              _vm.accountService().writeAuthorities
                                ? _c(
                                    "b-button",
                                    {
                                      staticClass: "btn btn-sm",
                                      attrs: { variant: "warning" },
                                      on: {
                                        click: function ($event) {
                                          return _vm.prepareToDetach(i)
                                        },
                                      },
                                    },
                                    [
                                      _c("font-awesome-icon", {
                                        attrs: { icon: "times" },
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "span",
                                        { staticClass: "d-none d-md-inline" },
                                        [_vm._v("Detach")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ]),
                      ]
                    )
                  }),
                  0
                ),
              ]),
            ])
          : _vm._e(),
        _vm._v(" "),
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-md-6" }, [
            _vm.accountService().writeAuthorities && !_vm.reorderAlias
              ? _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-success jh-create-entity create-functional-flow",
                    attrs: {
                      id: "jh-create-entity",
                      "data-cy": "entityCreateButton",
                      title:
                        "Edit Flow Alias in order to move interfaces from on flow to another",
                    },
                    on: {
                      click: function ($event) {
                        return _vm.startReorder()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v(" Organize Flows")]),
                  ],
                  1
                )
              : _vm._e(),
            _vm._v(" "),
            _vm.reorderAlias &&
            (_vm.reorderAliasflowToSave.length > 0 ||
              _vm.reorderStepToSave.length > 0)
              ? _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-success jh-create-entity create-functional-flow",
                    attrs: {
                      id: "jh-create-entity",
                      "data-cy": "entityCreateButton",
                      title:
                        "Edit Flow Alias in order to move interfaces from on flow to another",
                    },
                    on: {
                      click: function ($event) {
                        return _vm.saveReorder()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Save")]),
                  ],
                  1
                )
              : _vm._e(),
            _vm._v(" "),
            _vm.reorderAlias
              ? _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-success jh-create-entity create-functional-flow",
                    attrs: {
                      id: "jh-create-entity",
                      "data-cy": "entityCreateButton",
                      title:
                        "Edit Flow Alias in order to move interfaces from on flow to another",
                    },
                    on: {
                      click: function ($event) {
                        return _vm.cancelReorder()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Cancel")]),
                  ],
                  1
                )
              : _vm._e(),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "d-flex justify-content-end col-md-6" }, [
            _c("span", [
              _vm.accountService().writeAuthorities
                ? _c(
                    "button",
                    {
                      staticClass:
                        "btn btn-primary jh-create-entity create-functional-flow",
                      on: {
                        click: function ($event) {
                          return _vm.prepareSearchInterfaces()
                        },
                      },
                    },
                    [
                      _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                      _vm._v(" "),
                      _c("span", [_vm._v("Add Interface")]),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.accountService().writeAuthorities && _vm.toBeSaved
                ? _c(
                    "button",
                    {
                      staticClass:
                        "btn btn-primary jh-create-entity create-functional-flow",
                      on: {
                        click: function ($event) {
                          return _vm.saveFunctionalFlow()
                        },
                      },
                    },
                    [
                      _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                      _vm._v(" "),
                      _c("span", [_vm._v("Save")]),
                    ],
                    1
                  )
                : _vm._e(),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _vm.functionalFlow.landscapes &&
        _vm.functionalFlow.landscapes.length > 0
          ? _c("div", { staticClass: "table-responsive" }, [
              _c("br"),
              _vm._v(" "),
              _c("br"),
              _vm._v(" "),
              _c(
                "h3",
                [
                  _c("font-awesome-icon", {
                    staticStyle: { color: "Tomato", "font-size": "0.7em" },
                    attrs: { icon: "map" },
                  }),
                  _vm._v(
                    " Landscapes using Functional Flow\n        " +
                      _vm._s(_vm.functionalFlow.alias) +
                      "\n      "
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("table", { staticClass: "table table-striped" }, [
                _vm._m(15),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.functionalFlow.landscapes, function (landscape) {
                    return _c("tr", { key: landscape.id }, [
                      _c(
                        "td",
                        [
                          _c(
                            "router-link",
                            {
                              attrs: {
                                to: {
                                  name: "LandscapeViewView",
                                  params: { landscapeViewId: landscape.id },
                                },
                              },
                            },
                            [_vm._v(_vm._s(landscape.id))]
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "td",
                        [
                          _c(
                            "router-link",
                            {
                              attrs: {
                                to: {
                                  name: "LandscapeViewView",
                                  params: { landscapeViewId: landscape.id },
                                },
                              },
                            },
                            [_vm._v(_vm._s(landscape.diagramName))]
                          ),
                        ],
                        1
                      ),
                    ])
                  }),
                  0
                ),
              ]),
            ])
          : _vm._e(),
      ]),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          ref: "searchEntity",
          staticClass: "mymodalclass",
          attrs: { id: "searchEntity" },
        },
        [
          _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
            _c(
              "span",
              {
                attrs: {
                  id: "eaDesignItApp.flowInterface.delete.question",
                  "data-cy": "flowInterfaceDeleteDialogHeading",
                },
              },
              [_vm._v("Find or create Interface")]
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-body" }, [
            _c(
              "datalist",
              { attrs: { id: "applications" } },
              _vm._l(_vm.applications, function (applcation) {
                return _c("option", { key: applcation.id }, [
                  _vm._v(_vm._s(applcation.name)),
                ])
              }),
              0
            ),
            _vm._v(" "),
            _c(
              "datalist",
              { attrs: { id: "protocols" } },
              _vm._l(_vm.protocols, function (protocol) {
                return _c("option", { key: protocol.id }, [
                  _vm._v(_vm._s(protocol.name)),
                ])
              }),
              0
            ),
            _vm._v(" "),
            _c("span", [
              _vm._v("\n        Source : "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.searchSourceName,
                    expression: "searchSourceName",
                  },
                ],
                attrs: { list: "applications" },
                domProps: { value: _vm.searchSourceName },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.searchSourceName = $event.target.value
                  },
                },
              }),
              _vm._v(" Target :\n        "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.searchTargetName,
                    expression: "searchTargetName",
                  },
                ],
                attrs: { list: "applications" },
                domProps: { value: _vm.searchTargetName },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.searchTargetName = $event.target.value
                  },
                },
              }),
              _vm._v(" Protocol : "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.searchProtocolName,
                    expression: "searchProtocolName",
                  },
                ],
                attrs: { list: "protocols" },
                domProps: { value: _vm.searchProtocolName },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.searchProtocolName = $event.target.value
                  },
                },
              }),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-primary",
                  attrs: { type: "button" },
                  on: {
                    click: function ($event) {
                      return _vm.searchInterfaces()
                    },
                  },
                },
                [_vm._v("Search Interface")]
              ),
            ]),
            _vm._v(" "),
            _vm.interfaces && _vm.interfaces.length > 0
              ? _c("div", { staticClass: "table-responsive" }, [
                  _c(
                    "table",
                    { staticClass: "table" },
                    [
                      _c("thead", [
                        _c("tr", [
                          _c("th"),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Alias")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Source")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Target")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Protocol")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("DataFlows")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Functional Flows (used by)")]),
                          ]),
                        ]),
                      ]),
                      _vm._v(" "),
                      _vm._l(_vm.interfaces, function (inter) {
                        return _c("tr", { key: inter.id }, [
                          _c("td", [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.checkedInterface,
                                  expression: "checkedInterface",
                                },
                              ],
                              attrs: { type: "checkbox", id: inter.id },
                              domProps: {
                                value: inter,
                                checked: Array.isArray(_vm.checkedInterface)
                                  ? _vm._i(_vm.checkedInterface, inter) > -1
                                  : _vm.checkedInterface,
                              },
                              on: {
                                change: function ($event) {
                                  var $$a = _vm.checkedInterface,
                                    $$el = $event.target,
                                    $$c = $$el.checked ? true : false
                                  if (Array.isArray($$a)) {
                                    var $$v = inter,
                                      $$i = _vm._i($$a, $$v)
                                    if ($$el.checked) {
                                      $$i < 0 &&
                                        (_vm.checkedInterface = $$a.concat([
                                          $$v,
                                        ]))
                                    } else {
                                      $$i > -1 &&
                                        (_vm.checkedInterface = $$a
                                          .slice(0, $$i)
                                          .concat($$a.slice($$i + 1)))
                                    }
                                  } else {
                                    _vm.checkedInterface = $$c
                                  }
                                },
                              },
                            }),
                          ]),
                          _vm._v(" "),
                          _c("td", [_vm._v(_vm._s(inter.alias))]),
                          _vm._v(" "),
                          _c("td", [_vm._v(_vm._s(inter.source.name))]),
                          _vm._v(" "),
                          _c("td", [_vm._v(_vm._s(inter.target.name))]),
                          _vm._v(" "),
                          _c("td", [
                            inter.protocol
                              ? _c("span", [
                                  _vm._v(_vm._s(inter.protocol.name)),
                                ])
                              : _vm._e(),
                          ]),
                          _vm._v(" "),
                          _c(
                            "td",
                            _vm._l(inter.dataFlows, function (dataflow) {
                              return _c(
                                "span",
                                {
                                  key: dataflow.id,
                                  attrs: {
                                    title:
                                      "frequency : [" +
                                      dataflow.frequency +
                                      "]" +
                                      (dataflow.format
                                        ? ", format : [" +
                                          dataflow.format.name +
                                          "]"
                                        : ""),
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(dataflow.resourceName) +
                                      "\n              "
                                  ),
                                ]
                              )
                            }),
                            0
                          ),
                          _vm._v(" "),
                          _c(
                            "td",
                            _vm._l(inter.functionalFlows, function (flow) {
                              return _c(
                                "span",
                                {
                                  key: flow.id,
                                  attrs: { title: flow.description },
                                },
                                [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(flow.alias) +
                                      "\n              "
                                  ),
                                ]
                              )
                            }),
                            0
                          ),
                        ])
                      }),
                    ],
                    2
                  ),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.searchDone &&
            (!_vm.checkedInterface || _vm.checkedInterface.length === 0)
              ? _c("div", [
                  _c("p"),
                  _vm._v(" "),
                  _c("p", [
                    _vm._v(
                      "Nothing found. Do you want to create new Interface?"
                    ),
                  ]),
                ])
              : _vm._e(),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { attrs: { slot: "modal-footer" }, slot: "modal-footer" },
            [
              _c(
                "button",
                {
                  staticClass: "btn btn-secondary",
                  attrs: { type: "button" },
                  on: {
                    click: function ($event) {
                      return _vm.closeSearchDialog()
                    },
                  },
                },
                [_vm._v("Cancel")]
              ),
              _vm._v(" "),
              _vm.checkedInterface && _vm.checkedInterface.length > 0
                ? _c(
                    "button",
                    {
                      ref: "mergeflowInterfaceButtonRef",
                      staticClass: "btn btn-primary",
                      attrs: {
                        type: "button",
                        id: "mergeflowInterfaceButtonID",
                        "data-cy": "entityConfirmDeleteButton",
                      },
                      on: {
                        click: function ($event) {
                          return _vm.addOrCreateInterface()
                        },
                      },
                    },
                    [_vm._v("\n        Add\n      ")]
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.accountService().writeAuthorities
                ? _c("router-link", {
                    attrs: {
                      to: {
                        name: "FlowInterfaceCreate",
                        query: {
                          functionalFlowId: _vm.functionalFlow.id,
                          sourceId: _vm.searchSourceId,
                          targetId: _vm.searchTargetId,
                          protocolId: _vm.searchProtocolId,
                        },
                      },
                      custom: "",
                    },
                    scopedSlots: _vm._u(
                      [
                        {
                          key: "default",
                          fn: function (ref) {
                            var navigate = ref.navigate
                            return [
                              _vm.searchDone &&
                              (!_vm.checkedInterface ||
                                _vm.checkedInterface.length === 0)
                                ? _c(
                                    "button",
                                    {
                                      staticClass:
                                        "btn btn-primary jh-create-entity create-flow-interface",
                                      attrs: {
                                        id: "jh-create-entity",
                                        "data-cy": "entityCreateButton",
                                      },
                                      on: { click: navigate },
                                    },
                                    [
                                      _c("font-awesome-icon", {
                                        attrs: { icon: "plus" },
                                      }),
                                      _vm._v(" "),
                                      _c("span", [
                                        _vm._v(" Create a new Flow Interface "),
                                      ]),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ]
                          },
                        },
                      ],
                      null,
                      false,
                      730564130
                    ),
                  })
                : _vm._e(),
            ],
            1
          ),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          ref: "detachInterfaceEntity",
          attrs: { id: "detachInterfaceEntity" },
        },
        [
          _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
            _c(
              "span",
              {
                attrs: {
                  id: "eaDesignItApp.landscapeView.delete.question",
                  "data-cy": "landscapeViewDeleteDialogHeading",
                },
              },
              [_vm._v("Confirm delete operation")]
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-body" }, [
            _c("p", { attrs: { id: "jhi-delete-landscapeView-heading" } }, [
              _vm._v("Are you sure you want to detach this Interface?"),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { attrs: { slot: "modal-footer" }, slot: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: { type: "button" },
                on: {
                  click: function ($event) {
                    return _vm.closeDetachDialog()
                  },
                },
              },
              [_vm._v("Cancel")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "button",
                  id: "jhi-confirm-delete-landscapeView",
                  "data-cy": "entityConfirmDeleteButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.detachInterface()
                  },
                },
              },
              [_vm._v("\n        Detach\n      ")]
            ),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Alias")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Description")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Comment")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Status")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Documentation URL")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Documentation URL 2")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Start Date")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("End Date")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Owner")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Step")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Interface")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Source")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Target")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Protocol")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Data Flows")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Id")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Diagram Name")]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./functional-flow-details.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/functional-flow/functional-flow-details.vue?vue&type=style&index=0&lang=css&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(/*! !../../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js")["default"])
var update = add("009b7cd4", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_functional-flow_functional-flow-details_vue.js.map