"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_eadesignit_sequence-diagram_import_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/eadesignit/sequence-diagram/import.component.ts?vue&type=script&lang=ts&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/eadesignit/sequence-diagram/import.component.ts?vue&type=script&lang=ts& ***!
  \****************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var SequenceDiagram = /** @class */ (function (_super) {
    __extends(SequenceDiagram, _super);
    function SequenceDiagram() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.plantuml = '';
        _this.plantUMLImage = '';
        _this.isFetching = false;
        _this.functionalFlow = null;
        _this.importError = '';
        _this.previewError = '';
        return _this;
    }
    SequenceDiagram.prototype.getPlantUML = function () {
        var _this = this;
        this.sequenceDiagramService()
            .getPlantUML(this.plantuml)
            .then(function (res) {
            _this.plantUMLImage = res.data;
            _this.isFetching = false;
            _this.previewError = '';
        }, function (err) {
            console.log(err);
            _this.plantUMLImage = '';
            _this.functionalFlow = null;
            _this.previewError = err;
        });
    };
    SequenceDiagram.prototype.importPlantUML = function () {
        var _this = this;
        this.getPlantUML();
        this.sequenceDiagramService()
            .importPlantuml(this.plantuml)
            .then(function (res) {
            _this.functionalFlow = res.data;
            _this.isFetching = false;
            _this.importError = '';
        }, function (err) {
            _this.plantUMLImage = '';
            _this.functionalFlow = '';
            _this.importError = err;
        });
    };
    SequenceDiagram.prototype.saveImport = function () {
        var _this = this;
        this.getPlantUML();
        this.sequenceDiagramService()
            .saveImport(this.functionalFlow)
            .then(function (res) {
            _this.$router.push({ name: 'FunctionalFlowView', params: { functionalFlowId: res.data.id } });
        }, function (err) {
            _this.plantUMLImage = '';
            _this.functionalFlow = '';
            _this.importError = err;
        });
    };
    SequenceDiagram.prototype.changeInterface = function (flowimportLine) {
        if (flowimportLine.selectedInterface && flowimportLine.selectedInterface.protocol) {
            flowimportLine.protocol = flowimportLine.selectedInterface.protocol;
        }
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('sequenceDiagramService'),
        __metadata("design:type", Function)
    ], SequenceDiagram.prototype, "sequenceDiagramService", void 0);
    SequenceDiagram = __decorate([
        vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component
    ], SequenceDiagram);
    return SequenceDiagram;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (SequenceDiagram);


/***/ }),

/***/ "./src/main/webapp/app/eadesignit/sequence-diagram/import.vue":
/*!********************************************************************!*\
  !*** ./src/main/webapp/app/eadesignit/sequence-diagram/import.vue ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _import_vue_vue_type_template_id_dfcc9854___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./import.vue?vue&type=template&id=dfcc9854& */ "./src/main/webapp/app/eadesignit/sequence-diagram/import.vue?vue&type=template&id=dfcc9854&");
/* harmony import */ var _import_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./import.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/eadesignit/sequence-diagram/import.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _import_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _import_vue_vue_type_template_id_dfcc9854___WEBPACK_IMPORTED_MODULE_0__.render,
  _import_vue_vue_type_template_id_dfcc9854___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/eadesignit/sequence-diagram/import.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/eadesignit/sequence-diagram/import.component.ts?vue&type=script&lang=ts&":
/*!******************************************************************************************************!*\
  !*** ./src/main/webapp/app/eadesignit/sequence-diagram/import.component.ts?vue&type=script&lang=ts& ***!
  \******************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_import_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./import.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/eadesignit/sequence-diagram/import.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_import_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/eadesignit/sequence-diagram/import.vue?vue&type=template&id=dfcc9854&":
/*!***************************************************************************************************!*\
  !*** ./src/main/webapp/app/eadesignit/sequence-diagram/import.vue?vue&type=template&id=dfcc9854& ***!
  \***************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_import_vue_vue_type_template_id_dfcc9854___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_import_vue_vue_type_template_id_dfcc9854___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_import_vue_vue_type_template_id_dfcc9854___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./import.vue?vue&type=template&id=dfcc9854& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/eadesignit/sequence-diagram/import.vue?vue&type=template&id=dfcc9854&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/eadesignit/sequence-diagram/import.vue?vue&type=template&id=dfcc9854&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/eadesignit/sequence-diagram/import.vue?vue&type=template&id=dfcc9854& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c(
      "h2",
      { attrs: { id: "page-heading", "data-cy": "FlowImportHeading" } },
      [_vm._v("Import Flow from Plantuml Sequence Diagram")]
    ),
    _vm._v(" "),
    _c("div", [
      _c("textarea", {
        directives: [
          {
            name: "model",
            rawName: "v-model",
            value: _vm.plantuml,
            expression: "plantuml",
          },
        ],
        staticStyle: { width: "100%", "min-width": "600px" },
        attrs: { rows: "30" },
        domProps: { value: _vm.plantuml },
        on: {
          input: function ($event) {
            if ($event.target.composing) {
              return
            }
            _vm.plantuml = $event.target.value
          },
        },
      }),
    ]),
    _vm._v(" "),
    _c("div", [
      _c(
        "button",
        {
          staticClass: "btn btn-primary",
          attrs: { type: "submit", "data-cy": "submit" },
          on: { click: _vm.importPlantUML },
        },
        [_vm._v("Import")]
      ),
    ]),
    _vm._v(" "),
    _c("div", {
      staticClass: "table-responsive",
      domProps: { innerHTML: _vm._s(_vm.plantUMLImage) },
    }),
    _vm._v(" "),
    _vm.importError
      ? _c("div", { staticClass: "alert alert-danger" }, [
          _vm._v("Error during import"),
        ])
      : _vm._e(),
    _vm._v(" "),
    _vm.functionalFlow
      ? _c("h2", [
          _vm._v("\n    " + _vm._s(_vm.functionalFlow.description) + "\n  "),
        ])
      : _vm._e(),
    _vm._v(" "),
    _vm.functionalFlow &&
    _vm.functionalFlow.flowImportLines &&
    _vm.functionalFlow.flowImportLines.length > 0
      ? _c("div", { staticClass: "table-responsive" }, [
          _c("table", { staticClass: "table table-striped" }, [
            _vm._m(0),
            _vm._v(" "),
            _c(
              "tbody",
              _vm._l(_vm.functionalFlow.flowImportLines, function (step) {
                return _c("tr", { key: step.id }, [
                  _c("td", [
                    _vm._v(
                      "\n            " + _vm._s(step.order) + ".\n            "
                    ),
                    _c("span", [_vm._v(_vm._s(step.description))]),
                  ]),
                  _vm._v(" "),
                  _c("td", [
                    step.potentialInterfaces
                      ? _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: step.selectedInterface,
                                expression: "step.selectedInterface",
                              },
                            ],
                            on: {
                              change: [
                                function ($event) {
                                  var $$selectedVal = Array.prototype.filter
                                    .call($event.target.options, function (o) {
                                      return o.selected
                                    })
                                    .map(function (o) {
                                      var val =
                                        "_value" in o ? o._value : o.value
                                      return val
                                    })
                                  _vm.$set(
                                    step,
                                    "selectedInterface",
                                    $event.target.multiple
                                      ? $$selectedVal
                                      : $$selectedVal[0]
                                  )
                                },
                                function ($event) {
                                  return _vm.changeInterface(step)
                                },
                              ],
                            },
                          },
                          [
                            _c("option", { attrs: { value: "" } }),
                            _vm._v(" "),
                            _vm._l(step.potentialInterfaces, function (inter) {
                              return _c(
                                "option",
                                { key: inter.id, domProps: { value: inter } },
                                [_vm._v(_vm._s(inter.alias))]
                              )
                            }),
                          ],
                          2
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _c(
                    "td",
                    [
                      step.source
                        ? _c(
                            "router-link",
                            {
                              attrs: {
                                to: {
                                  name: "ApplicationView",
                                  params: { applicationId: step.source.id },
                                },
                              },
                            },
                            [
                              _vm._v(
                                "\n              " +
                                  _vm._s(step.source.name) +
                                  "\n            "
                              ),
                            ]
                          )
                        : _c("span", { staticClass: "alert alert-danger" }, [
                            _vm._v("Not imported"),
                          ]),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "td",
                    [
                      step.target
                        ? _c(
                            "router-link",
                            {
                              attrs: {
                                to: {
                                  name: "ApplicationView",
                                  params: { applicationId: step.target.id },
                                },
                              },
                            },
                            [
                              _vm._v(
                                "\n              " +
                                  _vm._s(step.target.name) +
                                  "\n            "
                              ),
                            ]
                          )
                        : _c("span", { staticClass: "alert alert-danger" }, [
                            _vm._v("Not imported"),
                          ]),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "td",
                    [
                      step.protocol
                        ? _c(
                            "router-link",
                            {
                              attrs: {
                                to: {
                                  name: "ProtocolView",
                                  params: { protocolId: step.protocol.id },
                                },
                              },
                            },
                            [
                              _vm._v(
                                "\n              " +
                                  _vm._s(step.protocol.name) +
                                  "\n            "
                              ),
                            ]
                          )
                        : _c("span", { staticClass: "alert alert-warning" }, [
                            _vm._v("Not imported"),
                          ]),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("td", [
                    step.potentialDataFlows
                      ? _c(
                          "select",
                          {
                            directives: [
                              {
                                name: "model",
                                rawName: "v-model",
                                value: step.selectedDataFlow,
                                expression: "step.selectedDataFlow",
                              },
                            ],
                            on: {
                              change: function ($event) {
                                var $$selectedVal = Array.prototype.filter
                                  .call($event.target.options, function (o) {
                                    return o.selected
                                  })
                                  .map(function (o) {
                                    var val = "_value" in o ? o._value : o.value
                                    return val
                                  })
                                _vm.$set(
                                  step,
                                  "selectedDataFlow",
                                  $event.target.multiple
                                    ? $$selectedVal
                                    : $$selectedVal[0]
                                )
                              },
                            },
                          },
                          [
                            _c("option", { attrs: { value: "" } }),
                            _vm._v(" "),
                            _vm._l(
                              step.potentialDataFlows,
                              function (dataFlow) {
                                return _c(
                                  "option",
                                  {
                                    key: dataFlow.id,
                                    domProps: { value: dataFlow },
                                  },
                                  [_vm._v(_vm._s(dataFlow.id))]
                                )
                              }
                            ),
                          ],
                          2
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _c("td", [
                    step.selectedDataFlow && step.selectedDataFlow.contractURL
                      ? _c("span", [
                          _vm._v(
                            _vm._s(
                              step.selectedDataFlow.contractURL.substring(0, 50)
                            ) + "..."
                          ),
                        ])
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _c("td", [
                    step.selectedDataFlow &&
                    step.selectedDataFlow.documentationURL
                      ? _c("span", [
                          _vm._v(
                            _vm._s(
                              step.selectedDataFlow.documentationURL.substring(
                                0,
                                50
                              )
                            ) + "..."
                          ),
                        ])
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _c("td", [
                    step.selectedDataFlow
                      ? _c("span", [
                          _vm._v(_vm._s(step.selectedDataFlow.frequency)),
                        ])
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _c("td", [
                    step.selectedDataFlow && step.selectedDataFlow.format
                      ? _c("span", [
                          _vm._v(_vm._s(step.selectedDataFlow.format.name)),
                        ])
                      : _vm._e(),
                  ]),
                ])
              }),
              0
            ),
          ]),
        ])
      : _vm._e(),
    _vm._v(" "),
    _c("div", [
      _c(
        "button",
        {
          staticClass: "btn btn-primary",
          attrs: {
            type: "submit",
            disabled: !_vm.functionalFlow || _vm.functionalFlow.onError,
            "data-cy": "submit",
          },
          on: { click: _vm.saveImport },
        },
        [_vm._v("\n      Save\n    ")]
      ),
    ]),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Step")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Interface")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Source")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Target")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Protocol")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Data Flows")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Contract URL")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Document URL")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Frequency")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Format")])]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_eadesignit_sequence-diagram_import_vue.js.map