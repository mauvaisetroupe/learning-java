"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_flow-interface_flow-interface-details_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-interface/flow-interface-details.component.ts?vue&type=script&lang=ts&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-interface/flow-interface-details.component.ts?vue&type=script&lang=ts& ***!
  \****************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FlowInterfaceDetails = /** @class */ (function (_super) {
    __extends(FlowInterfaceDetails, _super);
    function FlowInterfaceDetails() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.flowInterface = {};
        return _this;
    }
    FlowInterfaceDetails.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.flowInterfaceId) {
                vm.retrieveFlowInterface(to.params.flowInterfaceId);
            }
        });
    };
    FlowInterfaceDetails.prototype.retrieveFlowInterface = function (flowInterfaceId) {
        var _this = this;
        this.flowInterfaceService()
            .find(flowInterfaceId)
            .then(function (res) {
            _this.flowInterface = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    FlowInterfaceDetails.prototype.previousState = function () {
        this.$router.go(-1);
    };
    FlowInterfaceDetails.prototype.prepareToDetach = function (dataFlow) {
        if (this.$refs.detachDataEntity) {
            this.$refs.detachDataEntity.show();
        }
        this.dataFlowToDetach = dataFlow;
    };
    FlowInterfaceDetails.prototype.detachDataFlow = function () {
        var _this = this;
        this.dataFlowService()
            .update(this.dataFlowToDetach)
            .then(function (res) {
            _this.retrieveFlowInterface(_this.flowInterface.id);
            _this.closeDetachDialog();
        });
    };
    FlowInterfaceDetails.prototype.closeDetachDialog = function () {
        this.$refs.detachDataEntity.hide();
    };
    FlowInterfaceDetails.prototype.isOwner = function (flowInterface) {
        var _a, _b;
        var username = (_b = (_a = this.$store.getters.account) === null || _a === void 0 ? void 0 : _a.login) !== null && _b !== void 0 ? _b : '';
        if (this.accountService().writeAuthorities) {
            return true;
        }
        if (flowInterface.owner && flowInterface.owner.users) {
            for (var _i = 0, _c = flowInterface.owner.users; _i < _c.length; _i++) {
                var user = _c[_i];
                if (user.login === username) {
                    return true;
                }
            }
        }
        return false;
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('flowInterfaceService'),
        __metadata("design:type", Function)
    ], FlowInterfaceDetails.prototype, "flowInterfaceService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], FlowInterfaceDetails.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('accountService'),
        __metadata("design:type", Function)
    ], FlowInterfaceDetails.prototype, "accountService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('dataFlowService'),
        __metadata("design:type", Function)
    ], FlowInterfaceDetails.prototype, "dataFlowService", void 0);
    FlowInterfaceDetails = __decorate([
        vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component
    ], FlowInterfaceDetails);
    return FlowInterfaceDetails;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (FlowInterfaceDetails);


/***/ }),

/***/ "./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue":
/*!********************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _flow_interface_details_vue_vue_type_template_id_50dcc96e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./flow-interface-details.vue?vue&type=template&id=50dcc96e& */ "./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue?vue&type=template&id=50dcc96e&");
/* harmony import */ var _flow_interface_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./flow-interface-details.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/flow-interface/flow-interface-details.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _flow_interface_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _flow_interface_details_vue_vue_type_template_id_50dcc96e___WEBPACK_IMPORTED_MODULE_0__.render,
  _flow_interface_details_vue_vue_type_template_id_50dcc96e___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/flow-interface/flow-interface-details.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-interface/flow-interface-details.component.ts?vue&type=script&lang=ts&":
/*!******************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-interface/flow-interface-details.component.ts?vue&type=script&lang=ts& ***!
  \******************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_flow_interface_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./flow-interface-details.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-interface/flow-interface-details.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_flow_interface_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue?vue&type=template&id=50dcc96e&":
/*!***************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue?vue&type=template&id=50dcc96e& ***!
  \***************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_interface_details_vue_vue_type_template_id_50dcc96e___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_interface_details_vue_vue_type_template_id_50dcc96e___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_interface_details_vue_vue_type_template_id_50dcc96e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./flow-interface-details.vue?vue&type=template&id=50dcc96e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue?vue&type=template&id=50dcc96e&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue?vue&type=template&id=50dcc96e&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-interface/flow-interface-details.vue?vue&type=template&id=50dcc96e& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "row justify-content-center" },
    [
      _c("div", { staticClass: "col-8" }, [
        _vm.flowInterface
          ? _c(
              "div",
              [
                _c(
                  "h2",
                  {
                    staticClass: "jh-entity-heading",
                    attrs: { "data-cy": "flowInterfaceDetailsHeading" },
                  },
                  [
                    _c("font-awesome-icon", {
                      staticStyle: { color: "Tomato", "font-size": "0.9em" },
                      attrs: { icon: "grip-lines" },
                    }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Interface")]),
                    _vm._v(
                      " -\n        " +
                        _vm._s(_vm.flowInterface.alias) +
                        "\n      "
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("dl", { staticClass: "row jh-entity-details" }, [
                  _vm._m(0),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.flowInterface.alias))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(1),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.flowInterface.status))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(2),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [
                      _c(
                        "a",
                        { attrs: { href: _vm.flowInterface.documentationURL } },
                        [_vm._v(_vm._s(_vm.flowInterface.documentationURL))]
                      ),
                    ]),
                  ]),
                  _vm._v(" "),
                  _vm._m(3),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [
                      _c(
                        "a",
                        {
                          attrs: { href: _vm.flowInterface.documentationURL2 },
                        },
                        [_vm._v(_vm._s(_vm.flowInterface.documentationURL2))]
                      ),
                    ]),
                  ]),
                  _vm._v(" "),
                  _vm._m(4),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.flowInterface.description))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(5),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.flowInterface.startDate))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(6),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.flowInterface.endDate))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(7),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.flowInterface.source
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "ApplicationView",
                                    params: {
                                      applicationId:
                                        _vm.flowInterface.source.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(_vm.flowInterface.source.name))]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _vm._m(8),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.flowInterface.target
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "ApplicationView",
                                    params: {
                                      applicationId:
                                        _vm.flowInterface.target.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(_vm.flowInterface.target.name))]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _vm._m(9),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.flowInterface.sourceComponent
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "ApplicationComponentView",
                                    params: {
                                      applicationComponentId:
                                        _vm.flowInterface.sourceComponent.id,
                                    },
                                  },
                                },
                              },
                              [
                                _vm._v(
                                  _vm._s(_vm.flowInterface.sourceComponent.name)
                                ),
                              ]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _vm._m(10),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.flowInterface.targetComponent
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "ApplicationComponentView",
                                    params: {
                                      applicationComponentId:
                                        _vm.flowInterface.targetComponent.id,
                                    },
                                  },
                                },
                              },
                              [
                                _vm._v(
                                  _vm._s(_vm.flowInterface.targetComponent.name)
                                ),
                              ]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _vm._m(11),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.flowInterface.protocol
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "ProtocolView",
                                    params: {
                                      protocolId: _vm.flowInterface.protocol.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(_vm.flowInterface.protocol.name))]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _vm._m(12),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.flowInterface.owner
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "OwnerView",
                                    params: {
                                      ownerId: _vm.flowInterface.owner.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(_vm.flowInterface.owner.name))]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                ]),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info",
                    attrs: {
                      type: "submit",
                      "data-cy": "entityDetailsBackButton",
                    },
                    on: {
                      click: function ($event) {
                        $event.preventDefault()
                        return _vm.previousState()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "arrow-left" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v(" Back")]),
                  ],
                  1
                ),
                _vm._v(" "),
                _vm.flowInterface.id
                  ? _c("router-link", {
                      attrs: {
                        to: {
                          name: "FlowInterfaceEdit",
                          params: { flowInterfaceId: _vm.flowInterface.id },
                        },
                        custom: "",
                      },
                      scopedSlots: _vm._u(
                        [
                          {
                            key: "default",
                            fn: function (ref) {
                              var navigate = ref.navigate
                              return [
                                _vm.accountService().writeOrContributor
                                  ? _c(
                                      "button",
                                      {
                                        staticClass: "btn btn-primary",
                                        attrs: {
                                          disabled: !_vm.isOwner(
                                            _vm.flowInterface
                                          ),
                                        },
                                        on: { click: navigate },
                                      },
                                      [
                                        _c("font-awesome-icon", {
                                          attrs: { icon: "pencil-alt" },
                                        }),
                                        _vm._v(" "),
                                        _c("span", [_vm._v(" Edit")]),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ]
                            },
                          },
                        ],
                        null,
                        false,
                        1505809640
                      ),
                    })
                  : _vm._e(),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _c("br"),
                _vm._v(" "),
                _c(
                  "h3",
                  [
                    _c("font-awesome-icon", {
                      staticStyle: { color: "Tomato", "font-size": "0.9em" },
                      attrs: { icon: "folder" },
                    }),
                    _vm._v(" Data Flows"),
                  ],
                  1
                ),
                _vm._v(" "),
                _vm.flowInterface.dataFlows &&
                _vm.flowInterface.dataFlows.length > 0
                  ? _c("div", { staticClass: "table-responsive" }, [
                      _c("br"),
                      _vm._v(" "),
                      _c("br"),
                      _vm._v(" "),
                      _c(
                        "table",
                        {
                          staticClass: "table table-striped",
                          attrs: { "aria-describedby": "dataFlows" },
                        },
                        [
                          _vm._m(13),
                          _vm._v(" "),
                          _c(
                            "tbody",
                            _vm._l(
                              _vm.flowInterface.dataFlows,
                              function (dataFlow, i) {
                                return _c(
                                  "tr",
                                  {
                                    key: dataFlow.id,
                                    attrs: { "data-cy": "entityTable" },
                                  },
                                  [
                                    _c(
                                      "td",
                                      [
                                        _c(
                                          "router-link",
                                          {
                                            attrs: {
                                              to: {
                                                name: "DataFlowView",
                                                params: {
                                                  dataFlowId: dataFlow.id,
                                                },
                                              },
                                            },
                                          },
                                          [_vm._v(_vm._s(dataFlow.id))]
                                        ),
                                      ],
                                      1
                                    ),
                                    _vm._v(" "),
                                    _c("td", [
                                      _vm._v(_vm._s(dataFlow.resourceName)),
                                    ]),
                                    _vm._v(" "),
                                    _c("td", [
                                      _vm._v(_vm._s(dataFlow.resourceType)),
                                    ]),
                                    _vm._v(" "),
                                    _c("td", [
                                      _vm._v(_vm._s(dataFlow.description)),
                                    ]),
                                    _vm._v(" "),
                                    _c(
                                      "td",
                                      _vm._l(dataFlow.items, function (item) {
                                        return _c(
                                          "span",
                                          { key: item.id },
                                          [
                                            _c(
                                              "router-link",
                                              {
                                                attrs: {
                                                  to: {
                                                    name: "DataFlowItemView",
                                                    params: {
                                                      dataFlowItemId: item.id,
                                                    },
                                                  },
                                                  title: item.resourceName,
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  "\n                    " +
                                                    _vm._s(item.id) +
                                                    "\n                  "
                                                ),
                                              ]
                                            ),
                                          ],
                                          1
                                        )
                                      }),
                                      0
                                    ),
                                    _vm._v(" "),
                                    _c("td", { staticClass: "text-right" }, [
                                      _c(
                                        "div",
                                        { staticClass: "btn-group" },
                                        [
                                          _c("router-link", {
                                            attrs: {
                                              to: {
                                                name: "DataFlowView",
                                                params: {
                                                  dataFlowId: dataFlow.id,
                                                },
                                              },
                                              custom: "",
                                            },
                                            scopedSlots: _vm._u(
                                              [
                                                {
                                                  key: "default",
                                                  fn: function (ref) {
                                                    var navigate = ref.navigate
                                                    return [
                                                      !_vm.accountService()
                                                        .writeAuthorities
                                                        ? _c(
                                                            "button",
                                                            {
                                                              staticClass:
                                                                "btn btn-info btn-sm details",
                                                              attrs: {
                                                                "data-cy":
                                                                  "entityDetailsButton",
                                                              },
                                                              on: {
                                                                click: navigate,
                                                              },
                                                            },
                                                            [
                                                              _c(
                                                                "font-awesome-icon",
                                                                {
                                                                  attrs: {
                                                                    icon: "eye",
                                                                  },
                                                                }
                                                              ),
                                                              _vm._v(" "),
                                                              _c(
                                                                "span",
                                                                {
                                                                  staticClass:
                                                                    "d-none d-md-inline",
                                                                },
                                                                [_vm._v("View")]
                                                              ),
                                                            ],
                                                            1
                                                          )
                                                        : _vm._e(),
                                                      _vm._v(" "),
                                                      _vm.accountService()
                                                        .writeAuthorities
                                                        ? _c(
                                                            "button",
                                                            {
                                                              staticClass:
                                                                "btn btn-primary btn-sm edit",
                                                              attrs: {
                                                                "data-cy":
                                                                  "entityEditButton",
                                                              },
                                                              on: {
                                                                click: navigate,
                                                              },
                                                            },
                                                            [
                                                              _c(
                                                                "font-awesome-icon",
                                                                {
                                                                  attrs: {
                                                                    icon: "pencil-alt",
                                                                  },
                                                                }
                                                              ),
                                                              _vm._v(" "),
                                                              _c(
                                                                "span",
                                                                {
                                                                  staticClass:
                                                                    "d-none d-md-inline",
                                                                },
                                                                [_vm._v("Edit")]
                                                              ),
                                                            ],
                                                            1
                                                          )
                                                        : _vm._e(),
                                                    ]
                                                  },
                                                },
                                              ],
                                              null,
                                              true
                                            ),
                                          }),
                                          _vm._v(" "),
                                          _vm.accountService().writeAuthorities
                                            ? _c(
                                                "b-button",
                                                {
                                                  directives: [
                                                    {
                                                      name: "b-modal",
                                                      rawName:
                                                        "v-b-modal.removeEntity",
                                                      modifiers: {
                                                        removeEntity: true,
                                                      },
                                                    },
                                                  ],
                                                  staticClass: "btn btn-sm",
                                                  attrs: {
                                                    variant: "warning",
                                                    "data-cy":
                                                      "entityDeleteButton",
                                                  },
                                                  on: {
                                                    click: function ($event) {
                                                      return _vm.prepareToDetach(
                                                        dataFlow
                                                      )
                                                    },
                                                  },
                                                },
                                                [
                                                  _c("font-awesome-icon", {
                                                    attrs: { icon: "times" },
                                                  }),
                                                  _vm._v(" "),
                                                  _c(
                                                    "span",
                                                    {
                                                      staticClass:
                                                        "d-none d-md-inline",
                                                    },
                                                    [_vm._v("Detach")]
                                                  ),
                                                ],
                                                1
                                              )
                                            : _vm._e(),
                                        ],
                                        1
                                      ),
                                    ]),
                                  ]
                                )
                              }
                            ),
                            0
                          ),
                        ]
                      ),
                    ])
                  : _vm._e(),
                _vm._v(" "),
                _c("div", { staticClass: "d-flex justify-content-end" }, [
                  _c(
                    "span",
                    [
                      _vm.accountService().writeAuthorities
                        ? _c(
                            "button",
                            {
                              staticClass:
                                "btn btn-primary jh-create-entity create-functional-flow",
                              on: {
                                click: function ($event) {
                                  return _vm.addNew()
                                },
                              },
                            },
                            [
                              _c("font-awesome-icon", {
                                attrs: { icon: "plus" },
                              }),
                              _vm._v(" "),
                              _c("span", [_vm._v("Add exisintg Data Flow")]),
                            ],
                            1
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.accountService().writeAuthorities
                        ? _c("router-link", {
                            attrs: {
                              to: { name: "DataFlowCreate" },
                              custom: "",
                            },
                            scopedSlots: _vm._u(
                              [
                                {
                                  key: "default",
                                  fn: function (ref) {
                                    var navigate = ref.navigate
                                    return [
                                      _vm.accountService().writeAuthorities
                                        ? _c(
                                            "button",
                                            {
                                              staticClass:
                                                "btn btn-primary jh-create-entity create-flow-interface",
                                              attrs: {
                                                id: "jh-create-entity",
                                                "data-cy": "entityCreateButton",
                                              },
                                              on: { click: navigate },
                                            },
                                            [
                                              _c("font-awesome-icon", {
                                                attrs: { icon: "plus" },
                                              }),
                                              _vm._v(" "),
                                              _c("span", [
                                                _vm._v(
                                                  " Create a new Data Flow "
                                                ),
                                              ]),
                                            ],
                                            1
                                          )
                                        : _vm._e(),
                                    ]
                                  },
                                },
                              ],
                              null,
                              false,
                              2385283295
                            ),
                          })
                        : _vm._e(),
                    ],
                    1
                  ),
                ]),
                _vm._v(" "),
                _vm.flowInterface.steps && _vm.flowInterface.steps.length > 0
                  ? _c("div", { staticClass: "table-responsive" }, [
                      _c("br"),
                      _vm._v(" "),
                      _c("br"),
                      _vm._v(" "),
                      _c(
                        "h3",
                        [
                          _c("font-awesome-icon", {
                            staticStyle: {
                              color: "Tomato",
                              "font-size": "0.7em",
                            },
                            attrs: { icon: "project-diagram" },
                          }),
                          _vm._v(
                            " Functional Flows using\n          interface " +
                              _vm._s(_vm.flowInterface.alias) +
                              "\n        "
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "table",
                        {
                          staticClass: "table table-striped",
                          attrs: { "aria-describedby": "functionalFlows" },
                        },
                        [
                          _vm._m(14),
                          _vm._v(" "),
                          _c(
                            "tbody",
                            _vm._l(_vm.flowInterface.steps, function (step) {
                              return _c(
                                "tr",
                                {
                                  key: step.id,
                                  attrs: {
                                    "data-cy": "entityTable",
                                    set: (_vm.functionalFlow = step.flow),
                                  },
                                },
                                [
                                  _c(
                                    "td",
                                    [
                                      _c(
                                        "router-link",
                                        {
                                          attrs: {
                                            to: {
                                              name: "FunctionalFlowView",
                                              params: {
                                                functionalFlowId:
                                                  _vm.functionalFlow.id,
                                              },
                                            },
                                          },
                                        },
                                        [_vm._v(_vm._s(_vm.functionalFlow.id))]
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(_vm._s(_vm.functionalFlow.alias)),
                                  ]),
                                  _vm._v(" "),
                                  _c("td", [
                                    _vm._v(
                                      _vm._s(_vm.functionalFlow.description)
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "td",
                                    _vm._l(
                                      _vm.functionalFlow.landscapes,
                                      function (landscape, i) {
                                        return _c(
                                          "span",
                                          { key: landscape.id },
                                          [
                                            _vm._v(
                                              "\n                  " +
                                                _vm._s(i > 0 ? ", " : "") +
                                                "\n                  "
                                            ),
                                            _c(
                                              "router-link",
                                              {
                                                attrs: {
                                                  to: {
                                                    name: "LandscapeViewView",
                                                    params: {
                                                      landscapeViewId:
                                                        landscape.id,
                                                    },
                                                  },
                                                },
                                              },
                                              [
                                                _vm._v(
                                                  _vm._s(landscape.diagramName)
                                                ),
                                              ]
                                            ),
                                          ],
                                          1
                                        )
                                      }
                                    ),
                                    0
                                  ),
                                  _vm._v(" "),
                                  _c("td"),
                                ]
                              )
                            }),
                            0
                          ),
                        ]
                      ),
                    ])
                  : _vm._e(),
              ],
              1
            )
          : _vm._e(),
      ]),
      _vm._v(" "),
      _c(
        "b-modal",
        { ref: "detachDataEntity", attrs: { id: "detachDataEntity" } },
        [
          _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
            _c(
              "span",
              {
                attrs: {
                  id: "eaDesignItApp.landscapeView.delete.question",
                  "data-cy": "landscapeViewDeleteDialogHeading",
                },
              },
              [_vm._v("Confirm delete operation")]
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-body" }, [
            _c("p", { attrs: { id: "jhi-delete-landscapeView-heading" } }, [
              _vm._v("Are you sure you want to detach this Data Flow?"),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { attrs: { slot: "modal-footer" }, slot: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: { type: "button" },
                on: {
                  click: function ($event) {
                    return _vm.closeDetachDialog()
                  },
                },
              },
              [_vm._v("Cancel")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "button",
                  id: "jhi-confirm-delete-landscapeView",
                  "data-cy": "entityConfirmDeleteButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.detachDataFlow()
                  },
                },
              },
              [_vm._v("\n        Delete\n      ")]
            ),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Alias")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Status")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Documentation URL")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Documentation URL 2")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Description")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Start Date")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("End Date")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Source")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Target")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Source Component")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Target Component")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Protocol")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Owner")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("ID")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Resource Name")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Resource Type")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Description")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Data Items")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("ID")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Alias")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Description")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Landscape")]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_flow-interface_flow-interface-details_vue.js.map