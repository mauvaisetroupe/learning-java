(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_landscape-view_landscape-view-details_vue"],{

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\niframe {\n  border: 5;\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 100%;\n  height: 100%;\n}\n.mycolor {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n.modal-dialog {\n  max-width: 80%;\n}\n", "",{"version":3,"sources":["webpack://./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue"],"names":[],"mappings":";AAqfA;EACA,SAAA;EACA,eAAA;EACA,MAAA;EACA,OAAA;EACA,QAAA;EACA,SAAA;EACA,WAAA;EACA,YAAA;AACA;AACA;EACA,oCAAA;AACA;AACA;EACA,cAAA;AACA","sourcesContent":["<template>\n  <div class=\"row justify-content-center\">\n    <div class=\"col-12\">\n      <div v-if=\"landscapeView\">\n        <h2 class=\"jh-entity-heading\" data-cy=\"landscapeViewDetailsHeading\">\n          <span\n            ><font-awesome-icon icon=\"map\" style=\"color: Tomato; font-size: 0.7em\"></font-awesome-icon> Landscape -\n            {{ landscapeView.diagramName }}</span\n          >\n        </h2>\n        <dl class=\"row jh-entity-details\">\n          <dt>\n            <span>Viewpoint</span>\n          </dt>\n          <dd>\n            <span>{{ landscapeView.viewpoint }}</span>\n          </dd>\n          <dt>\n            <span>Diagram Name</span>\n          </dt>\n          <dd>\n            <span>{{ landscapeView.diagramName }}</span>\n          </dd>\n          <dt>\n            <span>Owner</span>\n          </dt>\n          <dd>\n            <div v-if=\"landscapeView.owner\">\n              <router-link :to=\"{ name: 'OwnerView', params: { ownerId: landscapeView.owner.id } }\">{{\n                landscapeView.owner.name\n              }}</router-link>\n            </div>\n          </dd>\n          <!--\n          <dt>\n            <span>Flows</span>\n          </dt>\n          <dd>\n            <span v-for=\"(flows, i) in landscapeView.flows\" :key=\"flows.id\"\n              >{{ i > 0 ? ', ' : '' }}\n              <router-link :title=\"flows.description\" :to=\"{ name: 'FunctionalFlowView', params: { functionalFlowId: flows.id } }\">{{\n                flows.alias\n              }}</router-link>\n            </span>\n          </dd>\n          -->\n          <dt>\n            <span>Capabilities</span>\n          </dt>\n          <dd>\n            <span v-for=\"(capabilities, i) in landscapeView.capabilities\" :key=\"capabilities.id\"\n              >{{ i > 0 ? ', ' : '' }}\n              <router-link :to=\"{ name: 'CapabilityView', params: { capabilityId: capabilities.id } }\">{{ capabilities.name }}</router-link>\n            </span>\n          </dd>\n        </dl>\n        <button type=\"submit\" v-on:click.prevent=\"previousState()\" class=\"btn btn-info\" data-cy=\"entityDetailsBackButton\">\n          <font-awesome-icon icon=\"arrow-left\"></font-awesome-icon>&nbsp;<span> Back</span>\n        </button>\n        <router-link\n          v-if=\"landscapeView.id\"\n          :to=\"{ name: 'LandscapeViewEdit', params: { landscapeViewId: landscapeView.id } }\"\n          custom\n          v-slot=\"{ navigate }\"\n        >\n          <button @click=\"navigate\" class=\"btn btn-primary\" v-if=\"accountService().writeAuthorities\">\n            <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon>&nbsp;<span> Edit</span>\n          </button>\n        </router-link>\n      </div>\n      <div>\n        <br />\n      </div>\n      <br />\n      <h3>Landscape diagram</h3>\n      <div>\n        <div v-html=\"plantUMLImage\" class=\"table-responsive\"></div>\n        <div class=\"col-12\">\n          <button\n            class=\"btn btn-warning\"\n            v-on:click=\"exportPlantUML()\"\n            style=\"font-size: 0.7em; padding: 3px; margin: 3px\"\n            v-if=\"plantUMLImage\"\n          >\n            <span>Export plantuml</span>\n          </button>\n          <br /><br />\n        </div>\n      </div>\n      <h3>\n        <font-awesome-icon icon=\"project-diagram\" style=\"color: Tomato; font-size: 0.7em\"></font-awesome-icon> Functional Flows\n        <font-awesome-icon icon=\"file-excel\" style=\"color: green\" @click=\"exportExcel()\"></font-awesome-icon>\n      </h3>\n      <br />\n      <table class=\"table\">\n        <thead>\n          <tr>\n            <th scope=\"row\"><span>Flow</span></th>\n            <th scope=\"row\" v-if=\"reorderAlias\"></th>\n            <th scope=\"row\" v-if=\"reorderAlias\"></th>\n            <th scope=\"row\"><span>Description</span></th>\n            <th scope=\"row\"><span>Step</span></th>\n            <th scope=\"row\"><span>Interface</span></th>\n            <th scope=\"row\"><span>Source</span></th>\n            <th scope=\"row\"><span>Target</span></th>\n            <th scope=\"row\"><span>Protocol</span></th>\n            <th scope=\"row\"><span>DataFlow</span></th>\n            <th scope=\"row\"></th>\n          </tr>\n        </thead>\n        <tbody>\n          <template v-for=\"(functionalFlow, i) in landscapeView.flows\">\n            <template\n              v-for=\"(step, j) in functionalFlow.steps != null && functionalFlow.steps.length > 0 ? functionalFlow.steps : emptySteps\"\n            >\n              <tr v-bind:key=\"step.id\" :class=\"i % 2 == 0 ? 'mycolor' : ''\">\n                <td>\n                  <div v-if=\"!reorderAlias || !step.flowInterface.id\">\n                    <router-link\n                      :to=\"{ name: 'FunctionalFlowView', params: { functionalFlowId: functionalFlow.id } }\"\n                      v-if=\"functionalFlow && j == 0\"\n                    >\n                      {{ functionalFlow.alias }}\n                    </router-link>\n                  </div>\n                  <div v-if=\"reorderAlias && step.flowInterface.id\">\n                    <select @change=\"reorder(step, functionalFlow, $event)\" :id=\"step.id\" class=\"btn-success\">\n                      <option v-for=\"flow in landscapeView.flows\" :key=\"flow.id\" :value=\"flow.id\" :selected=\"flow.id === functionalFlow.id\">\n                        {{ flow.alias ? flow.alias : flow.id }}\n                      </option>\n                    </select>\n                  </div>\n                </td>\n                <td v-if=\"reorderAlias\">\n                  <font-awesome-icon\n                    icon=\"chevron-up\"\n                    class=\"btn-success\"\n                    v-if=\"j != 0\"\n                    @click=\"swap(functionalFlow, j, j - 1)\"\n                  ></font-awesome-icon>\n                </td>\n                <td v-if=\"reorderAlias\">\n                  <font-awesome-icon\n                    icon=\"chevron-down\"\n                    class=\"btn-success\"\n                    v-if=\"j != functionalFlow.steps.length - 1 && functionalFlow.steps.length > 1\"\n                    @click=\"swap(functionalFlow, j, j + 1)\"\n                  ></font-awesome-icon>\n                </td>\n                <td>\n                  <span v-if=\"j == 0\">\n                    <span v-if=\"!reorderAlias\">{{ functionalFlow.description }}</span>\n                    <span v-else>\n                      <textarea\n                        style=\"width: 100%; min-width: 600px\"\n                        rows=\"1\"\n                        v-model=\"functionalFlow.description\"\n                        @change=\"changeDescription(functionalFlow)\"\n                      ></textarea>\n                    </span>\n                  </span>\n                </td>\n                <td>\n                  <span v-if=\"step.description != 'EMPTYSTEP'\">\n                    {{ step.stepOrder }}.\n                    <span v-if=\"!reorderAlias\">{{ step.description }}</span>\n                    <span v-else>\n                      <textarea\n                        style=\"width: 100%; min-width: 600px\"\n                        rows=\"1\"\n                        v-model=\"step.description\"\n                        @change=\"changeStepDescription(functionalFlow, step)\"\n                      ></textarea>\n                    </span>\n                  </span>\n                </td>\n                <td>\n                  <router-link\n                    v-if=\"step.flowInterface.id\"\n                    :to=\"{ name: 'FlowInterfaceView', params: { flowInterfaceId: step.flowInterface.id } }\"\n                    >{{ step.flowInterface.alias }}</router-link\n                  >\n                </td>\n                <td>\n                  <router-link\n                    v-if=\"step.flowInterface.id\"\n                    :to=\"{ name: 'ApplicationView', params: { applicationId: step.flowInterface.source.id } }\"\n                  >\n                    {{ step.flowInterface.source.name }}\n                  </router-link>\n                </td>\n                <td>\n                  <router-link\n                    v-if=\"step.flowInterface.id\"\n                    :to=\"{ name: 'ApplicationView', params: { applicationId: step.flowInterface.target.id } }\"\n                  >\n                    {{ step.flowInterface.target.name }}\n                  </router-link>\n                </td>\n\n                <td>\n                  <router-link\n                    v-if=\"step.flowInterface.protocol\"\n                    :to=\"{ name: 'ProtocolView', params: { protocolId: step.flowInterface.protocol.id } }\"\n                    :title=\"step.flowInterface.protocol.name\"\n                  >\n                    {{ step.flowInterface.protocol.type }}\n                  </router-link>\n                </td>\n                <td>\n                  <span v-if=\"step.flowInterface.id\">\n                    <span v-for=\"(dataFlow, i) in step.flowInterface.dataFlows\" :key=\"dataFlow.id\"\n                      >{{ i > 0 ? ', ' : '' }}\n                      <router-link\n                        class=\"form-control-static\"\n                        :to=\"{ name: 'DataFlowView', params: { dataFlowId: dataFlow.id } }\"\n                        :title=\"dataFlow.resourceName\"\n                        >{{ dataFlow.id }}</router-link\n                      ><sup v-if=\"dataFlow.items && dataFlow.items.length > 0\">({{ dataFlow.items.length }})</sup>\n                    </span>\n                  </span>\n                </td>\n                <td class=\"text-right\">\n                  <div class=\"btn-group\" v-if=\"j == 0 && !reorderAlias\">\n                    <router-link\n                      :to=\"{ name: 'FunctionalFlowView', params: { functionalFlowId: functionalFlow.id } }\"\n                      custom\n                      v-slot=\"{ navigate }\"\n                    >\n                      <button\n                        @click=\"navigate\"\n                        class=\"btn btn-primary btn-sm edit\"\n                        data-cy=\"entityEditButton\"\n                        v-if=\"accountService().writeAuthorities\"\n                      >\n                        <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon>\n                        <span class=\"d-none d-md-inline\">Edit</span>\n                      </button>\n\n                      <button\n                        @click=\"navigate\"\n                        class=\"btn btn-info btn-sm details\"\n                        data-cy=\"entityDetailsButton\"\n                        v-if=\"!accountService().writeAuthorities\"\n                      >\n                        <font-awesome-icon icon=\"eye\"></font-awesome-icon>\n                        <span class=\"d-none d-md-inline\">View</span>\n                      </button>\n                    </router-link>\n\n                    <b-button v-if=\"accountService().writeAuthorities\" variant=\"warning\" class=\"btn btn-sm\" @click=\"prepareToDetach(i)\">\n                      <font-awesome-icon icon=\"times\"></font-awesome-icon>\n                      <span class=\"d-none d-md-inline\">Detach</span>\n                    </b-button>\n                  </div>\n                </td>\n              </tr>\n            </template>\n          </template>\n        </tbody>\n      </table>\n      <div class=\"row\">\n        <div class=\"col-md-6\">\n          <button\n            @click=\"startReorder()\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-success jh-create-entity create-functional-flow\"\n            title=\"Edit Flow Alias in order to move interfaces from on flow to another\"\n            v-if=\"accountService().writeAuthorities && !reorderAlias\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span> Organize Flows</span>\n          </button>\n\n          <button\n            @click=\"saveReorder()\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-success jh-create-entity create-functional-flow\"\n            title=\"Edit Flow Alias in order to move interfaces from on flow to another\"\n            v-if=\"reorderAlias && (reorderAliasflowToSave.length > 0 || reorderStepToSave.length > 0)\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span>Save</span>\n          </button>\n\n          <button\n            @click=\"cancelReorder()\"\n            id=\"jh-create-entity\"\n            data-cy=\"entityCreateButton\"\n            class=\"btn btn-success jh-create-entity create-functional-flow\"\n            title=\"Edit Flow Alias in order to move interfaces from on flow to another\"\n            v-if=\"reorderAlias\"\n          >\n            <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n            <span>Cancel</span>\n          </button>\n        </div>\n        <div class=\"col-md-6 d-flex justify-content-end\" v-if=\"!reorderAlias\">\n          <span>\n            <button\n              class=\"btn btn-primary jh-create-entity create-functional-flow\"\n              v-if=\"accountService().writeAuthorities\"\n              title=\"Add existing Functional flow, from other landscape, with same description, same interfaces\"\n              @click=\"openSearchFlow()\"\n            >\n              <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n              <span>Add exisintg Functional Flow</span>\n            </button>\n\n            <router-link\n              :to=\"{ name: 'FunctionalFlowCreate', query: { landscapeViewId: landscapeView.id } }\"\n              custom\n              v-slot=\"{ navigate }\"\n              v-if=\"accountService().writeAuthorities\"\n            >\n              <button\n                @click=\"navigate\"\n                id=\"jh-create-entity\"\n                data-cy=\"entityCreateButton\"\n                class=\"btn btn-primary jh-create-entity create-functional-flow\"\n                title=\"Create a new Functional Flow, based on existing Interfaces or creating new Interfaces\"\n              >\n                <font-awesome-icon icon=\"plus\"></font-awesome-icon>\n                <span> Create a new Functional Flow </span>\n              </button>\n            </router-link>\n          </span>\n        </div>\n      </div>\n\n      <br /><br /><br /><br /><br /><br />\n      <h2>Draw.io</h2>\n\n      <div v-if=\"!drawIoSVG\">\n        <button @click=\"editDiagram()\" class=\"btn btn-warning\" v-if=\"accountService().writeAuthorities\">\n          <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon>&nbsp;<span> Generate diagram</span>\n        </button>\n        <div>No preview available</div>\n        <div v-if=\"accountService().writeAuthorities\">\n          Generate diagram and use Arrange > Layout > Vertical Flow or Arrange > Layout > Organic to distribute the first diagram components\n        </div>\n      </div>\n\n      <div v-if=\"drawIoSVG && !isEditing\" class=\"m-5\">\n        <div v-html=\"drawIoSVG\" />\n      </div>\n\n      <div class=\"btn-group\">\n        <span v-if=\"!isEditing\">\n          <button @click=\"editDiagram()\" class=\"btn btn-warning\" v-if=\"accountService().writeAuthorities && drawIoSVG\">\n            <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon><span> Edit diagram</span>\n          </button>\n          <button @click=\"saveDiagram()\" class=\"btn btn-primary\" v-if=\"accountService().writeAuthorities && drawIoSVG && drawIOToBeSaved\">\n            <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon><span> Save diagram</span>\n          </button>\n          <button @click=\"prepareRemove()\" class=\"btn btn-danger\" v-if=\"accountService().writeAuthorities && drawIoSVG && !drawIOToBeSaved\">\n            <font-awesome-icon icon=\"times\"></font-awesome-icon><span> Delete Diagram</span>\n          </button>\n          <button @click=\"exportDrawIOXML()\" class=\"btn btn-info\" v-if=\"drawIoSVG && !isEditing\">\n            <font-awesome-icon icon=\"eye\"></font-awesome-icon><span> Export diagram</span>\n          </button>\n        </span>\n      </div>\n      <div v-if=\"!isHidden\">\n        <iframe\n          :v-if=\"!isHidden\"\n          id=\"myDiv\"\n          src=\"https://embed.diagrams.net/?nav=1&edit=_blank&layers=1&highlight=0000ff&embed=1&noSaveBtn=1&libraries=1&proto=json\"\n        />\n      </div>\n    </div>\n    <b-modal ref=\"removeDiagramEntity\" id=\"removeDiagramEntity\">\n      <span slot=\"modal-title\"\n        ><span id=\"eaDesignItApp.landscapeView.delete.question\" data-cy=\"landscapeViewDeleteDialogHeading\"\n          >Confirm delete operation</span\n        ></span\n      >\n      <div class=\"modal-body\">\n        <p id=\"jhi-delete-landscapeView-heading\">Are you sure you want to delete this Landscape View?</p>\n      </div>\n      <div slot=\"modal-footer\">\n        <button type=\"button\" class=\"btn btn-secondary\" v-on:click=\"closeDialog()\">Cancel</button>\n        <button\n          type=\"button\"\n          class=\"btn btn-primary\"\n          id=\"jhi-confirm-delete-landscapeView\"\n          data-cy=\"entityConfirmDeleteButton\"\n          v-on:click=\"deleteDiagram()\"\n        >\n          Delete\n        </button>\n      </div>\n    </b-modal>\n\n    <b-modal ref=\"detachFlowEntity\" id=\"detachFlowEntity\">\n      <span slot=\"modal-title\"\n        ><span id=\"eaDesignItApp.landscapeView.delete.question\" data-cy=\"landscapeViewDeleteDialogHeading\"\n          >Confirm delete operation</span\n        ></span\n      >\n      <div class=\"modal-body\">\n        <p id=\"jhi-delete-landscapeView-heading\">Are you sure you want to detach this Functional Flow?</p>\n      </div>\n      <div slot=\"modal-footer\">\n        <button type=\"button\" class=\"btn btn-secondary\" v-on:click=\"closeDetachDialog()\">Cancel</button>\n        <button\n          type=\"button\"\n          class=\"btn btn-primary\"\n          id=\"jhi-confirm-delete-landscapeView\"\n          data-cy=\"entityConfirmDeleteButton\"\n          v-on:click=\"detachFunctionalFlow()\"\n        >\n          Delete\n        </button>\n      </div>\n    </b-modal>\n\n    <b-modal ref=\"addExistingEntity\" id=\"addExistingEntity\">\n      <span slot=\"modal-title\">Search for exising Functional Flow</span>\n      <div class=\"modal-body\">\n        <p id=\"jhi-delete-landscapeView-heading\">Search for exising Functional Flow</p>\n        <div class=\"table-responsive\" v-if=\"functionalFlows && functionalFlows.length > 0\">\n          <table class=\"table table-striped\" aria-describedby=\"functionalFlows\">\n            <thead>\n              <tr>\n                <th scope=\"row\"><span>Alias</span></th>\n                <th scope=\"row\"><span>Description</span></th>\n                <th scope=\"row\"><span>Documentation URL</span></th>\n                <th scope=\"row\"><span>Documentation URL 2</span></th>\n                <th scope=\"row\"><span>Interfaces</span></th>\n                <th></th>\n              </tr>\n            </thead>\n            <tbody>\n              <tr v-for=\"functionalFlow in functionalFlows\" :key=\"functionalFlow.id\" data-cy=\"entityTable\">\n                <td>\n                  <router-link :to=\"{ name: 'FunctionalFlowView', params: { functionalFlowId: functionalFlow.id } }\" target=\"_blank\">{{\n                    functionalFlow.alias\n                  }}</router-link>\n                </td>\n                <td>{{ functionalFlow.description }}</td>\n                <td>\n                  <a :href=\"functionalFlow.documentationURL\" target=\"_blank\">{{\n                    functionalFlow.documentationURL ? functionalFlow.documentationURL.substring(0, 20) : ''\n                  }}</a>\n                </td>\n                <td>\n                  <a :href=\"functionalFlow.documentationURL2\" target=\"_blank\">{{\n                    functionalFlow.documentationURL2 ? functionalFlow.documentationURL2.substring(0, 20) : ''\n                  }}</a>\n                </td>\n                <td>\n                  <span\n                    v-for=\"(step, i) in functionalFlow.steps\"\n                    :set=\"(interfaces = step.flowInterface)\"\n                    :key=\"step.id\"\n                    :title=\"\n                      '[ ' +\n                      interfaces.source.name +\n                      ' / ' +\n                      interfaces.target.name +\n                      ' ]' +\n                      (interfaces.protocol ? ' (' + interfaces.protocol.type + ') ' : '')\n                    \"\n                    >{{ i > 0 ? ', ' : '' }}\n                    {{ interfaces.alias }}\n                  </span>\n                </td>\n                <td>{{ functionalFlow.startDate }}</td>\n                <td>{{ functionalFlow.endDate }}</td>\n                <td class=\"text-right\">\n                  <div class=\"btn-group\">\n                    <button @click=\"addNew(functionalFlow)\" class=\"btn btn-primary btn-sm edit\" data-cy=\"entityEditButton\">\n                      <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon>\n                      <span class=\"d-none d-md-inline\">Add</span>\n                    </button>\n                  </div>\n                </td>\n              </tr>\n            </tbody>\n          </table>\n        </div>\n      </div>\n      <div slot=\"modal-footer\">\n        <button type=\"button\" class=\"btn btn-secondary\" v-on:click=\"closeSearchFlow()\">Cancel</button>\n        <button\n          type=\"button\"\n          class=\"btn btn-primary\"\n          id=\"jhi-confirm-delete-landscapeView\"\n          data-cy=\"entityConfirmDeleteButton\"\n          v-on:click=\"addNew()\"\n        >\n          Add\n        </button>\n      </div>\n    </b-modal>\n  </div>\n</template>\n<style>\niframe {\n  border: 5;\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 100%;\n  height: 100%;\n}\n.mycolor {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n.modal-dialog {\n  max-width: 80%;\n}\n</style>\n\n<script lang=\"ts\" src=\"./landscape-view-details.component.ts\"></script>\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/landscape-view/landscape-view-details.component.ts?vue&type=script&lang=ts&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/landscape-view/landscape-view-details.component.ts?vue&type=script&lang=ts& ***!
  \****************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vue_class_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue-class-component */ "./node_modules/vue-class-component/dist/vue-class-component.esm.js");
/* harmony import */ var _shared_data_data_utils_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/shared/data/data-utils.service */ "./src/main/webapp/app/shared/data/data-utils.service.ts");
/* harmony import */ var _shared_model_flow_interface_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/shared/model/flow-interface.model */ "./src/main/webapp/app/shared/model/flow-interface.model.ts");
/* harmony import */ var _shared_model_functional_flow_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/shared/model/functional-flow.model */ "./src/main/webapp/app/shared/model/functional-flow.model.ts");
/* harmony import */ var _shared_model_functional_flow_step_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/shared/model/functional-flow-step.model */ "./src/main/webapp/app/shared/model/functional-flow-step.model.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var LandscapeViewDetails = /** @class */ (function (_super) {
    __extends(LandscapeViewDetails, _super);
    function LandscapeViewDetails() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.landscapeView = {};
        _this.plantUMLImage = '';
        _this.drawIoSVG = '';
        _this.isHidden = true;
        _this.isEditing = false;
        _this.drawIOToBeSaved = false;
        _this.emptySteps = [];
        _this.functionalFlows = [];
        _this.toBeSaved = false;
        _this.reorderAlias = false;
        //for description update
        _this.reorderAliasflowToSave = [];
        //for reordering update
        _this.reorderStepToSave = [];
        return _this;
    }
    Object.defineProperty(LandscapeViewDetails.prototype, "allAlias", {
        get: function () {
            return this.landscapeView.flows.map(function (f) { return f.alias; });
        },
        enumerable: false,
        configurable: true
    });
    LandscapeViewDetails.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.landscapeViewId) {
                vm.retrieveLandscapeView(to.params.landscapeViewId);
            }
        });
    };
    LandscapeViewDetails.prototype.retrieveLandscapeView = function (landscapeViewId) {
        var _this = this;
        var step = new _shared_model_functional_flow_step_model__WEBPACK_IMPORTED_MODULE_4__.FunctionalFlowStep();
        step.description = 'EMPTYSTEP';
        var inter = new _shared_model_flow_interface_model__WEBPACK_IMPORTED_MODULE_2__.FlowInterface();
        step.flowInterface = inter;
        if (this.emptySteps.length == 0)
            this.emptySteps.push(step);
        this.landscapeViewService()
            .find(landscapeViewId)
            .then(function (res) {
            _this.landscapeView = res;
            if (_this.landscapeView.compressedDrawSVG) {
                _this.drawIoSVG = decodeURIComponent(escape(window.atob(_this.landscapeView.compressedDrawSVG)));
            }
            _this.getPlantUML(landscapeViewId);
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    LandscapeViewDetails.prototype.previousState = function () {
        this.$router.go(-1);
    };
    LandscapeViewDetails.prototype.getPlantUML = function (landscapeViewId) {
        var _this = this;
        this.landscapeViewService()
            .getPlantUML(landscapeViewId)
            .then(function (res) {
            _this.plantUMLImage = res.data;
        }, function (err) {
            console.log(err);
        });
    };
    LandscapeViewDetails.prototype.mounted = function () {
        window.addEventListener('message', this.receiveMessage);
    };
    LandscapeViewDetails.prototype.editDiagram = function () {
        var _this = this;
        if (!this.landscapeView.compressedDrawXML) {
            this.landscapeViewService()
                .getDrawIO(this.landscapeView.id)
                .then(function (res) {
                _this.landscapeView.compressedDrawXML = res.data;
                _this.isHidden = false;
                _this.isEditing = true;
            }, function (err) {
                console.log(err);
            });
        }
        else {
            this.isHidden = false;
            this.isEditing = true;
        }
    };
    LandscapeViewDetails.prototype.saveDiagram = function () {
        var _this = this;
        var dto = {};
        dto.id = this.landscapeView.id;
        dto.compressedDrawXML = this.landscapeView.compressedDrawXML;
        console.log(this.drawIoSVG);
        dto.compressedDrawSVG = window.btoa(unescape(encodeURIComponent(this.drawIoSVG)));
        this.landscapeViewService()
            .partialUpdate(dto)
            .then(function (res) {
            _this.drawIOToBeSaved = false;
        }, function (err) {
            _this.alertService().showHttpError(_this, err.response);
        });
    };
    LandscapeViewDetails.prototype.deleteDiagram = function () {
        var _this = this;
        this.landscapeViewService()
            .deleteDrawInformation(this.landscapeView.id)
            .then(function (res) {
            _this.drawIOToBeSaved = false;
            _this.drawIoSVG = '';
        }, function (err) {
            _this.alertService().showHttpError(_this, err.response);
        });
        this.$refs.removeDiagramEntity.hide();
    };
    LandscapeViewDetails.prototype.receiveMessage = function (evt) {
        var iframe = document.getElementById('myDiv');
        //console.log(evt)
        if (evt.data.length > 0) {
            var msg = JSON.parse(evt.data);
            if (msg.event == 'init') {
                //iframe.contentWindow.postMessage(JSON.stringify({action: 'load',autosave: 1, xml: '<mxGraphModel dx="1350" dy="793" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="850" pageHeight="1100" math="0" shadow="0"><root><mxCell id="0" /><mxCell id="1" parent="0" /><mxCell id="vISkdTzWN7_PVdaD8Uo9-1" value="" style="ellipse;whiteSpace=wrap;html=1;aspect=fixed;" parent="1" vertex="1"><mxGeometry x="310" y="170" width="80" height="80" as="geometry" /></mxCell><mxCell id="vISkdTzWN7_PVdaD8Uo9-2" value="TEST" style="whiteSpace=wrap;html=1;aspect=fixed;" parent="1" vertex="1"><mxGeometry x="140" y="250" width="80" height="80" as="geometry" /></mxCell><mxCell id="vISkdTzWN7_PVdaD8Uo9-3" value="" style="endArrow=classic;html=1;rounded=0;exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0;entryY=1;entryDx=0;entryDy=0;" parent="1" source="vISkdTzWN7_PVdaD8Uo9-2" target="vISkdTzWN7_PVdaD8Uo9-1" edge="1"><mxGeometry width="50" height="50" relative="1" as="geometry"><mxPoint x="400" y="430" as="sourcePoint" /><mxPoint x="450" y="380" as="targetPoint" /></mxGeometry></mxCell></root></mxGraphModel>'}), '*');
                iframe.contentWindow.postMessage(JSON.stringify({ action: 'load', autosave: 1, xml: this.landscapeView.compressedDrawXML }), '*');
            }
            else if (msg.event == 'export') {
                // Extracts SVG DOM from data URI to enable links
                var svg = atob(msg.data.substring(msg.data.indexOf(',') + 1));
                this.drawIoSVG = svg;
                this.isHidden = true;
                this.isEditing = false;
                this.drawIOToBeSaved = true;
            }
            else if (msg.event == 'save') {
                iframe.contentWindow.postMessage(JSON.stringify({ action: 'export', format: 'xmlsvg', xml: msg.xml, spin: 'Updating page' }), '*');
                console.log(msg.xml);
                this.drawIOToBeSaved = true;
                this.landscapeView.compressedDrawXML = msg.xml;
            }
            else if (msg.event == 'exit') {
                this.isHidden = true;
                this.isEditing = false;
            }
        }
    };
    LandscapeViewDetails.prototype.exportDrawIOXML = function () {
        var xmlContent = 'data:text/xml;charset=utf-8,';
        xmlContent += this.landscapeView.compressedDrawXML;
        var data = encodeURI(xmlContent);
        var link = document.createElement('a');
        link.setAttribute('href', data);
        link.setAttribute('download', 'draw-io-export-' + this.landscapeView.diagramName.replace(/ /g, '-') + '.xml');
        link.click();
    };
    LandscapeViewDetails.prototype.prepareRemove = function (instance) {
        if (this.$refs.removeDiagramEntity) {
            this.$refs.removeDiagramEntity.show();
        }
    };
    LandscapeViewDetails.prototype.closeDialog = function () {
        this.$refs.removeDiagramEntity.hide();
    };
    LandscapeViewDetails.prototype.prepareToDetach = function (index) {
        if (this.$refs.detachFlowEntity) {
            this.$refs.detachFlowEntity.show();
        }
        this.flowToDetach = index;
    };
    LandscapeViewDetails.prototype.detachFunctionalFlow = function () {
        var _this = this;
        this.landscapeView.flows.splice(this.flowToDetach, 1);
        this.landscapeViewService()
            .update(this.landscapeView)
            .then(function (res) {
            _this.landscapeView = res;
            _this.closeDetachDialog();
            _this.getPlantUML(_this.landscapeView.id);
        });
    };
    LandscapeViewDetails.prototype.closeDetachDialog = function () {
        this.$refs.detachFlowEntity.hide();
    };
    LandscapeViewDetails.prototype.openSearchFlow = function () {
        var _this = this;
        if (this.$refs.addExistingEntity) {
            this.functionalFlowService()
                .retrieve()
                .then(function (res) {
                console.log(res.data);
                _this.functionalFlows = res.data.filter(function (f) { return f.alias != null; });
                _this.$refs.addExistingEntity.show();
            });
        }
    };
    LandscapeViewDetails.prototype.closeSearchFlow = function () {
        this.$refs.addExistingEntity.hide();
    };
    LandscapeViewDetails.prototype.addNew = function (functionalFlow) {
        var _this = this;
        if (!this.landscapeView.flows) {
            this.landscapeView.flows = [];
        }
        this.landscapeView.flows.push(functionalFlow);
        this.toBeSaved = true;
        this.landscapeViewService()
            .update(this.landscapeView)
            .then(function (res) {
            _this.landscapeView = res;
            _this.closeSearchFlow();
            _this.getPlantUML(_this.landscapeView.id);
        });
    };
    // FLOW REORGANIZATION
    LandscapeViewDetails.prototype.startReorder = function () {
        this.reorderAlias = true;
        this.reorderAliasflowToSave = [];
        this.reorderStepToSave = [];
    };
    LandscapeViewDetails.prototype.reorder = function (step, functionalFlow, event) {
        var newFlowId = parseInt(event.target.value);
        var newFunctionalFlow = this.landscapeView.flows.find(function (f) { return f.id === newFlowId; });
        // This is only for rendering page before save...
        // add interface in new Flow
        newFunctionalFlow.steps.push(step);
        // remove interface from old Flow
        functionalFlow.steps = functionalFlow.steps.filter(function (i) { return i.id != step.id; });
        this.addStepToSave(newFunctionalFlow, step);
        // Add old & new Flows for later update by REST call
        // if (this.reorderAliasflowToSave.filter(e => e.id === functionalFlow.id).length === 0) {
        //   this.reorderAliasflowToSave.push(functionalFlow);
        // }
        // if (this.reorderAliasflowToSave.filter(e => e.id === newFunctionalFlow.id).length === 0) {
        //   this.reorderAliasflowToSave.push(newFunctionalFlow);
        // }
        this.reorderAllSteps(functionalFlow);
        this.reorderAllSteps(newFunctionalFlow);
    };
    LandscapeViewDetails.prototype.addStepToSave = function (newFunctionalFlow, step) {
        // remove if already exist to avoid duplicate
        // step.flow = newFunctionalFlow this cause an erro, for looping steps?
        var newFunctionalFlowSimplified = new _shared_model_functional_flow_model__WEBPACK_IMPORTED_MODULE_3__.FunctionalFlow();
        newFunctionalFlowSimplified = __assign({}, newFunctionalFlow);
        newFunctionalFlowSimplified.steps = [];
        step.flow = newFunctionalFlowSimplified;
        this.reorderStepToSave.push(step);
    };
    LandscapeViewDetails.prototype.changeDescription = function (functionalFlow) {
        // Add old & new Flows for later update by REST call
        this.reorderAliasflowToSave = this.reorderAliasflowToSave.filter(function (e) { return e.id != functionalFlow.id; });
        this.reorderAliasflowToSave.push(functionalFlow);
    };
    LandscapeViewDetails.prototype.changeStepDescription = function (functionalFlow, step) {
        // Add old & new Flows for later update by REST call
        this.reorderStepToSave = this.reorderStepToSave.filter(function (s) { return s.id != step.id; });
        var newFunctionalFlowSimplified = new _shared_model_functional_flow_model__WEBPACK_IMPORTED_MODULE_3__.FunctionalFlow();
        newFunctionalFlowSimplified = __assign({}, functionalFlow);
        newFunctionalFlowSimplified.steps = [];
        step.flow = newFunctionalFlowSimplified;
        this.reorderStepToSave.push(step);
    };
    LandscapeViewDetails.prototype.cancelReorder = function () {
        var _this = this;
        this.landscapeViewService()
            .find(this.landscapeView.id)
            .then(function (res) {
            _this.landscapeView = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
        this.reorderAlias = false;
        this.reorderAliasflowToSave = [];
    };
    LandscapeViewDetails.prototype.saveReorder = function () {
        var _this = this;
        var promises = [];
        this.reorderAliasflowToSave.forEach(function (flow) {
            promises.push(_this.functionalFlowService().update(flow));
        });
        this.reorderStepToSave.forEach(function (step) {
            promises.push(_this.functionalFlowStepService().update(step));
        });
        Promise.all(promises).then(function (res) {
            _this.retrieveLandscapeView(_this.landscapeView.id);
            _this.reorderAlias = false;
            _this.reorderAliasflowToSave = [];
        });
    };
    LandscapeViewDetails.prototype.swap = function (flow, i, j) {
        var tmp = flow.steps[i];
        flow.steps.splice(i, 1, flow.steps[j]);
        flow.steps.splice(j, 1, tmp);
        // reorder all steps in flow
        this.reorderAllSteps(flow);
    };
    LandscapeViewDetails.prototype.reorderAllSteps = function (flow) {
        var _this = this;
        flow.steps.forEach(function (step, i) {
            if (step.stepOrder !== i + 1) {
                step.stepOrder = i + 1;
                _this.addStepToSave(flow, step);
            }
        });
    };
    LandscapeViewDetails.prototype.exportExcel = function () {
        var _this = this;
        this.flowImportService()
            .downloadFile(this.landscapeView.id)
            .then(function (response) {
            var url = URL.createObjectURL(new Blob([response.data], {
                type: 'application/vnd.ms-excel',
            }));
            var link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', _this.landscapeView.diagramName + '.xls');
            document.body.appendChild(link);
            link.click();
        });
    };
    LandscapeViewDetails.prototype.exportPlantUML = function () {
        var _this = this;
        this.landscapeViewService()
            .getPlantUMLSource(this.landscapeView.id)
            .then(function (response) {
            var url = URL.createObjectURL(new Blob([response.data], {
                type: 'text/plain',
            }));
            var link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', _this.landscapeView.diagramName + '-plantuml.txt');
            document.body.appendChild(link);
            link.click();
        });
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('landscapeViewService'),
        __metadata("design:type", Function)
    ], LandscapeViewDetails.prototype, "landscapeViewService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], LandscapeViewDetails.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('accountService'),
        __metadata("design:type", Function)
    ], LandscapeViewDetails.prototype, "accountService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowService'),
        __metadata("design:type", Function)
    ], LandscapeViewDetails.prototype, "functionalFlowService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowStepService'),
        __metadata("design:type", Function)
    ], LandscapeViewDetails.prototype, "functionalFlowStepService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('flowImportService'),
        __metadata("design:type", Function)
    ], LandscapeViewDetails.prototype, "flowImportService", void 0);
    LandscapeViewDetails = __decorate([
        vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component
    ], LandscapeViewDetails);
    return LandscapeViewDetails;
}((0,vue_class_component__WEBPACK_IMPORTED_MODULE_5__.mixins)(_shared_data_data_utils_service__WEBPACK_IMPORTED_MODULE_1__["default"])));
/* harmony default export */ __webpack_exports__["default"] = (LandscapeViewDetails);


/***/ }),

/***/ "./src/main/webapp/app/shared/data/data-utils.service.ts":
/*!***************************************************************!*\
  !*** ./src/main/webapp/app/shared/data/data-utils.service.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

/**
 * An utility service for data.
 */
var JhiDataUtils = /** @class */ (function (_super) {
    __extends(JhiDataUtils, _super);
    function JhiDataUtils() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * Method to abbreviate the text given
     */
    JhiDataUtils.prototype.abbreviate = function (text, append) {
        if (append === void 0) { append = '...'; }
        if (text.length < 30) {
            return text;
        }
        return text ? text.substring(0, 15) + append + text.slice(-10) : '';
    };
    /**
     * Method to find the byte size of the string provides
     */
    JhiDataUtils.prototype.byteSize = function (base64String) {
        return this.formatAsBytes(this.size(base64String));
    };
    /**
     * Method to open file
     */
    JhiDataUtils.prototype.openFile = function (contentType, data) {
        var byteCharacters = atob(data);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], {
            type: contentType,
        });
        var objectURL = URL.createObjectURL(blob);
        var win = window.open(objectURL);
        if (win) {
            win.onload = function () { return URL.revokeObjectURL(objectURL); };
        }
    };
    /**
     * Method to convert the file to base64
     */
    JhiDataUtils.prototype.toBase64 = function (file, cb) {
        var fileReader = new FileReader();
        fileReader.readAsDataURL(file);
        fileReader.onload = function (e) {
            var base64Data = e.target.result.substr(e.target.result.indexOf('base64,') + 'base64,'.length);
            cb(base64Data);
        };
    };
    /**
     * Method to clear the input
     */
    JhiDataUtils.prototype.clearInputImage = function (entity, elementRef, field, fieldContentType, idInput) {
        if (entity && field && fieldContentType) {
            if (Object.prototype.hasOwnProperty.call(entity, field)) {
                entity[field] = null;
            }
            if (Object.prototype.hasOwnProperty.call(entity, fieldContentType)) {
                entity[fieldContentType] = null;
            }
            if (elementRef && idInput && elementRef.nativeElement.querySelector('#' + idInput)) {
                elementRef.nativeElement.querySelector('#' + idInput).value = null;
            }
        }
    };
    JhiDataUtils.prototype.endsWith = function (suffix, str) {
        return str.indexOf(suffix, str.length - suffix.length) !== -1;
    };
    JhiDataUtils.prototype.paddingSize = function (value) {
        if (this.endsWith('==', value)) {
            return 2;
        }
        if (this.endsWith('=', value)) {
            return 1;
        }
        return 0;
    };
    JhiDataUtils.prototype.size = function (value) {
        return (value.length / 4) * 3 - this.paddingSize(value);
    };
    JhiDataUtils.prototype.formatAsBytes = function (size) {
        return size.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' bytes';
    };
    JhiDataUtils.prototype.setFileData = function (event, entity, field, isImage) {
        if (event && event.target.files && event.target.files[0]) {
            var file_1 = event.target.files[0];
            if (isImage && !/^image\//.test(file_1.type)) {
                return;
            }
            this.toBase64(file_1, function (base64Data) {
                entity[field] = base64Data;
                entity["".concat(field, "ContentType")] = file_1.type;
            });
        }
    };
    /**
     * Method to download file
     */
    JhiDataUtils.prototype.downloadFile = function (contentType, data, fileName) {
        var byteCharacters = atob(data);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], {
            type: contentType,
        });
        var tempLink = document.createElement('a');
        tempLink.href = window.URL.createObjectURL(blob);
        tempLink.download = fileName;
        tempLink.target = '_blank';
        tempLink.click();
    };
    /**
     * Method to parse header links
     */
    JhiDataUtils.prototype.parseLinks = function (header) {
        var links = {};
        if (header === null || header.indexOf(',') === -1) {
            return links;
        }
        // Split parts by comma
        var parts = header.split(',');
        // Parse each part into a named link
        parts.forEach(function (p) {
            if (p.indexOf('>;') === -1) {
                return;
            }
            var section = p.split('>;');
            var url = section[0].replace(/<(.*)/, '$1').trim();
            var queryString = { page: null };
            url.replace(new RegExp(/([^?=&]+)(=([^&]*))?/g), function ($0, $1, $2, $3) {
                queryString[$1] = $3;
            });
            var page = queryString.page;
            if (typeof page === 'string') {
                page = parseInt(page, 10);
            }
            var name = section[1].replace(/rel="(.*)"/, '$1').trim();
            links[name] = page;
        });
        return links;
    };
    JhiDataUtils = __decorate([
        vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component
    ], JhiDataUtils);
    return JhiDataUtils;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (JhiDataUtils);


/***/ }),

/***/ "./src/main/webapp/app/shared/model/flow-interface.model.ts":
/*!******************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/flow-interface.model.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FlowInterface": function() { return /* binding */ FlowInterface; }
/* harmony export */ });
var FlowInterface = /** @class */ (function () {
    function FlowInterface(id, alias, status, documentationURL, documentationURL2, description, startDate, endDate, dataFlows, source, target, sourceComponent, targetComponent, protocol, owner, steps) {
        this.id = id;
        this.alias = alias;
        this.status = status;
        this.documentationURL = documentationURL;
        this.documentationURL2 = documentationURL2;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.dataFlows = dataFlows;
        this.source = source;
        this.target = target;
        this.sourceComponent = sourceComponent;
        this.targetComponent = targetComponent;
        this.protocol = protocol;
        this.owner = owner;
        this.steps = steps;
    }
    return FlowInterface;
}());



/***/ }),

/***/ "./src/main/webapp/app/shared/model/functional-flow-step.model.ts":
/*!************************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/functional-flow-step.model.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FunctionalFlowStep": function() { return /* binding */ FunctionalFlowStep; }
/* harmony export */ });
var FunctionalFlowStep = /** @class */ (function () {
    function FunctionalFlowStep(id, description, stepOrder, flowInterface, flow) {
        this.id = id;
        this.description = description;
        this.stepOrder = stepOrder;
        this.flowInterface = flowInterface;
        this.flow = flow;
    }
    return FunctionalFlowStep;
}());



/***/ }),

/***/ "./src/main/webapp/app/shared/model/functional-flow.model.ts":
/*!*******************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/functional-flow.model.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FunctionalFlow": function() { return /* binding */ FunctionalFlow; }
/* harmony export */ });
var FunctionalFlow = /** @class */ (function () {
    function FunctionalFlow(id, alias, description, comment, status, documentationURL, documentationURL2, startDate, endDate, steps, owner, landscapes, dataFlows) {
        this.id = id;
        this.alias = alias;
        this.description = description;
        this.comment = comment;
        this.status = status;
        this.documentationURL = documentationURL;
        this.documentationURL2 = documentationURL2;
        this.startDate = startDate;
        this.endDate = endDate;
        this.steps = steps;
        this.owner = owner;
        this.landscapes = landscapes;
        this.dataFlows = dataFlows;
    }
    return FunctionalFlow;
}());



/***/ }),

/***/ "./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue":
/*!********************************************************************************!*\
  !*** ./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _landscape_view_details_vue_vue_type_template_id_5cbb64ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./landscape-view-details.vue?vue&type=template&id=5cbb64ae& */ "./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=template&id=5cbb64ae&");
/* harmony import */ var _landscape_view_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./landscape-view-details.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/landscape-view/landscape-view-details.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _landscape_view_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./landscape-view-details.vue?vue&type=style&index=0&lang=css& */ "./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _landscape_view_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _landscape_view_details_vue_vue_type_template_id_5cbb64ae___WEBPACK_IMPORTED_MODULE_0__.render,
  _landscape_view_details_vue_vue_type_template_id_5cbb64ae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/landscape-view/landscape-view-details.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/landscape-view/landscape-view-details.component.ts?vue&type=script&lang=ts&":
/*!******************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/landscape-view/landscape-view-details.component.ts?vue&type=script&lang=ts& ***!
  \******************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_landscape_view_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./landscape-view-details.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/landscape-view/landscape-view-details.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_landscape_view_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=template&id=5cbb64ae&":
/*!***************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=template&id=5cbb64ae& ***!
  \***************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_template_id_5cbb64ae___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_template_id_5cbb64ae___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_template_id_5cbb64ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./landscape-view-details.vue?vue&type=template&id=5cbb64ae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=template&id=5cbb64ae&");


/***/ }),

/***/ "./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css&":
/*!*****************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css& ***!
  \*****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-style-loader/index.js!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./landscape-view-details.vue?vue&type=style&index=0&lang=css& */ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = function(key) { return _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_landscape_view_details_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }.bind(0, __WEBPACK_IMPORT_KEY__)
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=template&id=5cbb64ae&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=template&id=5cbb64ae& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "row justify-content-center" },
    [
      _c("div", { staticClass: "col-12" }, [
        _vm.landscapeView
          ? _c(
              "div",
              [
                _c(
                  "h2",
                  {
                    staticClass: "jh-entity-heading",
                    attrs: { "data-cy": "landscapeViewDetailsHeading" },
                  },
                  [
                    _c(
                      "span",
                      [
                        _c("font-awesome-icon", {
                          staticStyle: {
                            color: "Tomato",
                            "font-size": "0.7em",
                          },
                          attrs: { icon: "map" },
                        }),
                        _vm._v(
                          " Landscape -\n          " +
                            _vm._s(_vm.landscapeView.diagramName)
                        ),
                      ],
                      1
                    ),
                  ]
                ),
                _vm._v(" "),
                _c("dl", { staticClass: "row jh-entity-details" }, [
                  _vm._m(0),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.landscapeView.viewpoint))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(1),
                  _vm._v(" "),
                  _c("dd", [
                    _c("span", [_vm._v(_vm._s(_vm.landscapeView.diagramName))]),
                  ]),
                  _vm._v(" "),
                  _vm._m(2),
                  _vm._v(" "),
                  _c("dd", [
                    _vm.landscapeView.owner
                      ? _c(
                          "div",
                          [
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "OwnerView",
                                    params: {
                                      ownerId: _vm.landscapeView.owner.id,
                                    },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(_vm.landscapeView.owner.name))]
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ]),
                  _vm._v(" "),
                  _vm._m(3),
                  _vm._v(" "),
                  _c(
                    "dd",
                    _vm._l(
                      _vm.landscapeView.capabilities,
                      function (capabilities, i) {
                        return _c(
                          "span",
                          { key: capabilities.id },
                          [
                            _vm._v(
                              _vm._s(i > 0 ? ", " : "") + "\n            "
                            ),
                            _c(
                              "router-link",
                              {
                                attrs: {
                                  to: {
                                    name: "CapabilityView",
                                    params: { capabilityId: capabilities.id },
                                  },
                                },
                              },
                              [_vm._v(_vm._s(capabilities.name))]
                            ),
                          ],
                          1
                        )
                      }
                    ),
                    0
                  ),
                ]),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info",
                    attrs: {
                      type: "submit",
                      "data-cy": "entityDetailsBackButton",
                    },
                    on: {
                      click: function ($event) {
                        $event.preventDefault()
                        return _vm.previousState()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "arrow-left" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v(" Back")]),
                  ],
                  1
                ),
                _vm._v(" "),
                _vm.landscapeView.id
                  ? _c("router-link", {
                      attrs: {
                        to: {
                          name: "LandscapeViewEdit",
                          params: { landscapeViewId: _vm.landscapeView.id },
                        },
                        custom: "",
                      },
                      scopedSlots: _vm._u(
                        [
                          {
                            key: "default",
                            fn: function (ref) {
                              var navigate = ref.navigate
                              return [
                                _vm.accountService().writeAuthorities
                                  ? _c(
                                      "button",
                                      {
                                        staticClass: "btn btn-primary",
                                        on: { click: navigate },
                                      },
                                      [
                                        _c("font-awesome-icon", {
                                          attrs: { icon: "pencil-alt" },
                                        }),
                                        _vm._v(" "),
                                        _c("span", [_vm._v(" Edit")]),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ]
                            },
                          },
                        ],
                        null,
                        false,
                        1874555495
                      ),
                    })
                  : _vm._e(),
              ],
              1
            )
          : _vm._e(),
        _vm._v(" "),
        _vm._m(4),
        _vm._v(" "),
        _c("br"),
        _vm._v(" "),
        _c("h3", [_vm._v("Landscape diagram")]),
        _vm._v(" "),
        _c("div", [
          _c("div", {
            staticClass: "table-responsive",
            domProps: { innerHTML: _vm._s(_vm.plantUMLImage) },
          }),
          _vm._v(" "),
          _c("div", { staticClass: "col-12" }, [
            _vm.plantUMLImage
              ? _c(
                  "button",
                  {
                    staticClass: "btn btn-warning",
                    staticStyle: {
                      "font-size": "0.7em",
                      padding: "3px",
                      margin: "3px",
                    },
                    on: {
                      click: function ($event) {
                        return _vm.exportPlantUML()
                      },
                    },
                  },
                  [_c("span", [_vm._v("Export plantuml")])]
                )
              : _vm._e(),
            _vm._v(" "),
            _c("br"),
            _c("br"),
          ]),
        ]),
        _vm._v(" "),
        _c(
          "h3",
          [
            _c("font-awesome-icon", {
              staticStyle: { color: "Tomato", "font-size": "0.7em" },
              attrs: { icon: "project-diagram" },
            }),
            _vm._v(" Functional Flows\n      "),
            _c("font-awesome-icon", {
              staticStyle: { color: "green" },
              attrs: { icon: "file-excel" },
              on: {
                click: function ($event) {
                  return _vm.exportExcel()
                },
              },
            }),
          ],
          1
        ),
        _vm._v(" "),
        _c("br"),
        _vm._v(" "),
        _c("table", { staticClass: "table" }, [
          _c("thead", [
            _c("tr", [
              _vm._m(5),
              _vm._v(" "),
              _vm.reorderAlias
                ? _c("th", { attrs: { scope: "row" } })
                : _vm._e(),
              _vm._v(" "),
              _vm.reorderAlias
                ? _c("th", { attrs: { scope: "row" } })
                : _vm._e(),
              _vm._v(" "),
              _vm._m(6),
              _vm._v(" "),
              _vm._m(7),
              _vm._v(" "),
              _vm._m(8),
              _vm._v(" "),
              _vm._m(9),
              _vm._v(" "),
              _vm._m(10),
              _vm._v(" "),
              _vm._m(11),
              _vm._v(" "),
              _vm._m(12),
              _vm._v(" "),
              _c("th", { attrs: { scope: "row" } }),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "tbody",
            [
              _vm._l(_vm.landscapeView.flows, function (functionalFlow, i) {
                return [
                  _vm._l(
                    functionalFlow.steps != null &&
                      functionalFlow.steps.length > 0
                      ? functionalFlow.steps
                      : _vm.emptySteps,
                    function (step, j) {
                      return [
                        _c(
                          "tr",
                          { key: step.id, class: i % 2 == 0 ? "mycolor" : "" },
                          [
                            _c("td", [
                              !_vm.reorderAlias || !step.flowInterface.id
                                ? _c(
                                    "div",
                                    [
                                      functionalFlow && j == 0
                                        ? _c(
                                            "router-link",
                                            {
                                              attrs: {
                                                to: {
                                                  name: "FunctionalFlowView",
                                                  params: {
                                                    functionalFlowId:
                                                      functionalFlow.id,
                                                  },
                                                },
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "\n                    " +
                                                  _vm._s(functionalFlow.alias) +
                                                  "\n                  "
                                              ),
                                            ]
                                          )
                                        : _vm._e(),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.reorderAlias && step.flowInterface.id
                                ? _c("div", [
                                    _c(
                                      "select",
                                      {
                                        staticClass: "btn-success",
                                        attrs: { id: step.id },
                                        on: {
                                          change: function ($event) {
                                            return _vm.reorder(
                                              step,
                                              functionalFlow,
                                              $event
                                            )
                                          },
                                        },
                                      },
                                      _vm._l(
                                        _vm.landscapeView.flows,
                                        function (flow) {
                                          return _c(
                                            "option",
                                            {
                                              key: flow.id,
                                              domProps: {
                                                value: flow.id,
                                                selected:
                                                  flow.id === functionalFlow.id,
                                              },
                                            },
                                            [
                                              _vm._v(
                                                "\n                      " +
                                                  _vm._s(
                                                    flow.alias
                                                      ? flow.alias
                                                      : flow.id
                                                  ) +
                                                  "\n                    "
                                              ),
                                            ]
                                          )
                                        }
                                      ),
                                      0
                                    ),
                                  ])
                                : _vm._e(),
                            ]),
                            _vm._v(" "),
                            _vm.reorderAlias
                              ? _c(
                                  "td",
                                  [
                                    j != 0
                                      ? _c("font-awesome-icon", {
                                          staticClass: "btn-success",
                                          attrs: { icon: "chevron-up" },
                                          on: {
                                            click: function ($event) {
                                              return _vm.swap(
                                                functionalFlow,
                                                j,
                                                j - 1
                                              )
                                            },
                                          },
                                        })
                                      : _vm._e(),
                                  ],
                                  1
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.reorderAlias
                              ? _c(
                                  "td",
                                  [
                                    j != functionalFlow.steps.length - 1 &&
                                    functionalFlow.steps.length > 1
                                      ? _c("font-awesome-icon", {
                                          staticClass: "btn-success",
                                          attrs: { icon: "chevron-down" },
                                          on: {
                                            click: function ($event) {
                                              return _vm.swap(
                                                functionalFlow,
                                                j,
                                                j + 1
                                              )
                                            },
                                          },
                                        })
                                      : _vm._e(),
                                  ],
                                  1
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _c("td", [
                              j == 0
                                ? _c("span", [
                                    !_vm.reorderAlias
                                      ? _c("span", [
                                          _vm._v(
                                            _vm._s(functionalFlow.description)
                                          ),
                                        ])
                                      : _c("span", [
                                          _c("textarea", {
                                            directives: [
                                              {
                                                name: "model",
                                                rawName: "v-model",
                                                value:
                                                  functionalFlow.description,
                                                expression:
                                                  "functionalFlow.description",
                                              },
                                            ],
                                            staticStyle: {
                                              width: "100%",
                                              "min-width": "600px",
                                            },
                                            attrs: { rows: "1" },
                                            domProps: {
                                              value: functionalFlow.description,
                                            },
                                            on: {
                                              change: function ($event) {
                                                return _vm.changeDescription(
                                                  functionalFlow
                                                )
                                              },
                                              input: function ($event) {
                                                if ($event.target.composing) {
                                                  return
                                                }
                                                _vm.$set(
                                                  functionalFlow,
                                                  "description",
                                                  $event.target.value
                                                )
                                              },
                                            },
                                          }),
                                        ]),
                                  ])
                                : _vm._e(),
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              step.description != "EMPTYSTEP"
                                ? _c("span", [
                                    _vm._v(
                                      "\n                  " +
                                        _vm._s(step.stepOrder) +
                                        ".\n                  "
                                    ),
                                    !_vm.reorderAlias
                                      ? _c("span", [
                                          _vm._v(_vm._s(step.description)),
                                        ])
                                      : _c("span", [
                                          _c("textarea", {
                                            directives: [
                                              {
                                                name: "model",
                                                rawName: "v-model",
                                                value: step.description,
                                                expression: "step.description",
                                              },
                                            ],
                                            staticStyle: {
                                              width: "100%",
                                              "min-width": "600px",
                                            },
                                            attrs: { rows: "1" },
                                            domProps: {
                                              value: step.description,
                                            },
                                            on: {
                                              change: function ($event) {
                                                return _vm.changeStepDescription(
                                                  functionalFlow,
                                                  step
                                                )
                                              },
                                              input: function ($event) {
                                                if ($event.target.composing) {
                                                  return
                                                }
                                                _vm.$set(
                                                  step,
                                                  "description",
                                                  $event.target.value
                                                )
                                              },
                                            },
                                          }),
                                        ]),
                                  ])
                                : _vm._e(),
                            ]),
                            _vm._v(" "),
                            _c(
                              "td",
                              [
                                step.flowInterface.id
                                  ? _c(
                                      "router-link",
                                      {
                                        attrs: {
                                          to: {
                                            name: "FlowInterfaceView",
                                            params: {
                                              flowInterfaceId:
                                                step.flowInterface.id,
                                            },
                                          },
                                        },
                                      },
                                      [_vm._v(_vm._s(step.flowInterface.alias))]
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              [
                                step.flowInterface.id
                                  ? _c(
                                      "router-link",
                                      {
                                        attrs: {
                                          to: {
                                            name: "ApplicationView",
                                            params: {
                                              applicationId:
                                                step.flowInterface.source.id,
                                            },
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                  " +
                                            _vm._s(
                                              step.flowInterface.source.name
                                            ) +
                                            "\n                "
                                        ),
                                      ]
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              [
                                step.flowInterface.id
                                  ? _c(
                                      "router-link",
                                      {
                                        attrs: {
                                          to: {
                                            name: "ApplicationView",
                                            params: {
                                              applicationId:
                                                step.flowInterface.target.id,
                                            },
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                  " +
                                            _vm._s(
                                              step.flowInterface.target.name
                                            ) +
                                            "\n                "
                                        ),
                                      ]
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "td",
                              [
                                step.flowInterface.protocol
                                  ? _c(
                                      "router-link",
                                      {
                                        attrs: {
                                          to: {
                                            name: "ProtocolView",
                                            params: {
                                              protocolId:
                                                step.flowInterface.protocol.id,
                                            },
                                          },
                                          title:
                                            step.flowInterface.protocol.name,
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                  " +
                                            _vm._s(
                                              step.flowInterface.protocol.type
                                            ) +
                                            "\n                "
                                        ),
                                      ]
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c("td", [
                              step.flowInterface.id
                                ? _c(
                                    "span",
                                    _vm._l(
                                      step.flowInterface.dataFlows,
                                      function (dataFlow, i) {
                                        return _c(
                                          "span",
                                          { key: dataFlow.id },
                                          [
                                            _vm._v(
                                              _vm._s(i > 0 ? ", " : "") +
                                                "\n                    "
                                            ),
                                            _c(
                                              "router-link",
                                              {
                                                staticClass:
                                                  "form-control-static",
                                                attrs: {
                                                  to: {
                                                    name: "DataFlowView",
                                                    params: {
                                                      dataFlowId: dataFlow.id,
                                                    },
                                                  },
                                                  title: dataFlow.resourceName,
                                                },
                                              },
                                              [_vm._v(_vm._s(dataFlow.id))]
                                            ),
                                            dataFlow.items &&
                                            dataFlow.items.length > 0
                                              ? _c("sup", [
                                                  _vm._v(
                                                    "(" +
                                                      _vm._s(
                                                        dataFlow.items.length
                                                      ) +
                                                      ")"
                                                  ),
                                                ])
                                              : _vm._e(),
                                          ],
                                          1
                                        )
                                      }
                                    ),
                                    0
                                  )
                                : _vm._e(),
                            ]),
                            _vm._v(" "),
                            _c("td", { staticClass: "text-right" }, [
                              j == 0 && !_vm.reorderAlias
                                ? _c(
                                    "div",
                                    { staticClass: "btn-group" },
                                    [
                                      _c("router-link", {
                                        attrs: {
                                          to: {
                                            name: "FunctionalFlowView",
                                            params: {
                                              functionalFlowId:
                                                functionalFlow.id,
                                            },
                                          },
                                          custom: "",
                                        },
                                        scopedSlots: _vm._u(
                                          [
                                            {
                                              key: "default",
                                              fn: function (ref) {
                                                var navigate = ref.navigate
                                                return [
                                                  _vm.accountService()
                                                    .writeAuthorities
                                                    ? _c(
                                                        "button",
                                                        {
                                                          staticClass:
                                                            "btn btn-primary btn-sm edit",
                                                          attrs: {
                                                            "data-cy":
                                                              "entityEditButton",
                                                          },
                                                          on: {
                                                            click: navigate,
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "font-awesome-icon",
                                                            {
                                                              attrs: {
                                                                icon: "pencil-alt",
                                                              },
                                                            }
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "d-none d-md-inline",
                                                            },
                                                            [_vm._v("Edit")]
                                                          ),
                                                        ],
                                                        1
                                                      )
                                                    : _vm._e(),
                                                  _vm._v(" "),
                                                  !_vm.accountService()
                                                    .writeAuthorities
                                                    ? _c(
                                                        "button",
                                                        {
                                                          staticClass:
                                                            "btn btn-info btn-sm details",
                                                          attrs: {
                                                            "data-cy":
                                                              "entityDetailsButton",
                                                          },
                                                          on: {
                                                            click: navigate,
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "font-awesome-icon",
                                                            {
                                                              attrs: {
                                                                icon: "eye",
                                                              },
                                                            }
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "d-none d-md-inline",
                                                            },
                                                            [_vm._v("View")]
                                                          ),
                                                        ],
                                                        1
                                                      )
                                                    : _vm._e(),
                                                ]
                                              },
                                            },
                                          ],
                                          null,
                                          true
                                        ),
                                      }),
                                      _vm._v(" "),
                                      _vm.accountService().writeAuthorities
                                        ? _c(
                                            "b-button",
                                            {
                                              staticClass: "btn btn-sm",
                                              attrs: { variant: "warning" },
                                              on: {
                                                click: function ($event) {
                                                  return _vm.prepareToDetach(i)
                                                },
                                              },
                                            },
                                            [
                                              _c("font-awesome-icon", {
                                                attrs: { icon: "times" },
                                              }),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "d-none d-md-inline",
                                                },
                                                [_vm._v("Detach")]
                                              ),
                                            ],
                                            1
                                          )
                                        : _vm._e(),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ]),
                          ]
                        ),
                      ]
                    }
                  ),
                ]
              }),
            ],
            2
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-md-6" }, [
            _vm.accountService().writeAuthorities && !_vm.reorderAlias
              ? _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-success jh-create-entity create-functional-flow",
                    attrs: {
                      id: "jh-create-entity",
                      "data-cy": "entityCreateButton",
                      title:
                        "Edit Flow Alias in order to move interfaces from on flow to another",
                    },
                    on: {
                      click: function ($event) {
                        return _vm.startReorder()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v(" Organize Flows")]),
                  ],
                  1
                )
              : _vm._e(),
            _vm._v(" "),
            _vm.reorderAlias &&
            (_vm.reorderAliasflowToSave.length > 0 ||
              _vm.reorderStepToSave.length > 0)
              ? _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-success jh-create-entity create-functional-flow",
                    attrs: {
                      id: "jh-create-entity",
                      "data-cy": "entityCreateButton",
                      title:
                        "Edit Flow Alias in order to move interfaces from on flow to another",
                    },
                    on: {
                      click: function ($event) {
                        return _vm.saveReorder()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Save")]),
                  ],
                  1
                )
              : _vm._e(),
            _vm._v(" "),
            _vm.reorderAlias
              ? _c(
                  "button",
                  {
                    staticClass:
                      "btn btn-success jh-create-entity create-functional-flow",
                    attrs: {
                      id: "jh-create-entity",
                      "data-cy": "entityCreateButton",
                      title:
                        "Edit Flow Alias in order to move interfaces from on flow to another",
                    },
                    on: {
                      click: function ($event) {
                        return _vm.cancelReorder()
                      },
                    },
                  },
                  [
                    _c("font-awesome-icon", { attrs: { icon: "plus" } }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Cancel")]),
                  ],
                  1
                )
              : _vm._e(),
          ]),
          _vm._v(" "),
          !_vm.reorderAlias
            ? _c(
                "div",
                { staticClass: "col-md-6 d-flex justify-content-end" },
                [
                  _c(
                    "span",
                    [
                      _vm.accountService().writeAuthorities
                        ? _c(
                            "button",
                            {
                              staticClass:
                                "btn btn-primary jh-create-entity create-functional-flow",
                              attrs: {
                                title:
                                  "Add existing Functional flow, from other landscape, with same description, same interfaces",
                              },
                              on: {
                                click: function ($event) {
                                  return _vm.openSearchFlow()
                                },
                              },
                            },
                            [
                              _c("font-awesome-icon", {
                                attrs: { icon: "plus" },
                              }),
                              _vm._v(" "),
                              _c("span", [
                                _vm._v("Add exisintg Functional Flow"),
                              ]),
                            ],
                            1
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.accountService().writeAuthorities
                        ? _c("router-link", {
                            attrs: {
                              to: {
                                name: "FunctionalFlowCreate",
                                query: {
                                  landscapeViewId: _vm.landscapeView.id,
                                },
                              },
                              custom: "",
                            },
                            scopedSlots: _vm._u(
                              [
                                {
                                  key: "default",
                                  fn: function (ref) {
                                    var navigate = ref.navigate
                                    return [
                                      _c(
                                        "button",
                                        {
                                          staticClass:
                                            "btn btn-primary jh-create-entity create-functional-flow",
                                          attrs: {
                                            id: "jh-create-entity",
                                            "data-cy": "entityCreateButton",
                                            title:
                                              "Create a new Functional Flow, based on existing Interfaces or creating new Interfaces",
                                          },
                                          on: { click: navigate },
                                        },
                                        [
                                          _c("font-awesome-icon", {
                                            attrs: { icon: "plus" },
                                          }),
                                          _vm._v(" "),
                                          _c("span", [
                                            _vm._v(
                                              " Create a new Functional Flow "
                                            ),
                                          ]),
                                        ],
                                        1
                                      ),
                                    ]
                                  },
                                },
                              ],
                              null,
                              false,
                              1317263025
                            ),
                          })
                        : _vm._e(),
                    ],
                    1
                  ),
                ]
              )
            : _vm._e(),
        ]),
        _vm._v(" "),
        _c("br"),
        _c("br"),
        _c("br"),
        _c("br"),
        _c("br"),
        _c("br"),
        _vm._v(" "),
        _c("h2", [_vm._v("Draw.io")]),
        _vm._v(" "),
        !_vm.drawIoSVG
          ? _c("div", [
              _vm.accountService().writeAuthorities
                ? _c(
                    "button",
                    {
                      staticClass: "btn btn-warning",
                      on: {
                        click: function ($event) {
                          return _vm.editDiagram()
                        },
                      },
                    },
                    [
                      _c("font-awesome-icon", {
                        attrs: { icon: "pencil-alt" },
                      }),
                      _vm._v(" "),
                      _c("span", [_vm._v(" Generate diagram")]),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _c("div", [_vm._v("No preview available")]),
              _vm._v(" "),
              _vm.accountService().writeAuthorities
                ? _c("div", [
                    _vm._v(
                      "\n        Generate diagram and use Arrange > Layout > Vertical Flow or Arrange > Layout > Organic to distribute the first diagram components\n      "
                    ),
                  ])
                : _vm._e(),
            ])
          : _vm._e(),
        _vm._v(" "),
        _vm.drawIoSVG && !_vm.isEditing
          ? _c("div", { staticClass: "m-5" }, [
              _c("div", { domProps: { innerHTML: _vm._s(_vm.drawIoSVG) } }),
            ])
          : _vm._e(),
        _vm._v(" "),
        _c("div", { staticClass: "btn-group" }, [
          !_vm.isEditing
            ? _c("span", [
                _vm.accountService().writeAuthorities && _vm.drawIoSVG
                  ? _c(
                      "button",
                      {
                        staticClass: "btn btn-warning",
                        on: {
                          click: function ($event) {
                            return _vm.editDiagram()
                          },
                        },
                      },
                      [
                        _c("font-awesome-icon", {
                          attrs: { icon: "pencil-alt" },
                        }),
                        _c("span", [_vm._v(" Edit diagram")]),
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.accountService().writeAuthorities &&
                _vm.drawIoSVG &&
                _vm.drawIOToBeSaved
                  ? _c(
                      "button",
                      {
                        staticClass: "btn btn-primary",
                        on: {
                          click: function ($event) {
                            return _vm.saveDiagram()
                          },
                        },
                      },
                      [
                        _c("font-awesome-icon", {
                          attrs: { icon: "pencil-alt" },
                        }),
                        _c("span", [_vm._v(" Save diagram")]),
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.accountService().writeAuthorities &&
                _vm.drawIoSVG &&
                !_vm.drawIOToBeSaved
                  ? _c(
                      "button",
                      {
                        staticClass: "btn btn-danger",
                        on: {
                          click: function ($event) {
                            return _vm.prepareRemove()
                          },
                        },
                      },
                      [
                        _c("font-awesome-icon", { attrs: { icon: "times" } }),
                        _c("span", [_vm._v(" Delete Diagram")]),
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.drawIoSVG && !_vm.isEditing
                  ? _c(
                      "button",
                      {
                        staticClass: "btn btn-info",
                        on: {
                          click: function ($event) {
                            return _vm.exportDrawIOXML()
                          },
                        },
                      },
                      [
                        _c("font-awesome-icon", { attrs: { icon: "eye" } }),
                        _c("span", [_vm._v(" Export diagram")]),
                      ],
                      1
                    )
                  : _vm._e(),
              ])
            : _vm._e(),
        ]),
        _vm._v(" "),
        !_vm.isHidden
          ? _c("div", [
              _c("iframe", {
                attrs: {
                  "v-if": !_vm.isHidden,
                  id: "myDiv",
                  src: "https://embed.diagrams.net/?nav=1&edit=_blank&layers=1&highlight=0000ff&embed=1&noSaveBtn=1&libraries=1&proto=json",
                },
              }),
            ])
          : _vm._e(),
      ]),
      _vm._v(" "),
      _c(
        "b-modal",
        { ref: "removeDiagramEntity", attrs: { id: "removeDiagramEntity" } },
        [
          _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
            _c(
              "span",
              {
                attrs: {
                  id: "eaDesignItApp.landscapeView.delete.question",
                  "data-cy": "landscapeViewDeleteDialogHeading",
                },
              },
              [_vm._v("Confirm delete operation")]
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-body" }, [
            _c("p", { attrs: { id: "jhi-delete-landscapeView-heading" } }, [
              _vm._v("Are you sure you want to delete this Landscape View?"),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { attrs: { slot: "modal-footer" }, slot: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: { type: "button" },
                on: {
                  click: function ($event) {
                    return _vm.closeDialog()
                  },
                },
              },
              [_vm._v("Cancel")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "button",
                  id: "jhi-confirm-delete-landscapeView",
                  "data-cy": "entityConfirmDeleteButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.deleteDiagram()
                  },
                },
              },
              [_vm._v("\n        Delete\n      ")]
            ),
          ]),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        { ref: "detachFlowEntity", attrs: { id: "detachFlowEntity" } },
        [
          _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
            _c(
              "span",
              {
                attrs: {
                  id: "eaDesignItApp.landscapeView.delete.question",
                  "data-cy": "landscapeViewDeleteDialogHeading",
                },
              },
              [_vm._v("Confirm delete operation")]
            ),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-body" }, [
            _c("p", { attrs: { id: "jhi-delete-landscapeView-heading" } }, [
              _vm._v("Are you sure you want to detach this Functional Flow?"),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { attrs: { slot: "modal-footer" }, slot: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: { type: "button" },
                on: {
                  click: function ($event) {
                    return _vm.closeDetachDialog()
                  },
                },
              },
              [_vm._v("Cancel")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "button",
                  id: "jhi-confirm-delete-landscapeView",
                  "data-cy": "entityConfirmDeleteButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.detachFunctionalFlow()
                  },
                },
              },
              [_vm._v("\n        Delete\n      ")]
            ),
          ]),
        ]
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        { ref: "addExistingEntity", attrs: { id: "addExistingEntity" } },
        [
          _c("span", { attrs: { slot: "modal-title" }, slot: "modal-title" }, [
            _vm._v("Search for exising Functional Flow"),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-body" }, [
            _c("p", { attrs: { id: "jhi-delete-landscapeView-heading" } }, [
              _vm._v("Search for exising Functional Flow"),
            ]),
            _vm._v(" "),
            _vm.functionalFlows && _vm.functionalFlows.length > 0
              ? _c("div", { staticClass: "table-responsive" }, [
                  _c(
                    "table",
                    {
                      staticClass: "table table-striped",
                      attrs: { "aria-describedby": "functionalFlows" },
                    },
                    [
                      _c("thead", [
                        _c("tr", [
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Alias")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Description")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Documentation URL")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Documentation URL 2")]),
                          ]),
                          _vm._v(" "),
                          _c("th", { attrs: { scope: "row" } }, [
                            _c("span", [_vm._v("Interfaces")]),
                          ]),
                          _vm._v(" "),
                          _c("th"),
                        ]),
                      ]),
                      _vm._v(" "),
                      _c(
                        "tbody",
                        _vm._l(_vm.functionalFlows, function (functionalFlow) {
                          return _c(
                            "tr",
                            {
                              key: functionalFlow.id,
                              attrs: { "data-cy": "entityTable" },
                            },
                            [
                              _c(
                                "td",
                                [
                                  _c(
                                    "router-link",
                                    {
                                      attrs: {
                                        to: {
                                          name: "FunctionalFlowView",
                                          params: {
                                            functionalFlowId: functionalFlow.id,
                                          },
                                        },
                                        target: "_blank",
                                      },
                                    },
                                    [_vm._v(_vm._s(functionalFlow.alias))]
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(functionalFlow.description)),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _c(
                                  "a",
                                  {
                                    attrs: {
                                      href: functionalFlow.documentationURL,
                                      target: "_blank",
                                    },
                                  },
                                  [
                                    _vm._v(
                                      _vm._s(
                                        functionalFlow.documentationURL
                                          ? functionalFlow.documentationURL.substring(
                                              0,
                                              20
                                            )
                                          : ""
                                      )
                                    ),
                                  ]
                                ),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _c(
                                  "a",
                                  {
                                    attrs: {
                                      href: functionalFlow.documentationURL2,
                                      target: "_blank",
                                    },
                                  },
                                  [
                                    _vm._v(
                                      _vm._s(
                                        functionalFlow.documentationURL2
                                          ? functionalFlow.documentationURL2.substring(
                                              0,
                                              20
                                            )
                                          : ""
                                      )
                                    ),
                                  ]
                                ),
                              ]),
                              _vm._v(" "),
                              _c(
                                "td",
                                _vm._l(
                                  functionalFlow.steps,
                                  function (step, i) {
                                    return _c(
                                      "span",
                                      {
                                        key: step.id,
                                        attrs: {
                                          set: (_vm.interfaces =
                                            step.flowInterface),
                                          title:
                                            "[ " +
                                            _vm.interfaces.source.name +
                                            " / " +
                                            _vm.interfaces.target.name +
                                            " ]" +
                                            (_vm.interfaces.protocol
                                              ? " (" +
                                                _vm.interfaces.protocol.type +
                                                ") "
                                              : ""),
                                        },
                                      },
                                      [
                                        _vm._v(
                                          _vm._s(i > 0 ? ", " : "") +
                                            "\n                  " +
                                            _vm._s(_vm.interfaces.alias) +
                                            "\n                "
                                        ),
                                      ]
                                    )
                                  }
                                ),
                                0
                              ),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(functionalFlow.startDate)),
                              ]),
                              _vm._v(" "),
                              _c("td", [
                                _vm._v(_vm._s(functionalFlow.endDate)),
                              ]),
                              _vm._v(" "),
                              _c("td", { staticClass: "text-right" }, [
                                _c("div", { staticClass: "btn-group" }, [
                                  _c(
                                    "button",
                                    {
                                      staticClass:
                                        "btn btn-primary btn-sm edit",
                                      attrs: { "data-cy": "entityEditButton" },
                                      on: {
                                        click: function ($event) {
                                          return _vm.addNew(functionalFlow)
                                        },
                                      },
                                    },
                                    [
                                      _c("font-awesome-icon", {
                                        attrs: { icon: "pencil-alt" },
                                      }),
                                      _vm._v(" "),
                                      _c(
                                        "span",
                                        { staticClass: "d-none d-md-inline" },
                                        [_vm._v("Add")]
                                      ),
                                    ],
                                    1
                                  ),
                                ]),
                              ]),
                            ]
                          )
                        }),
                        0
                      ),
                    ]
                  ),
                ])
              : _vm._e(),
          ]),
          _vm._v(" "),
          _c("div", { attrs: { slot: "modal-footer" }, slot: "modal-footer" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: { type: "button" },
                on: {
                  click: function ($event) {
                    return _vm.closeSearchFlow()
                  },
                },
              },
              [_vm._v("Cancel")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "button",
                  id: "jhi-confirm-delete-landscapeView",
                  "data-cy": "entityConfirmDeleteButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.addNew()
                  },
                },
              },
              [_vm._v("\n        Add\n      ")]
            ),
          ]),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Viewpoint")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Diagram Name")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Owner")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Capabilities")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", [_c("br")])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Flow")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Description")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Step")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Interface")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Source")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Target")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("Protocol")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("th", { attrs: { scope: "row" } }, [
      _c("span", [_vm._v("DataFlow")]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./landscape-view-details.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/landscape-view/landscape-view-details.vue?vue&type=style&index=0&lang=css&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(/*! !../../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js")["default"])
var update = add("11c5d0bf", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_landscape-view_landscape-view-details_vue.js.map